import { useState, useEffect } from 'react';
import { 
  LogIn, UserPlus, Play, PawPrint, Menu, X, ShoppingBag, 
  PlusCircle, Phone, User, LogOut, CheckCircle2, ShieldCheck, Heart,
  Instagram, MapPin, Award, Clock, Sparkles, ExternalLink, FileSpreadsheet, BarChart3, HardDrive, Edit3, Film
} from 'lucide-react';
import BoomerangVideoBg from './BoomerangVideoBg';
import bgVideo from './assets/videos/labrador-hero.mp4';
import { INITIAL_PETS } from './data/mockPets';
import { PetListing, UserSession, OwnerDetails } from './types';
import AuthModal from './components/AuthModal';
import PetMarketplaceModal from './components/PetMarketplaceModal';
import PetInquiryModal from './components/PetInquiryModal';
import OwnerKennelModal from './components/OwnerKennelModal';
import PetSuppliesModal from './components/PetSuppliesModal';
import AdminDashboardModal from './components/AdminDashboardModal';
import CapybaraMascotModal from './components/CapybaraMascotModal';
import GoogleDriveVaultModal from './components/GoogleDriveVaultModal';
import EditDetailsModal from './components/EditDetailsModal';
import VideoSpotlightModal from './components/VideoSpotlightModal';
import OpeningIntroScreen from './components/OpeningIntroScreen';
import { detailsService } from './services/detailsService';
import { storageService } from './services/storageService';
import { ga4Service } from './services/ga4Analytics';
import { videoStorageService, VideoMetadata } from './services/videoStorageService';
import { initAuth, googleSignIn, logoutGoogle } from './services/googleAuth';
import AccountSettingsModal from './components/AccountSettingsModal';
import ContactModal from './components/ContactModal';
import FeedbackModal from './components/FeedbackModal';
import PrivacyNoticeModal from './components/PrivacyNoticeModal';
import GrowthBar from './components/GrowthBar';

const BG_VIDEO = '/INTRO.mp4';

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [pets, setPets] = useState<PetListing[]>(INITIAL_PETS);
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);

  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  
  const [isMarketplaceOpen, setIsMarketplaceOpen] = useState(false);
  const [marketplaceTab, setMarketplaceTab] = useState<'buy' | 'sell'>('buy');
  
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [isSuppliesModalOpen, setIsSuppliesModalOpen] = useState(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);
  const [isCapybaraModalOpen, setIsCapybaraModalOpen] = useState(false);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [isEditDetailsOpen, setIsEditDetailsOpen] = useState(false);
  const [isAccountSettingsOpen, setIsAccountSettingsOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [ownerDetails, setOwnerDetails] = useState<OwnerDetails>(() => detailsService.getDetails());

  // Starting Page Video state
  const [activeVideoSrc, setActiveVideoSrc] = useState<string>(BG_VIDEO);
  const [isCustomVideo, setIsCustomVideo] = useState<boolean>(false);
  const [videoMetadata, setVideoMetadata] = useState<VideoMetadata | null>(null);
  const [isVideoMuted, setIsVideoMuted] = useState<boolean>(true);
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(true);
  const [isVideoSpotlightOpen, setIsVideoSpotlightOpen] = useState<boolean>(false);
  const [showIntroScreen, setShowIntroScreen] = useState<boolean>(true);

  const loadStartingVideo = async () => {
    try {
      const custom = await videoStorageService.getCustomVideo();
      if (custom) {
        setActiveVideoSrc(custom.url);
        setIsCustomVideo(true);
        setVideoMetadata(custom.metadata);
      } else {
        setActiveVideoSrc(BG_VIDEO);
        setIsCustomVideo(false);
        setVideoMetadata(null);
      }
    } catch {
      setActiveVideoSrc(BG_VIDEO);
      setIsCustomVideo(false);
    }
  };

  useEffect(() => {
    loadStartingVideo();
    const unsub = videoStorageService.subscribe(() => {
      loadStartingVideo();
    });
    return unsub;
  }, []);

  useEffect(() => {
    const unsub = detailsService.subscribe((updated) => setOwnerDetails(updated));
    setOwnerDetails(detailsService.getDetails());
    return unsub;
  }, []);

  // Determine if active user is owner or founder
  const isOwnerOrFounder = Boolean(
    currentUser && (
      currentUser.role === 'admin' ||
      currentUser.email?.toLowerCase() === 'storybytech07@gmail.com' ||
      currentUser.email?.toLowerCase() === 'founder@thepawclub.in' ||
      currentUser.phone?.replace(/\D/g, '').endsWith('9014508314') ||
      currentUser.name?.toLowerCase().includes('storybytech') ||
      currentUser.name?.toLowerCase().includes('sai')
    )
  );
  
  const [selectedPetForInquiry, setSelectedPetForInquiry] = useState<PetListing | null>(null);
  const [toastNotification, setToastNotification] = useState<string>('');

  // Track page view telemetry on mount
  useEffect(() => {
    storageService.recordPageView();
    ga4Service.trackPageView('PawClub Home');
  }, []);

  // Maintain Firebase authentication state across page navigation and reloads
  useEffect(() => {
    const unsub = initAuth((user) => {
      const isFounder = user.email?.toLowerCase() === 'storybytech07@gmail.com' || user.email?.toLowerCase() === 'founder@thepawclub.in';
      const stored = storageService.getUserById(user.uid);
      const session: UserSession = {
        id: user.uid,
        name: user.displayName || stored?.name || 'PawClub Member',
        phone: stored?.phone || (isFounder ? '+91 9014508314' : ''),
        email: user.email || undefined,
        role: isFounder ? 'admin' : (stored?.role === 'admin' ? 'admin' : stored?.role === 'seller' ? 'seller' : 'buyer'),
        avatar: user.photoURL || stored?.avatarUrl || undefined,
        authMethod: 'google',
        savedPets: []
      };
      setCurrentUser(session);
    }, () => {
      // not signed in
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, []);

  const handleQuickGoogleSignIn = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        const { user, profile } = res;
        const isFounder = user.email?.toLowerCase() === 'storybytech07@gmail.com' || user.email?.toLowerCase() === 'founder@thepawclub.in';
        const session: UserSession = {
          id: user.uid,
          name: user.displayName || profile.name || 'PawClub Member',
          phone: profile.phone || (isFounder ? '+91 9014508314' : ''),
          email: user.email || undefined,
          role: isFounder ? 'admin' : (profile.role === 'admin' ? 'admin' : profile.role === 'seller' ? 'seller' : 'buyer'),
          avatar: user.photoURL || profile.avatarUrl || undefined,
          authMethod: 'google',
          savedPets: []
        };
        handleLoginSuccess(session);
      }
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        setIsAuthOpen(true);
      }
    }
  };

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  const showToast = (msg: string) => {
    setToastNotification(msg);
    setTimeout(() => setToastNotification(''), 4000);
  };

  const handleLoginSuccess = (session: UserSession) => {
    setCurrentUser(session);
    showToast(`Welcome, ${session.name}! Logged in successfully.`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('You have been signed out.');
  };

  const handleAddPet = (newPet: PetListing) => {
    setPets((prev) => [newPet, ...prev]);
  };

  const openMarketplace = (tab: 'buy' | 'sell') => {
    setMarketplaceTab(tab);
    setIsMarketplaceOpen(true);
    setMenuOpen(false);
  };

  const openAuth = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
    setMenuOpen(false);
  };

  return (
    <section className="relative w-full min-h-screen sm:h-screen overflow-hidden bg-[#18110b]">
      {/* 1. Opening Page Video Intro (Plays automatically when opening website) */}
      {showIntroScreen && (
        <OpeningIntroScreen
          videoSrc={activeVideoSrc}
          onEnter={() => setShowIntroScreen(false)}
          brandName={ownerDetails.businessName || 'THE PAWCLUB'}
          location={ownerDetails.location || 'Kamareddy, Telangana, India'}
          trainerInfo={ownerDetails.specialization || 'Certified Trainer · Boarding & Kennel Facility'}
        />
      )}

      {/* Main Website Interface */}
      <BoomerangVideoBg 
        src={activeVideoSrc} 
        className="absolute inset-0 w-full h-full"
        isMuted={isVideoMuted}
        isPlaying={isVideoPlaying}
        onTogglePlay={() => setIsVideoPlaying((p) => !p)}
        onToggleMute={() => setIsVideoMuted((m) => !m)}
        onOpenSpotlight={() => setIsVideoSpotlightOpen(true)}
        onOpenUpload={() => setIsVideoSpotlightOpen(true)}
        onReplayIntro={() => setShowIntroScreen(true)}
        isCustomVideo={isCustomVideo}
        isOwnerOrFounder={isOwnerOrFounder}
      />
      
      {/* Toast Alert */}
      {toastNotification && (
        <div className="fixed top-24 right-6 z-50 bg-[#2a170d] text-amber-300 px-4 py-2.5 rounded-2xl shadow-2xl border border-amber-600/40 flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{toastNotification}</span>
        </div>
      )}

      {/* Top Announcement Bar */}
      <header className="absolute top-0 left-0 right-0 z-40 bg-[#1e1108]/85 backdrop-blur-md border-b border-amber-900/40 text-white text-[11px] sm:text-xs py-1.5 px-4 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3 overflow-hidden whitespace-nowrap">
          <span className="flex items-center gap-1 font-bold text-amber-400">
            <MapPin className="w-3 h-3 text-amber-400" /> Kamareddy, Telangana
          </span>
          <span className="hidden md:inline text-white/40">|</span>
          <span className="hidden md:flex items-center gap-1 text-white/90 font-medium">
            <PawPrint className="w-3 h-3 text-amber-400" /> Dog Boarding & Training Kennel
          </span>
          <span className="hidden lg:inline text-white/40">|</span>
          <span className="hidden lg:inline text-amber-200/90 font-medium">
            🐶 Puppies & Exotic Pets · Pet Supplies Shop
          </span>
        </div>

        <div className="flex items-center gap-3 font-semibold flex-shrink-0">
          {isOwnerOrFounder && (
            <>
              <button
                onClick={() => setIsAdminDashboardOpen(true)}
                className="flex items-center gap-1.5 text-amber-300 hover:text-white transition-colors cursor-pointer text-[10px] sm:text-xs font-bold bg-amber-950/80 px-2.5 py-0.5 rounded-full border border-amber-500/40 shadow-xs"
                title="Open Admin, Google Sheets & Analytics Command Center"
              >
                <ShieldCheck className="w-3 h-3 text-amber-400" />
                <span>Owner & Sheets Portal</span>
              </button>
              <span className="text-white/40 hidden sm:inline">|</span>
            </>
          )}
          <a
            href="https://instagram.com/thepawclub_2"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-pink-300 hover:text-pink-200 transition-colors"
          >
            <Instagram className="w-3 h-3 text-pink-400" />
            <span className="hidden sm:inline">Official:</span> @thepawclub_2
          </a>
          <span className="text-white/40">|</span>
          <a
            href="tel:9014508314"
            className="flex items-center gap-1 text-amber-300 hover:text-amber-200 font-extrabold"
          >
            <Phone className="w-3 h-3 text-amber-400" /> 9014508314
          </a>
        </div>
      </header>

      {/* Main Navigation */}
      <nav className="absolute top-7 sm:top-8 left-0 right-0 z-30 flex items-center justify-between px-4 sm:px-6 md:px-10 py-3 sm:py-4">
        {/* Brand Logo */}
        <div 
          onClick={() => setIsOwnerModalOpen(true)}
          className="flex items-center gap-2 text-[#2a170d] cursor-pointer hover:opacity-90 transition-opacity"
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-md">
            <PawPrint className="w-5 h-5 text-amber-950" />
          </div>
          <div>
            <span className="text-lg sm:text-xl md:text-2xl font-extrabold tracking-tight text-[#22130a]">
              PawClub<sup className="text-[10px] sm:text-xs font-bold text-amber-700">®</sup>
            </span>
            <span className="block text-[9px] uppercase tracking-wider text-amber-800 font-extrabold -mt-1 hidden sm:block">
              Kamareddy Kennel & Supplies
            </span>
          </div>
        </div>

        {/* Center Desktop Navigation Pill */}
        <div className="hidden lg:flex items-center gap-1 bg-white/85 backdrop-blur-md rounded-full pl-5 pr-1.5 py-1.5 shadow-md border border-amber-900/15">
          <button
            onClick={() => openMarketplace('buy')}
            className="text-xs sm:text-sm px-3.5 py-1.5 font-extrabold text-[#2a170d] hover:text-amber-700 transition-colors cursor-pointer flex items-center gap-1.5"
          >
            🐾 Buy & Adopt Pets
            <span className="text-[10px] bg-amber-100 text-amber-950 px-1.5 py-0.5 rounded-full font-bold border border-amber-300">
              {pets.length} Available
            </span>
          </button>

          <button
            onClick={() => setIsSuppliesModalOpen(true)}
            className="text-xs sm:text-sm px-3.5 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-amber-700" />
            Pet Supplies Shop
          </button>
          
          <button
            onClick={() => setIsOwnerModalOpen(true)}
            className="text-xs sm:text-sm px-3.5 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1"
          >
            <Award className="w-3.5 h-3.5 text-amber-700" />
            Boarding & Training
          </button>

          <button
            onClick={() => openMarketplace('sell')}
            className="text-xs sm:text-sm px-3.5 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1"
          >
            <PlusCircle className="w-3.5 h-3.5 text-amber-700" />
            Sell a Pet
          </button>

          <button
            onClick={() => setIsCapybaraModalOpen(true)}
            className="text-xs sm:text-sm px-3 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1.5 bg-amber-100/70 rounded-full border border-amber-300 hover:bg-amber-200/70"
            title="Meet PawClub's exotic walking mascot"
          >
            <span className="text-sm">🦫</span>
            Capybara
          </button>

          <button
            onClick={() => setShowIntroScreen(true)}
            className="text-xs sm:text-sm px-3.5 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1.5 bg-amber-100/90 rounded-full border border-amber-300 hover:bg-amber-200/90 shadow-xs"
            title="Replay opening intro video"
          >
            <Film className="w-3.5 h-3.5 text-amber-800" />
            Intro Video
          </button>

          {/* Owner & Founder Restricted Management Tools */}
          {isOwnerOrFounder && (
            <div className="flex items-center gap-1 pl-2 ml-1 border-l border-amber-900/20">
              <button
                onClick={() => setIsDriveModalOpen(true)}
                className="text-xs sm:text-sm px-3 py-1.5 font-bold text-[#14532d] hover:text-[#052e16] transition-colors cursor-pointer flex items-center gap-1.5 bg-emerald-100/90 rounded-full border border-emerald-400 shadow-xs"
                title="Open PawClub Pet Vault on Google Drive (Owner Only)"
              >
                <HardDrive className="w-3.5 h-3.5 text-emerald-800" />
                Drive Vault
              </button>

              <button
                onClick={() => setIsAdminDashboardOpen(true)}
                className="text-xs sm:text-sm px-3 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1.5 bg-amber-100/90 rounded-full border border-amber-400 shadow-xs"
                title="Open Admin, Google Sheets & GA4 Telemetry (Owner Only)"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-800" />
                Sheets Portal
              </button>

              <button
                onClick={() => setIsEditDetailsOpen(true)}
                className="text-xs sm:text-sm px-3 py-1.5 font-bold text-[#452718] hover:text-[#2a170d] transition-colors cursor-pointer flex items-center gap-1.5 bg-amber-50 rounded-full border border-amber-300 hover:bg-amber-100/70"
                title="Replace details with your own personal / kennel details (Owner Only)"
              >
                <Edit3 className="w-3.5 h-3.5 text-amber-700" />
                Edit Details
              </button>
            </div>
          )}

          <a
            href={`tel:${ownerDetails.phone}`}
            className="ml-2 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs font-extrabold px-4 py-2 rounded-full transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Phone className="w-3 h-3 text-amber-400" />
            Call: {ownerDetails.phone}
          </a>
        </div>

        {/* Right Action Icons & Login */}
        <div className="flex items-center gap-2.5 sm:gap-4 text-[#2a170d]">
          {currentUser ? (
            <div className="hidden sm:flex items-center gap-2 bg-white/90 backdrop-blur-md py-1 px-3 rounded-full border border-amber-900/15 shadow-sm text-xs">
              <div 
                onClick={() => setIsAccountSettingsOpen(true)}
                className="w-7 h-7 rounded-full overflow-hidden bg-amber-700 text-white flex items-center justify-center font-bold text-[10px] cursor-pointer hover:ring-2 hover:ring-amber-500 transition-all"
                title="Account Settings"
              >
                {currentUser.avatar ? (
                  <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                ) : (
                  currentUser.name.charAt(0).toUpperCase()
                )}
              </div>
              <div className="text-left cursor-pointer" onClick={() => setIsAccountSettingsOpen(true)} title="View Account Settings">
                <span className="font-extrabold text-[#2a170d] block leading-tight flex items-center gap-1">
                  {currentUser.name}
                  {currentUser.role === 'admin' && (
                    <span className="text-[9px] bg-amber-600 text-white px-1.5 py-0.2 rounded-full font-bold">Admin</span>
                  )}
                </span>
                <span className="text-[10px] text-amber-900 flex items-center gap-0.5 font-bold">
                  <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" /> Member Account
                </span>
              </div>
              {isOwnerOrFounder && (
                <button
                  onClick={() => setIsAdminDashboardOpen(true)}
                  title="Open Founder Admin & Sheets Dashboard"
                  className="ml-1 text-amber-900 hover:bg-amber-100 transition-colors cursor-pointer p-1 rounded-full"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={async () => {
                  await logoutGoogle();
                  handleLogout();
                }}
                title="Log out"
                className="text-gray-400 hover:text-red-600 transition-colors cursor-pointer p-1"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <>
              {/* Professional Continue with Google Button */}
              <button
                onClick={handleQuickGoogleSignIn}
                className="hidden sm:flex items-center gap-2 text-xs font-extrabold bg-white hover:bg-amber-50 text-gray-800 px-3.5 py-1.5 rounded-full shadow-md border border-amber-900/15 transition-all cursor-pointer hover:shadow-lg"
                title="Register or Sign In with Google"
              >
                <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                </svg>
                <span>Continue with Google</span>
              </button>

              <button
                onClick={() => openAuth('login')}
                className="hidden sm:flex items-center gap-1.5 text-xs font-extrabold bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 px-4 py-2 rounded-full shadow-md transition-all cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                Sign In
              </button>
            </>
          )}

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="lg:hidden relative flex items-center justify-center w-10 h-10 rounded-full bg-white/85 backdrop-blur-md border border-amber-900/20 text-[#2a170d] transition-all duration-300 hover:bg-white cursor-pointer shadow-sm"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
          >
            <Menu
              className={`w-5 h-5 absolute transition-all duration-300 ${
                menuOpen ? 'opacity-0 rotate-90 scale-50' : 'opacity-100 rotate-0 scale-100'
              }`}
            />
            <X
              className={`w-5 h-5 absolute transition-all duration-300 ${
                menuOpen ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-50'
              }`}
            />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      <div
        className={`lg:hidden fixed inset-0 z-40 transition-opacity duration-300 ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setMenuOpen(false)}
      >
        <div className="absolute inset-0 bg-[#160c06]/60 backdrop-blur-sm" />
      </div>

      <div
        className={`lg:hidden fixed top-0 right-0 bottom-0 z-50 w-[88%] max-w-sm bg-[#fffdfb]/98 backdrop-blur-xl shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          menuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full pt-20 px-6 pb-6 justify-between overflow-y-auto">
          <div>
            {/* Kennel Quick Info Header in Drawer */}
            <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200/80 mb-5">
              <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                PawClub Boarding & Training Kennel
              </span>
              <h3 className="text-base font-extrabold text-[#2a170d] mt-0.5">The PawClub Kennel</h3>
              <p className="text-xs text-amber-950 font-semibold mt-1">📍 Kamareddy, Telangana, India</p>
              
              <div className="mt-2.5 pt-2 border-t border-amber-200/60 flex items-center justify-between text-xs">
                <a href="tel:9014508314" className="font-extrabold text-amber-900 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-amber-700" /> 9014508314
                </a>
                <a
                  href="https://instagram.com/thepawclub_2"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-bold text-pink-600 flex items-center gap-1"
                >
                  <Instagram className="w-3.5 h-3.5" /> @thepawclub_2
                </a>
              </div>
            </div>

            {/* Nav list */}
            <div className="flex flex-col gap-1">
              <button
                onClick={() => openMarketplace('buy')}
                className="text-lg font-extrabold text-[#2a170d] py-3 text-left border-b border-amber-100 flex items-center justify-between"
              >
                <span>🐾 Buy & Adopt Pets</span>
                <span className="text-xs font-bold bg-[#2a170d] text-amber-300 px-2 py-0.5 rounded-full">
                  {pets.length}
                </span>
              </button>

              <button
                onClick={() => { setIsSuppliesModalOpen(true); setMenuOpen(false); }}
                className="text-lg font-extrabold text-[#2a170d] py-3 text-left border-b border-amber-100 flex items-center justify-between"
              >
                <span>🥩 Pet Supplies & Food Shop</span>
                <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full">
                  Supplies
                </span>
              </button>

              <button
                onClick={() => { setIsOwnerModalOpen(true); setMenuOpen(false); }}
                className="text-lg font-extrabold text-amber-900 py-3 text-left border-b border-amber-100 flex items-center gap-2"
              >
                <Award className="w-5 h-5 text-amber-700" />
                Boarding & Training Details
              </button>
              
              <button
                onClick={() => openMarketplace('sell')}
                className="text-lg font-bold text-[#452718] py-3 text-left border-b border-amber-100 flex items-center gap-2"
              >
                <PlusCircle className="w-5 h-5 text-amber-700" />
                Sell / List a Pet
              </button>

              <button
                onClick={() => { setIsCapybaraModalOpen(true); setMenuOpen(false); }}
                className="text-lg font-extrabold text-amber-900 py-3 text-left border-b border-amber-100 flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <span className="text-xl">🦫</span>
                  Capybara Mascot & Exotic Pets
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-950 font-bold px-2 py-0.5 rounded-full border border-amber-400">
                  Interactive
                </span>
              </button>

              <button
                onClick={() => { setShowIntroScreen(true); setMenuOpen(false); }}
                className="text-lg font-extrabold text-amber-900 py-3 text-left border-b border-amber-100 flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <Film className="w-5 h-5 text-amber-700" />
                  Replay Opening Intro Video
                </span>
                <span className="text-[10px] bg-amber-500 text-amber-950 font-bold px-2 py-0.5 rounded-full">
                  Intro
                </span>
              </button>

              {/* Owner & Founder Only Mobile Menu Section */}
              {isOwnerOrFounder && (
                <div className="mt-2 pt-2 border-t-2 border-amber-200/60">
                  <span className="text-[11px] uppercase tracking-wider font-extrabold text-amber-800 px-1 block mb-1">
                    🔒 Founder & Owner Tools
                  </span>

                  <button
                    onClick={() => { setIsDriveModalOpen(true); setMenuOpen(false); }}
                    className="w-full text-base font-extrabold text-emerald-900 py-2.5 text-left border-b border-amber-100 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <HardDrive className="w-4 h-4 text-emerald-700" />
                      Google Drive Pet Vault
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                      Private
                    </span>
                  </button>

                  <button
                    onClick={() => { setIsAdminDashboardOpen(true); setMenuOpen(false); }}
                    className="w-full text-base font-extrabold text-amber-900 py-2.5 text-left border-b border-amber-100 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-amber-700" />
                      Admin & Google Sheets
                    </span>
                    <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full border border-amber-300">
                      Sheets
                    </span>
                  </button>

                  <button
                    onClick={() => { setIsEditDetailsOpen(true); setMenuOpen(false); }}
                    className="w-full text-base font-extrabold text-amber-900 py-2.5 text-left border-b border-amber-100 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2">
                      <Edit3 className="w-4 h-4 text-amber-700" />
                      Replace / Edit My Details
                    </span>
                    <span className="text-[10px] bg-amber-200 text-amber-950 font-bold px-2 py-0.5 rounded-full">
                      Settings
                    </span>
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 flex flex-col gap-2.5">
            {!currentUser ? (
              <>
                <button
                  onClick={() => openAuth('login')}
                  className="w-full flex items-center justify-center gap-2 text-xs font-bold text-white bg-gradient-to-r from-pink-600 to-purple-600 py-3 rounded-full shadow"
                >
                  <Instagram className="w-4 h-4" />
                  Instagram Login (@thepawclub_2)
                </button>
                <button
                  onClick={() => openAuth('login')}
                  className="w-full flex items-center justify-center gap-2 text-xs font-extrabold text-amber-300 bg-[#2a170d] py-3 rounded-full shadow"
                >
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  Sign In with Phone (9014508314)
                </button>
              </>
            ) : (
              <div className="p-3 bg-white rounded-xl border border-gray-200 text-center text-xs">
                <span className="font-bold text-gray-800">{currentUser.name}</span>
                <span className="block text-gray-500 mt-0.5">{currentUser.phone}</span>
                <button onClick={handleLogout} className="mt-2 text-red-600 font-bold text-xs underline">
                  Sign Out
                </button>
              </div>
            )}

            <a
              href="tel:9014508314"
              className="w-full bg-amber-500 hover:bg-amber-600 text-amber-950 text-xs font-extrabold py-3 rounded-full flex items-center justify-center gap-2 shadow"
            >
              <Phone className="w-3.5 h-3.5" /> Call PawClub Kennel: 9014508314
            </a>
          </div>
        </div>
      </div>

      {/* Hero Copy with New High-Contrast Rich Text Colors */}
      <div className="relative z-10 flex flex-col items-center text-center pt-28 sm:pt-32 md:pt-36 px-4 sm:px-6">
        
        {/* Brand Verified Badge (Clean, customer-facing) */}
        <div className="mb-4 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 backdrop-blur-md border border-amber-900/20 text-[#2a170d] shadow-sm">
          <PawPrint className="w-4 h-4 text-amber-700" />
          <span className="text-xs sm:text-sm font-extrabold">
            The PawClub Kennel & Pet Supplies · Kamareddy
          </span>
          <span className="text-[11px] bg-amber-500 text-amber-950 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
            Official Kennel
          </span>
        </div>

        {/* Primary Headline with Rich Warm Palette (Espresso & Amber-Gold) */}
        <h1
          className="font-normal leading-[0.94] text-[#1c120c] text-[2.2rem] sm:text-4xl md:text-5xl lg:text-[4.75rem] xl:text-[5.25rem] max-w-5xl drop-shadow-sm"
          style={{ 
            fontFamily: '"Neue Haas Grotesk Display Pro 55 Roman", "Neue Haas Grotesk Text Pro", "Helvetica Neue", Helvetica, Arial, sans-serif', 
            letterSpacing: '-0.035em' 
          }}
        >
          Cherish every wag{' '}
          <span className="text-[#b45309] font-medium" style={{ textShadow: '0 2px 20px rgba(251, 191, 36, 0.25)' }}>
            with certified care,
            <br className="hidden sm:block" /> boarding & supplies
          </span>
        </h1>

        {/* Central Action Buttons */}
        <div className="mt-6 sm:mt-8 flex items-center gap-3 flex-wrap justify-center">
          <button
            onClick={() => setIsSuppliesModalOpen(true)}
            className="bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs sm:text-sm font-extrabold px-6 py-3.5 rounded-full shadow-xl transition-transform hover:scale-105 cursor-pointer flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4 text-amber-400" />
            Shop Pet Supplies & Nutrition
          </button>

          <button
            onClick={() => openMarketplace('buy')}
            className="bg-white/90 hover:bg-white text-[#2a170d] text-xs sm:text-sm font-extrabold px-5 py-3.5 rounded-full shadow-md backdrop-blur-md border border-amber-900/20 transition-transform hover:scale-105 cursor-pointer flex items-center gap-2"
          >
            <PawPrint className="w-4 h-4 text-amber-700" />
            Adopt & Buy Pets
          </button>

          <button
            onClick={() => setShowIntroScreen(true)}
            className="bg-amber-500/90 hover:bg-amber-400 text-amber-950 text-xs sm:text-sm font-extrabold px-5 py-3.5 rounded-full shadow-md backdrop-blur-md transition-transform hover:scale-105 cursor-pointer flex items-center gap-1.5"
          >
            <Film className="w-4 h-4 text-amber-950" />
            Watch Intro Video
          </button>
        </div>
      </div>

      {/* MODALS */}
      {/* 1. Pet Marketplace Modal (Buy & Sell) */}
      <PetMarketplaceModal
        isOpen={isMarketplaceOpen}
        onClose={() => setIsMarketplaceOpen(false)}
        pets={pets}
        onAddPet={handleAddPet}
        onSelectPetForInquiry={(pet) => setSelectedPetForInquiry(pet)}
        initialTab={marketplaceTab}
        currentUser={currentUser}
        onOpenAuth={() => {
          setIsMarketplaceOpen(false);
          openAuth('login');
        }}
        onOpenOwner={() => {
          setIsMarketplaceOpen(false);
          setIsOwnerModalOpen(true);
        }}
        onOpenSupplies={() => {
          setIsMarketplaceOpen(false);
          setIsSuppliesModalOpen(true);
        }}
      />

      {/* 2. Pet Supplies Modal */}
      <PetSuppliesModal
        isOpen={isSuppliesModalOpen}
        onClose={() => setIsSuppliesModalOpen(false)}
        onOpenOwner={() => {
          setIsSuppliesModalOpen(false);
          setIsOwnerModalOpen(true);
        }}
      />

      {/* 3. Owner & Kennel Modal */}
      <OwnerKennelModal
        isOpen={isOwnerModalOpen}
        onClose={() => setIsOwnerModalOpen(false)}
        onOpenSupplies={() => {
          setIsOwnerModalOpen(false);
          setIsSuppliesModalOpen(true);
        }}
        onOpenMarketplace={() => {
          setIsOwnerModalOpen(false);
          openMarketplace('buy');
        }}
        onOpenEditDetails={() => {
          setIsOwnerModalOpen(false);
          setIsEditDetailsOpen(true);
        }}
        isOwnerOrFounder={isOwnerOrFounder}
      />

      {/* 4. Pet Inquiry Modal */}
      <PetInquiryModal
        pet={selectedPetForInquiry}
        isOpen={!!selectedPetForInquiry}
        onClose={() => setSelectedPetForInquiry(null)}
        currentUser={currentUser}
      />

      {/* 5. Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialMode={authMode}
      />

      {/* 6. Admin & Analytics Command Center Modal */}
      <AdminDashboardModal
        isOpen={isAdminDashboardOpen}
        onClose={() => setIsAdminDashboardOpen(false)}
        currentUser={currentUser}
      />

      {/* 7. Capybara Mascot & Exotic Pets Showcase Modal */}
      <CapybaraMascotModal
        isOpen={isCapybaraModalOpen}
        onClose={() => setIsCapybaraModalOpen(false)}
        onOpenOwner={() => setIsOwnerModalOpen(true)}
      />

      {/* 8. Google Drive Pet Vault Modal */}
      <GoogleDriveVaultModal
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
        currentUser={currentUser}
        isOwnerOrFounder={isOwnerOrFounder}
      />

      {/* 9. Replace With My Details Customization Modal */}
      <EditDetailsModal
        isOpen={isEditDetailsOpen}
        onClose={() => setIsEditDetailsOpen(false)}
        onSaved={(updated) => {
          setOwnerDetails(updated);
          showToast(`Details updated: ${updated.name} (${updated.phone})`);
        }}
      />

      {/* 10. Starting Page Video Theater & Upload Modal */}
      <VideoSpotlightModal
        isOpen={isVideoSpotlightOpen}
        onClose={() => setIsVideoSpotlightOpen(false)}
        videoSrc={activeVideoSrc}
        isCustomVideo={isCustomVideo}
        videoMetadata={videoMetadata}
        onVideoUpdated={() => {
          loadStartingVideo();
          showToast('Starting page video updated!');
        }}
        isOwnerOrFounder={isOwnerOrFounder}
      />

      {/* 11. User Account Settings & Profile Modal */}
      <AccountSettingsModal
        isOpen={isAccountSettingsOpen}
        onClose={() => setIsAccountSettingsOpen(false)}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* 12. Contact Kennel & Inquiries Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      {/* 13. Customer Experience & Review Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        currentUser={currentUser}
      />

      {/* 14. Privacy Notice & Security Policy Modal */}
      <PrivacyNoticeModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        onOpenDelete={() => setIsAccountSettingsOpen(true)}
      />

      {/* 15. Website Growth, Referral & Community Hub Bar */}
      <GrowthBar
        onOpenAuth={() => openAuth('login')}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        currentUser={currentUser}
      />
    </section>
  );
}

export default App;
