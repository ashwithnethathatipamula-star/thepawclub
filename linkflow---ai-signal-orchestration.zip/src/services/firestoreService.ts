import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  increment
} from 'firebase/firestore';
import { User } from 'firebase/auth';
import { db, auth } from './firebase';
import { UserProfile, LoginEvent, DailyAnalytics } from '../types/userManagement';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const firestoreService = {
  /**
   * Syncs user profile in Firestore.
   * Creates a profile if new, or updates lastLoginAt and increments totalLogins if returning.
   */
  async syncUserProfile(user: User, options?: { role?: 'user' | 'admin' | 'seller'; phone?: string; utmSource?: string; referralCode?: string }): Promise<UserProfile> {
    const userDocRef = doc(db, 'users', user.uid);
    const nowIso = new Date().toISOString();
    const isFounder = user.email?.toLowerCase() === 'storybytech07@gmail.com' || user.email?.toLowerCase() === 'founder@thepawclub.in';

    let existingProfile: UserProfile | null = null;
    try {
      const snap = await getDoc(userDocRef);
      if (snap.exists()) {
        existingProfile = snap.data() as UserProfile;
      }
    } catch (err) {
      console.warn('Could not read existing user doc from Firestore:', err);
    }

    if (existingProfile) {
      // Returning user: update last login and increment counter
      const updatedTotalLogins = (existingProfile.totalLogins || 0) + 1;
      const updatedRole = isFounder ? 'admin' : (existingProfile.role || 'user');
      const updateData: Partial<UserProfile> = {
        name: user.displayName || existingProfile.name || 'PawClub Member',
        email: user.email || existingProfile.email,
        photoURL: user.photoURL || existingProfile.avatarUrl || '',
        lastLoginAt: nowIso,
        totalLogins: updatedTotalLogins,
        role: updatedRole as any,
        status: existingProfile.status || 'active'
      };

      try {
        await updateDoc(userDocRef, {
          name: updateData.name,
          email: updateData.email,
          photoURL: updateData.photoURL,
          lastLoginAt: updateData.lastLoginAt,
          totalLogins: increment(1),
          role: updateData.role,
          status: updateData.status
        });
      } catch (err) {
        console.warn('Firestore updateDoc failed, fallback to local:', err);
      }

      return {
        ...existingProfile,
        ...updateData,
        id: user.uid,
        totalLogins: updatedTotalLogins
      };
    } else {
      // New user registration
      const newProfile: UserProfile = {
        id: user.uid,
        name: user.displayName || user.email?.split('@')[0] || 'PawClub Member',
        email: user.email || '',
        phone: options?.phone || '',
        role: isFounder ? 'admin' : (options?.role || 'user'),
        authMethod: 'google',
        registeredAt: nowIso,
        lastLoginAt: nowIso,
        totalLogins: 1,
        consentGiven: true,
        avatarUrl: user.photoURL || '',
        status: 'active'
      };

      try {
        await setDoc(userDocRef, {
          id: newProfile.id,
          name: newProfile.name,
          email: newProfile.email,
          photoURL: newProfile.avatarUrl || '',
          phone: newProfile.phone || '',
          role: newProfile.role,
          authMethod: newProfile.authMethod,
          registeredAt: newProfile.registeredAt,
          lastLoginAt: newProfile.lastLoginAt,
          totalLogins: 1,
          status: newProfile.status,
          referralCode: options?.referralCode || '',
          utmSource: options?.utmSource || ''
        });
      } catch (err) {
        console.warn('Firestore setDoc failed:', err);
      }

      // If founder, also ensure admin record in /admins/{uid}
      if (isFounder) {
        try {
          await setDoc(doc(db, 'admins', user.uid), {
            email: user.email,
            role: 'superadmin',
            grantedAt: nowIso
          });
        } catch { /* admin record creation attempted */ }
      }

      return newProfile;
    }
  },

  /**
   * Records a discrete login audit event in /login_events/{eventId}
   */
  async recordLoginEvent(user: User, method: string = 'google', status: 'success' | 'failed' = 'success'): Promise<LoginEvent> {
    const eventId = `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date();
    const event: LoginEvent = {
      id: eventId,
      userId: user.uid,
      userEmail: user.email || 'N/A',
      userName: user.displayName || 'Member',
      timestamp: now.toISOString(),
      loginDate: now.toISOString().split('T')[0],
      loginTime: now.toTimeString().split(' ')[0],
      authMethod: method,
      device: typeof navigator !== 'undefined' ? (navigator.userAgent.includes('Mobile') ? 'Mobile Browser' : 'Desktop Browser') : 'Web',
      status: status
    };

    try {
      await setDoc(doc(db, 'login_events', eventId), {
        id: event.id,
        userId: event.userId,
        userEmail: event.userEmail,
        userName: event.userName,
        timestamp: event.timestamp,
        loginDate: event.loginDate,
        loginTime: event.loginTime,
        authMethod: event.authMethod,
        device: event.device,
        status: event.status
      });
    } catch (err) {
      console.warn('Firestore recordLoginEvent failed:', err);
    }

    return event;
  },

  /**
   * Fetches all registered users (for authorized Founder/Admin)
   */
  async fetchAllUsers(): Promise<UserProfile[]> {
    const path = 'users';
    try {
      const snap = await getDocs(collection(db, path));
      const users: UserProfile[] = [];
      snap.forEach((d) => {
        const data = d.data() as any;
        users.push({
          id: d.id,
          name: data.name || 'Member',
          email: data.email || '',
          phone: data.phone || '',
          role: data.role || 'user',
          authMethod: data.authMethod || 'google',
          registeredAt: data.registeredAt || new Date().toISOString(),
          lastLoginAt: data.lastLoginAt || new Date().toISOString(),
          totalLogins: data.totalLogins || 1,
          consentGiven: true,
          avatarUrl: data.photoURL || data.avatarUrl || '',
          status: data.status || 'active'
        });
      });
      return users;
    } catch (err) {
      console.warn('Failed to fetch all users from Firestore (admin permission or offline):', err);
      return [];
    }
  },

  /**
   * Fetches login history audit logs (for authorized Founder/Admin)
   */
  async fetchLoginHistory(limitCount: number = 50): Promise<LoginEvent[]> {
    const path = 'login_events';
    try {
      const q = query(collection(db, path), orderBy('timestamp', 'desc'), limit(limitCount));
      const snap = await getDocs(q);
      const events: LoginEvent[] = [];
      snap.forEach((d) => {
        events.push(d.data() as LoginEvent);
      });
      return events;
    } catch (err) {
      console.warn('Failed to fetch login history from Firestore:', err);
      return [];
    }
  },

  /**
   * Delete user account from Firestore
   */
  async deleteUserAccount(userId: string): Promise<void> {
    const path = `users/${userId}`;
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  /**
   * Store contact submission
   */
  async saveContactSubmission(data: { name: string; email: string; phone?: string; message: string; service?: string }): Promise<string> {
    const id = `contact_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const path = `contact_submissions/${id}`;
    const payload = {
      id,
      name: data.name,
      email: data.email,
      phone: data.phone || '',
      service: data.service || 'General Inquiry',
      message: data.message,
      createdAt: new Date().toISOString(),
      status: 'new'
    };
    try {
      await setDoc(doc(db, 'contact_submissions', id), payload);
      return id;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  },

  /**
   * Store newsletter subscriber
   */
  async saveNewsletterSubscriber(email: string, source: string = 'footer'): Promise<string> {
    const cleanEmail = email.trim().toLowerCase();
    const id = `sub_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const path = `newsletter_subscribers/${id}`;
    const payload = {
      id,
      email: cleanEmail,
      consentGiven: 'explicit_double_optin',
      subscribedAt: new Date().toISOString(),
      source
    };
    try {
      await setDoc(doc(db, 'newsletter_subscribers', id), payload);
      return id;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  },

  /**
   * Store feedback submission
   */
  async saveFeedback(data: { name?: string; email?: string; rating: number; comment: string }): Promise<string> {
    const id = `fb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const path = `feedback_submissions/${id}`;
    const payload = {
      id,
      name: data.name || 'Anonymous Club Guest',
      email: data.email || '',
      rating: Number(data.rating),
      comment: data.comment,
      createdAt: new Date().toISOString()
    };
    try {
      await setDoc(doc(db, 'feedback_submissions', id), payload);
      return id;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  }
};
