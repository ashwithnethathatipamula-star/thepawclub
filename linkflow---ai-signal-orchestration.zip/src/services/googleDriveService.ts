import { getAccessToken } from './googleAuth';
import { detailsService } from './detailsService';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
  webContentLink?: string;
  iconLink?: string;
  thumbnailLink?: string;
  description?: string;
  isFolder?: boolean;
  owners?: Array<{ displayName: string; emailAddress: string; photoLink?: string }>;
}

export interface DriveStorageInfo {
  userName: string;
  userEmail: string;
  userPhoto?: string;
  usageBytes: number;
  limitBytes: number;
}

class GoogleDriveService {
  private async getAuthHeader(): Promise<string> {
    const token = await getAccessToken();
    if (!token) {
      throw new Error('Google Drive Access Token not found. Please sign in with Google first.');
    }
    return `Bearer ${token}`;
  }

  /**
   * Fetch Drive account & storage quota
   */
  async getAccountInfo(): Promise<DriveStorageInfo | null> {
    try {
      const authHeader = await this.getAuthHeader();
      const res = await fetch(
        'https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress,photoLink),storageQuota(limit,usage)',
        {
          headers: { Authorization: authHeader }
        }
      );

      if (!res.ok) {
        throw new Error(`Failed to fetch Drive about: ${res.statusText}`);
      }

      const data = await res.json();
      return {
        userName: data.user?.displayName || 'Google Drive User',
        userEmail: data.user?.emailAddress || '',
        userPhoto: data.user?.photoLink,
        usageBytes: Number(data.storageQuota?.usage || 0),
        limitBytes: Number(data.storageQuota?.limit || 0)
      };
    } catch (err) {
      console.error('Error getting Drive account info:', err);
      return null;
    }
  }

  /**
   * List files from Drive
   */
  async listFiles(options?: {
    folderId?: string;
    search?: string;
    pageSize?: number;
    mimeTypeFilter?: string;
  }): Promise<DriveFileItem[]> {
    const authHeader = await this.getAuthHeader();
    const queryParts: string[] = ['trashed = false'];

    if (options?.folderId) {
      queryParts.push(`'${options.folderId}' in parents`);
    }

    if (options?.search) {
      const escaped = options.search.replace(/'/g, "\\'");
      queryParts.push(`name contains '${escaped}'`);
    }

    if (options?.mimeTypeFilter) {
      queryParts.push(`mimeType = '${options.mimeTypeFilter}'`);
    }

    const q = queryParts.join(' and ');
    const pageSize = options?.pageSize || 30;

    const url = new URL('https://www.googleapis.com/drive/v3/files');
    url.searchParams.set('q', q);
    url.searchParams.set('pageSize', pageSize.toString());
    url.searchParams.set(
      'fields',
      'files(id, name, mimeType, size, createdTime, modifiedTime, webViewLink, webContentLink, iconLink, thumbnailLink, description, owners)'
    );
    url.searchParams.set('orderBy', 'folder desc, modifiedTime desc');

    const res = await fetch(url.toString(), {
      headers: { Authorization: authHeader }
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`Drive list failed (${res.status}): ${errorText}`);
    }

    const data = await res.json();
    return (data.files || []).map((f: any) => ({
      ...f,
      isFolder: f.mimeType === 'application/vnd.google-apps.folder'
    }));
  }

  /**
   * Create a folder in Google Drive
   */
  async createFolder(name: string, parentFolderId?: string): Promise<DriveFileItem> {
    const authHeader = await this.getAuthHeader();

    const metadata: Record<string, any> = {
      name,
      mimeType: 'application/vnd.google-apps.folder'
    };

    if (parentFolderId) {
      metadata.parents = [parentFolderId];
    }

    const res = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: authHeader,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(metadata)
    });

    if (!res.ok) {
      const error = await res.text();
      throw new Error(`Failed to create folder (${res.status}): ${error}`);
    }

    const data = await res.json();
    return { ...data, isFolder: true };
  }

  /**
   * Upload file to Google Drive using multipart upload
   */
  async uploadFile(
    name: string,
    content: string | Blob,
    mimeType: string,
    parentFolderId?: string,
    description?: string
  ): Promise<DriveFileItem> {
    const authHeader = await this.getAuthHeader();

    const metadata: Record<string, any> = {
      name,
      mimeType,
      description: description || 'Created by PawClub App'
    };

    if (parentFolderId) {
      metadata.parents = [parentFolderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    let fileContent: string;
    if (content instanceof Blob) {
      fileContent = await content.text();
    } else {
      fileContent = content;
    }

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      `Content-Type: ${mimeType}\r\n\r\n` +
      fileContent +
      closeDelimiter;

    const res = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,createdTime,modifiedTime,webViewLink,webContentLink',
      {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartRequestBody
      }
    );

    if (!res.ok) {
      const error = await res.text();
      throw new Error(`Failed to upload file (${res.status}): ${error}`);
    }

    return await res.json();
  }

  /**
   * Delete a file or folder from Google Drive
   * (Must always be guarded by a user confirmation modal before invoking)
   */
  async deleteFile(fileId: string): Promise<void> {
    const authHeader = await this.getAuthHeader();

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'DELETE',
      headers: { Authorization: authHeader }
    });

    if (!res.ok && res.status !== 204) {
      const error = await res.text();
      throw new Error(`Failed to delete file (${res.status}): ${error}`);
    }
  }

  /**
   * Helper to ensure the root "PawClub Pet Vault" folder exists
   */
  async getOrCreatePawClubFolder(): Promise<DriveFileItem> {
    const files = await this.listFiles({
      search: '🐾 PawClub Pet Vault',
      mimeTypeFilter: 'application/vnd.google-apps.folder'
    });

    const existing = files.find(f => f.name === '🐾 PawClub Pet Vault' && f.isFolder);
    if (existing) {
      return existing;
    }

    return await this.createFolder('🐾 PawClub Pet Vault');
  }

  /**
   * Generate & upload a Pet Medical & Vaccination Dossier to Google Drive
   */
  async savePetDossierToDrive(pet: {
    name: string;
    breed: string;
    age: string;
    gender: string;
    vaccinated: boolean;
    microchipped: boolean;
    healthChecked: boolean;
    pedigree: boolean;
    ownerOrSeller: string;
    contact: string;
  }, folderId?: string): Promise<DriveFileItem> {
    const details = detailsService.getDetails();
    const dossierMarkdown = `# 🐾 ${details.businessName.toUpperCase()} · OFFICIAL PET HEALTH & RECORD DOSSIER
Kennel & Boarding Center: ${details.location}
${details.role}: ${details.name} (Phone: ${details.formattedPhone})
Instagram: ${details.instagramOfficial}
Date Generated: ${new Date().toLocaleDateString('en-IN', { dateStyle: 'full' })}

---------------------------------------------------------
PET PROFILE:
- Pet Name: ${pet.name}
- Breed: ${pet.breed}
- Age: ${pet.age}
- Gender: ${pet.gender}
- Handler / Guardian: ${pet.ownerOrSeller}
- Emergency Contact: ${pet.contact}

HEALTH & VETERINARY STATUS:
- Vaccination Status: ${pet.vaccinated ? '✅ Fully Up-To-Date (Rabies, DHPP, Bordetella)' : '⚠️ Pending Vet Booster'}
- Microchip Registration: ${pet.microchipped ? '✅ Verified Chip Installed & Synced' : '❌ Unchipped'}
- Full Health Certification: ${pet.healthChecked ? '✅ Cleared by Licensed Veterinarian' : '⏳ In Review'}
- Official Pedigree Registration: ${pet.pedigree ? '✅ Certified Pedigree Papers Verified' : 'Standard Companion'}

CARE INSTRUCTIONS:
- Nutrition: High-protein balanced diet twice daily.
- Exercise: 45 min walk/play session daily at PawClub grounds.
- Boarding Notes: Socialized with calm dogs, supervised by ${details.name}.

Authorized Signature:
${details.name} — ${details.role}, ${details.businessName}
`;

    const fileName = `PawClub_${pet.name.replace(/\s+/g, '_')}_Health_Record.md`;
    return await this.uploadFile(
      fileName,
      dossierMarkdown,
      'text/markdown',
      folderId,
      `Official health dossier for ${pet.name} stored in PawClub Pet Vault`
    );
  }

  /**
   * Save Website & User Analytics Report to Google Drive
   */
  async saveAnalyticsReportToDrive(reportData: any, folderId?: string): Promise<DriveFileItem> {
    const jsonString = JSON.stringify(reportData, null, 2);
    const fileName = `PawClub_Analytics_Backup_${new Date().toISOString().split('T')[0]}.json`;

    return await this.uploadFile(
      fileName,
      jsonString,
      'application/json',
      folderId,
      'PawClub User Management & Analytics System Backup'
    );
  }
}

export const googleDriveService = new GoogleDriveService();
