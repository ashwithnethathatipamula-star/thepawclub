// IndexedDB persistent storage for starting page hero video

const DB_NAME = 'pawclub_video_db';
const STORE_NAME = 'hero_video_store';
const KEY = 'active_hero_video';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export interface VideoMetadata {
  name: string;
  size: number;
  type: string;
  uploadedAt: string;
}

class VideoStorageService {
  private currentObjectUrl: string | null = null;
  private listeners: Array<() => void> = [];

  subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  async saveCustomVideo(file: File): Promise<string> {
    const db = await openDB();
    const metadata: VideoMetadata = {
      name: file.name,
      size: file.size,
      type: file.type || 'video/mp4',
      uploadedAt: new Date().toISOString()
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.put({ blob: file, metadata }, KEY);
      tx.oncomplete = () => {
        if (this.currentObjectUrl) {
          URL.revokeObjectURL(this.currentObjectUrl);
        }
        this.currentObjectUrl = URL.createObjectURL(file);
        this.notify();
        resolve(this.currentObjectUrl);
      };
      tx.onerror = () => reject(tx.error);
    });
  }

  async getCustomVideo(): Promise<{ url: string; metadata: VideoMetadata } | null> {
    try {
      const db = await openDB();
      return new Promise((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.get(KEY);
        req.onsuccess = () => {
          if (req.result && req.result.blob) {
            if (this.currentObjectUrl) {
              URL.revokeObjectURL(this.currentObjectUrl);
            }
            this.currentObjectUrl = URL.createObjectURL(req.result.blob);
            resolve({
              url: this.currentObjectUrl,
              metadata: req.result.metadata
            });
          } else {
            resolve(null);
          }
        };
        req.onerror = () => resolve(null);
      });
    } catch {
      return null;
    }
  }

  async clearCustomVideo(): Promise<void> {
    try {
      const db = await openDB();
      return new Promise((resolve) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.delete(KEY);
        tx.oncomplete = () => {
          if (this.currentObjectUrl) {
            URL.revokeObjectURL(this.currentObjectUrl);
            this.currentObjectUrl = null;
          }
          this.notify();
          resolve();
        };
        tx.onerror = () => resolve();
      });
    } catch {
      // ignore
    }
  }
}

export const videoStorageService = new VideoStorageService();
