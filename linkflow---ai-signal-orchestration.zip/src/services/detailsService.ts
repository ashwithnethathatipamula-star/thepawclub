import { OwnerDetails } from '../types';

const STORAGE_KEY = 'pawclub_owner_details_v1';

export const DEFAULT_OWNER_DETAILS: OwnerDetails = {
  name: 'StoryByTech',
  email: 'storybytech07@gmail.com',
  phone: '9014508314',
  formattedPhone: '+91 9014508314',
  whatsapp: '919014508314',
  location: 'Kamareddy, India',
  businessName: 'THE PAWCLUB',
  role: 'Founder & Certified Trainer',
  experience: '4+ Yrs Experience',
  kennelType: 'Boarding & Training Kennel',
  specialization: 'Boarding & Training | 🐶 Exotic Pets',
  founderHandle: '@storybytech',
  instagramOfficial: '@thepawclub_2',
  bio: 'Certified obedience training, agility, luxury pet boarding, exotic companions, and premium nutrition.'
};

class DetailsService {
  private details: OwnerDetails;
  private listeners: Set<(d: OwnerDetails) => void> = new Set();

  constructor() {
    this.details = this.load();
  }

  private load(): OwnerDetails {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_OWNER_DETAILS, ...parsed };
      }
    } catch (e) {
      console.warn('Failed to load owner details from storage', e);
    }
    return { ...DEFAULT_OWNER_DETAILS };
  }

  public getDetails(): OwnerDetails {
    return { ...this.details };
  }

  public saveDetails(updated: Partial<OwnerDetails>): OwnerDetails {
    const cleanPhone = (updated.phone || this.details.phone).replace(/\D/g, '');
    const formatted = cleanPhone.length === 10 ? `+91 ${cleanPhone}` : (updated.formattedPhone || updated.phone || this.details.formattedPhone);
    const whatsappNum = cleanPhone.startsWith('91') ? cleanPhone : (cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone);

    this.details = {
      ...this.details,
      ...updated,
      phone: cleanPhone || updated.phone || this.details.phone,
      formattedPhone: formatted,
      whatsapp: whatsappNum || this.details.whatsapp
    };

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.details));
    } catch (e) {
      console.error('Failed to save owner details', e);
    }

    this.notify();
    return { ...this.details };
  }

  public resetToDefaults(): OwnerDetails {
    this.details = { ...DEFAULT_OWNER_DETAILS };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.details));
    } catch (e) {
      console.error('Failed to reset details', e);
    }
    this.notify();
    return { ...this.details };
  }

  public subscribe(listener: (d: OwnerDetails) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      listener(this.details);
    }
  }
}

export const detailsService = new DetailsService();
