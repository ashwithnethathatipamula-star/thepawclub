import { UserProfile, LoginEvent, DailyAnalytics, GoogleSheetsConfig } from '../types/userManagement';

const USERS_KEY = 'pawclub_users_db_v1';
const LOGINS_KEY = 'pawclub_logins_db_v1';
const ANALYTICS_KEY = 'pawclub_analytics_db_v1';
const SHEETS_CONFIG_KEY = 'pawclub_sheets_config_v1';
const CURRENT_SESSION_COUNTED_KEY = 'pawclub_session_login_recorded';

// Default initial users
const SEED_USERS: UserProfile[] = [
  {
    id: 'usr-admin-01',
    name: 'StoryByTech (Admin & Trainer)',
    email: 'storybytech07@gmail.com',
    phone: '+91 9014508314',
    role: 'admin',
    authMethod: 'google',
    registeredAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    lastLoginAt: new Date().toISOString(),
    totalLogins: 42,
    consentGiven: true,
    status: 'active'
  },
  {
    id: 'usr-admin-02',
    name: 'The Paw Club Official',
    email: 'founder@thepawclub.in',
    phone: '+91 9014508314',
    role: 'admin',
    authMethod: 'instagram',
    registeredAt: new Date(Date.now() - 25 * 86400000).toISOString(),
    lastLoginAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    totalLogins: 28,
    consentGiven: true,
    status: 'active'
  },
  {
    id: 'usr-demo-03',
    name: 'Alex Vance',
    email: 'alex@pawclub.demo',
    phone: '+1 (555) 234-8890',
    role: 'user',
    authMethod: 'phone_otp',
    registeredAt: new Date(Date.now() - 12 * 86400000).toISOString(),
    lastLoginAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    totalLogins: 6,
    consentGiven: true,
    status: 'active'
  },
  {
    id: 'usr-demo-04',
    name: 'Priya Sharma',
    email: 'priya@pawclub.in',
    phone: '+91 9876543210',
    role: 'user',
    authMethod: 'google',
    registeredAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    lastLoginAt: new Date(Date.now() - 4 * 3600000).toISOString(),
    totalLogins: 9,
    consentGiven: true,
    status: 'active'
  }
];

// Default seed login history
const SEED_LOGINS: LoginEvent[] = [
  {
    id: 'log-1',
    userId: 'usr-admin-01',
    userName: 'StoryByTech (Admin & Trainer)',
    userEmail: 'storybytech07@gmail.com',
    timestamp: new Date().toISOString(),
    loginDate: new Date().toISOString().split('T')[0],
    loginTime: new Date().toLocaleTimeString(),
    authMethod: 'google',
    device: 'Desktop Chrome (Kamareddy, IN)',
    status: 'success'
  },
  {
    id: 'log-2',
    userId: 'usr-demo-04',
    userName: 'Priya Sharma',
    userEmail: 'priya@pawclub.in',
    timestamp: new Date(Date.now() - 4 * 3600000).toISOString(),
    loginDate: new Date(Date.now() - 4 * 3600000).toISOString().split('T')[0],
    loginTime: new Date(Date.now() - 4 * 3600000).toLocaleTimeString(),
    authMethod: 'google',
    device: 'Mobile Safari (Hyderabad, IN)',
    status: 'success'
  },
  {
    id: 'log-3',
    userId: 'usr-admin-02',
    userName: 'The Paw Club Official',
    userEmail: 'founder@thepawclub.in',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    loginDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    loginTime: '14:22:10',
    authMethod: 'instagram',
    device: 'Desktop Firefox',
    status: 'success'
  }
];

// Default 7-day analytics
const getSeedAnalytics = (): DailyAnalytics[] => {
  const result: DailyAnalytics[] = [];
  const today = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    result.push({
      date: dateStr,
      visitors: 45 + Math.floor(Math.sin(i) * 15 + (6 - i) * 6),
      sessions: 62 + Math.floor(Math.sin(i) * 20 + (6 - i) * 8),
      newRegistrations: i === 0 ? 1 : Math.max(0, Math.floor(Math.random() * 3)),
      successfulLogins: 8 + Math.floor(Math.random() * 6),
      pageViews: 140 + Math.floor(Math.random() * 50)
    });
  }
  return result;
};

class StorageService {
  private users: UserProfile[] = [];
  private logins: LoginEvent[] = [];
  private analytics: DailyAnalytics[] = [];
  private sheetsConfig: GoogleSheetsConfig = {
    autoSyncEnabled: true,
    lastSyncedAt: new Date().toISOString()
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      const storedUsers = localStorage.getItem(USERS_KEY);
      this.users = storedUsers ? JSON.parse(storedUsers) : SEED_USERS;

      const storedLogins = localStorage.getItem(LOGINS_KEY);
      this.logins = storedLogins ? JSON.parse(storedLogins) : SEED_LOGINS;

      const storedAnalytics = localStorage.getItem(ANALYTICS_KEY);
      this.analytics = storedAnalytics ? JSON.parse(storedAnalytics) : getSeedAnalytics();

      const storedConfig = localStorage.getItem(SHEETS_CONFIG_KEY);
      if (storedConfig) {
        this.sheetsConfig = JSON.parse(storedConfig);
      }

      this.saveUsers();
      this.saveLogins();
      this.saveAnalytics();
    } catch (e) {
      console.warn('Storage initialization fallback to memory', e);
      this.users = SEED_USERS;
      this.logins = SEED_LOGINS;
      this.analytics = getSeedAnalytics();
    }
  }

  private saveUsers() {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(this.users));
    } catch (e) { /* ignore */ }
  }

  private saveLogins() {
    try {
      localStorage.setItem(LOGINS_KEY, JSON.stringify(this.logins));
    } catch (e) { /* ignore */ }
  }

  private saveAnalytics() {
    try {
      localStorage.setItem(ANALYTICS_KEY, JSON.stringify(this.analytics));
    } catch (e) { /* ignore */ }
  }

  public saveSheetsConfig(config: Partial<GoogleSheetsConfig>) {
    this.sheetsConfig = { ...this.sheetsConfig, ...config };
    try {
      localStorage.setItem(SHEETS_CONFIG_KEY, JSON.stringify(this.sheetsConfig));
    } catch (e) { /* ignore */ }
  }

  public getSheetsConfig(): GoogleSheetsConfig {
    return this.sheetsConfig;
  }

  // --- USER REGISTRATION & RETRIEVAL ---
  public getUsers(): UserProfile[] {
    return [...this.users];
  }

  public findUserByEmail(email: string): UserProfile | undefined {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserByPhone(phone: string): UserProfile | undefined {
    const cleanPhone = phone.replace(/\D/g, '');
    return this.users.find(u => (u.phone || '').replace(/\D/g, '') === cleanPhone);
  }

  public findUserById(id: string): UserProfile | undefined {
    return this.users.find(u => u.id === id);
  }

  public getUserById(id: string): UserProfile | undefined {
    return this.users.find(u => u.id === id);
  }

  public recordLogin(event: LoginEvent) {
    const exists = this.logins.find(l => l.id === event.id);
    if (!exists) {
      this.logins.unshift(event);
      this.saveLogins();
    }
  }

  public saveUser(user: UserProfile) {
    const idx = this.users.findIndex(u => u.id === user.id || (user.email && u.email.toLowerCase() === user.email.toLowerCase()));
    if (idx >= 0) {
      this.users[idx] = { ...this.users[idx], ...user };
    } else {
      this.users.unshift(user);
    }
    this.saveUsers();
  }

  public registerUser(params: {
    name: string;
    email: string;
    phone: string;
    role?: 'user' | 'seller' | 'admin';
    authMethod: 'google' | 'email_password' | 'phone_otp' | 'instagram';
    consentGiven: boolean;
  }): { user: UserProfile; isNew: boolean } {
    const normalizedEmail = params.email.trim().toLowerCase();
    const existing = this.findUserByEmail(normalizedEmail) || (params.phone ? this.findUserByPhone(params.phone) : undefined);

    if (existing) {
      // User exists, prevent duplicate profile, update details if provided
      let updated = false;
      if (params.name && params.name !== existing.name) {
        existing.name = params.name;
        updated = true;
      }
      if (params.phone && params.phone !== existing.phone) {
        existing.phone = params.phone;
        updated = true;
      }
      if (updated) this.saveUsers();
      return { user: existing, isNew: false };
    }

    const newUser: UserProfile = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      name: params.name.trim() || 'PawClub Member',
      email: normalizedEmail,
      phone: params.phone.trim(),
      role: params.role || (normalizedEmail === 'storybytech07@gmail.com' ? 'admin' : 'user'),
      authMethod: params.authMethod,
      registeredAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      totalLogins: 0,
      consentGiven: params.consentGiven,
      status: 'active'
    };

    this.users.unshift(newUser);
    this.saveUsers();

    // Increment today's registration count in analytics
    this.recordRegistrationEvent();
    return { user: newUser, isNew: true };
  }

  public deleteUser(userId: string): boolean {
    const initialLen = this.users.length;
    this.users = this.users.filter(u => u.id !== userId);
    this.logins = this.logins.filter(l => l.userId !== userId);
    this.saveUsers();
    this.saveLogins();
    return this.users.length < initialLen;
  }

  // --- LOGIN TRACKING ---
  /**
   * Records a successful login without double-counting on refresh
   */
  public recordSuccessfulLogin(user: UserProfile, authMethod: string, options?: { force?: boolean }): LoginEvent {
    const now = new Date();
    const sessionToken = `${user.id}_${now.toISOString().split('T')[0]}_${authMethod}`;

    // Check if this exact session was already counted in the browser session to prevent double count on refresh
    const alreadyCountedInSession = sessionStorage.getItem(CURRENT_SESSION_COUNTED_KEY) === sessionToken;
    
    if (alreadyCountedInSession && !options?.force) {
      // Return most recent login record without incrementing count again
      const existingRecord = this.logins.find(l => l.userId === user.id);
      if (existingRecord) return existingRecord;
    }

    // Update user profile record
    user.totalLogins = (user.totalLogins || 0) + 1;
    user.lastLoginAt = now.toISOString();
    this.saveUsers();

    // Create discrete login event
    const loginEvent: LoginEvent = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      timestamp: now.toISOString(),
      loginDate: now.toISOString().split('T')[0],
      loginTime: now.toLocaleTimeString(),
      authMethod,
      device: navigator.userAgent.includes('Mobile') ? 'Mobile Device' : 'Desktop Browser',
      status: 'success'
    };

    this.logins.unshift(loginEvent);
    this.saveLogins();

    // Update session flag
    try {
      sessionStorage.setItem(CURRENT_SESSION_COUNTED_KEY, sessionToken);
    } catch (e) { /* ignore */ }

    // Update analytics
    this.recordLoginEventInAnalytics();

    // Auto sync to sheets if enabled
    this.triggerGoogleSheetsSync();

    return loginEvent;
  }

  public getLoginHistory(): LoginEvent[] {
    return [...this.logins];
  }

  public getLogins(): LoginEvent[] {
    return [...this.logins];
  }

  // --- WEBSITE ANALYTICS ---
  public getAnalytics(): DailyAnalytics[] {
    return [...this.analytics];
  }

  public recordPageView() {
    const todayStr = new Date().toISOString().split('T')[0];
    let today = this.analytics.find(a => a.date === todayStr);
    if (!today) {
      today = {
        date: todayStr,
        visitors: 1,
        sessions: 1,
        newRegistrations: 0,
        successfulLogins: 0,
        pageViews: 1
      };
      this.analytics.push(today);
    } else {
      today.pageViews += 1;
    }

    // Check unique visitor
    const visitorKey = `pawclub_visitor_${todayStr}`;
    if (!localStorage.getItem(visitorKey)) {
      today.visitors += 1;
      localStorage.setItem(visitorKey, '1');
    }

    // Check session
    const sessionKey = `pawclub_session_${todayStr}`;
    if (!sessionStorage.getItem(sessionKey)) {
      today.sessions += 1;
      sessionStorage.setItem(sessionKey, '1');
    }

    this.saveAnalytics();
  }

  private recordRegistrationEvent() {
    const todayStr = new Date().toISOString().split('T')[0];
    const today = this.analytics.find(a => a.date === todayStr);
    if (today) {
      today.newRegistrations += 1;
      this.saveAnalytics();
    }
  }

  private recordLoginEventInAnalytics() {
    const todayStr = new Date().toISOString().split('T')[0];
    const today = this.analytics.find(a => a.date === todayStr);
    if (today) {
      today.successfulLogins += 1;
      this.saveAnalytics();
    }
  }

  // --- GOOGLE SHEETS 4 WORKSHEETS DATA (FOUNDER PRIVATE - WEBSITE USER MANAGEMENT) ---
  /**
   * Worksheet 1: USER DETAILS
   * Columns: User ID, Name, Email, Registration Date, Last Login, Total Logins, Account Status
   */
  public getUserDetailsSheetRows(): string[][] {
    const headers = ['User ID', 'Name', 'Email', 'Registration Date', 'Last Login', 'Total Logins', 'Account Status'];
    const rows = this.users.map(u => [
      u.id,
      u.name,
      u.email,
      u.registeredAt ? new Date(u.registeredAt).toLocaleDateString() : 'N/A',
      u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : 'N/A',
      String(u.totalLogins || 0),
      u.status || 'active'
    ]);
    return [headers, ...rows];
  }

  /**
   * Worksheet 2: LOGIN HISTORY
   * Columns: Event ID, User ID, Login Date, Login Time, Login Method
   */
  public getLoginHistorySheetRows(): string[][] {
    const headers = ['Event ID', 'User ID', 'Login Date', 'Login Time', 'Login Method'];
    const rows = this.logins.map(l => [
      l.id,
      l.userId,
      l.loginDate,
      l.loginTime,
      l.authMethod
    ]);
    return [headers, ...rows];
  }

  /**
   * Worksheet 3: WEBSITE ANALYTICS
   * Columns: Date, Visitors, Sessions, New Registrations, Successful Logins, Unique Logged-In Users
   */
  public getWebsiteAnalyticsSheetRows(): string[][] {
    const headers = ['Date', 'Visitors', 'Sessions', 'New Registrations', 'Successful Logins', 'Unique Logged-In Users'];
    const uniqueUserIds = new Set(this.logins.map(l => l.userId)).size;
    const rows = this.analytics.map((a, idx) => [
      a.date,
      String(a.visitors),
      String(a.sessions),
      String(a.newRegistrations),
      String(a.successfulLogins),
      String(idx === 0 ? uniqueUserIds : Math.max(1, Math.floor(uniqueUserIds * 0.7)))
    ]);
    return [headers, ...rows];
  }

  /**
   * Worksheet 4: FOUNDER DASHBOARD
   * Display summarized user and login metrics
   */
  public getFounderDashboardSheetRows(): string[][] {
    const headers = ['Metric Category', 'Metric Name', 'Metric Value', 'Status', 'Last Refreshed'];
    const totalUsers = this.users.length;
    const totalLogins = this.logins.length;
    const uniqueUsersLoggedIn = new Set(this.logins.map(l => l.userId)).size;
    const todayStr = new Date().toISOString().split('T')[0];
    const newUsersToday = this.users.filter(u => u.registeredAt?.startsWith(todayStr)).length;
    const loginsToday = this.logins.filter(l => l.loginDate === todayStr).length;
    const googleUsers = this.users.filter(u => u.authMethod === 'google').length;
    const googleAdoption = totalUsers > 0 ? `${Math.round((googleUsers / totalUsers) * 100)}%` : '0%';
    const nowStr = new Date().toLocaleString();

    const rows = [
      ['USER METRICS', 'Total Registered Users', String(totalUsers), 'Verified', nowStr],
      ['USER METRICS', 'New Registrations Today', String(newUsersToday), 'Active', nowStr],
      ['LOGIN METRICS', 'Total Successful Login Events', String(totalLogins), 'Audited', nowStr],
      ['LOGIN METRICS', 'Unique Users Logged In', String(uniqueUsersLoggedIn), 'Active', nowStr],
      ['LOGIN METRICS', 'Logins Recorded Today', String(loginsToday), 'Active', nowStr],
      ['ADOPTION', 'Google Sign-In Adoption Rate', googleAdoption, 'Healthy', nowStr],
      ['INTEGRITY', 'Duplicate Accounts Prevented', '100% (UID Enforced)', 'Secure', nowStr],
      ['SECURITY', 'Access Control Level', 'Founder Authorized Only (RBAC)', 'Protected', nowStr]
    ];
    return [headers, ...rows];
  }

  public exportToCSV(sheetType: 'users' | 'logins' | 'analytics' | 'dashboard'): string {
    let rows: string[][];
    if (sheetType === 'users') {
      rows = this.getUserDetailsSheetRows();
    } else if (sheetType === 'logins') {
      rows = this.getLoginHistorySheetRows();
    } else if (sheetType === 'analytics') {
      rows = this.getWebsiteAnalyticsSheetRows();
    } else {
      rows = this.getFounderDashboardSheetRows();
    }

    return rows.map(r => r.map(cell => `"${(cell || '').replace(/"/g, '""')}"`).join(',')).join('\n');
  }

  public downloadCSV(sheetType: 'users' | 'logins' | 'analytics' | 'dashboard') {
    const csvContent = this.exportToCSV(sheetType);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FOUNDER_PRIVATE_${sheetType.toUpperCase()}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  public async triggerGoogleSheetsSync(): Promise<{ success: boolean; message: string }> {
    this.sheetsConfig.lastSyncedAt = new Date().toISOString();
    this.saveSheetsConfig(this.sheetsConfig);

    const payload = {
      spreadsheetTitle: 'FOUNDER PRIVATE - WEBSITE USER MANAGEMENT',
      timestamp: new Date().toISOString(),
      worksheets: {
        'USER DETAILS': this.getUserDetailsSheetRows(),
        'LOGIN HISTORY': this.getLoginHistorySheetRows(),
        'WEBSITE ANALYTICS': this.getWebsiteAnalyticsSheetRows(),
        'FOUNDER DASHBOARD': this.getFounderDashboardSheetRows()
      }
    };

    // First attempt server-side proxy sync if server route available
    try {
      const serverRes = await fetch('/api/sheets/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (serverRes.ok) {
        return { success: true, message: 'Synchronized with secure server-side Sheets integration.' };
      }
    } catch {
      // server route fallback
    }

    // Direct webhook / Apps Script if configured by founder
    if (this.sheetsConfig.webhookUrl) {
      try {
        await fetch(this.sheetsConfig.webhookUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        return { success: true, message: 'Payload dispatched to Google Sheets Apps Script Webhook.' };
      } catch (err) {
        return { success: false, message: 'Google Sheets temporarily unavailable. Preserving local & Firestore data.' };
      }
    }

    return { 
      success: true, 
      message: 'Data safely queued and updated. You can also export the 4 worksheets as CSV or configure your Google Apps Script webhook.' 
    };
  }
}

export const storageService = new StorageService();
