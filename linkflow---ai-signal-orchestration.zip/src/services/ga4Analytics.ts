interface GA4Event {
  eventName: string;
  timestamp: string;
  params: Record<string, any>;
}

class GA4AnalyticsService {
  private measurementId: string = 'G-PAWCLUB2026';
  private initialized: boolean = false;
  private recentEvents: GA4Event[] = [];
  private consentGiven: boolean = true;

  constructor() {
    this.init();
  }

  public init(measurementId?: string) {
    if (measurementId) this.measurementId = measurementId;

    if (typeof window !== 'undefined' && !this.initialized) {
      // Setup window.dataLayer
      (window as any).dataLayer = (window as any).dataLayer || [];
      const gtag = (...args: any[]) => {
        (window as any).dataLayer.push(args);
      };
      (window as any).gtag = gtag;

      gtag('js', new Date());
      gtag('config', this.measurementId, {
        send_page_view: false, // Dispatched via privacy-safe custom page_view
        anonymize_ip: true
      });

      this.initialized = true;

      // Detect and record UTM or referral attribution
      this.detectCampaignParams();
    }
  }

  public setConsent(granted: boolean) {
    this.consentGiven = granted;
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('consent', 'update', {
        analytics_storage: granted ? 'granted' : 'denied'
      });
    }
    this.logEvent('consent_update', { analytics_consent: granted ? 'granted' : 'denied' });
  }

  private detectCampaignParams() {
    if (typeof window === 'undefined') return;
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const utmSource = urlParams.get('utm_source');
      const utmMedium = urlParams.get('utm_medium');
      const utmCampaign = urlParams.get('utm_campaign');
      const ref = urlParams.get('ref');

      if (utmSource || ref) {
        this.logEvent('campaign_attribution', {
          utm_source: utmSource || 'direct',
          utm_medium: utmMedium || 'none',
          utm_campaign: utmCampaign || 'general',
          referral_code: ref || 'none'
        });
      }
    } catch { /* ignore */ }
  }

  public trackPageView(pageTitle: string, path: string = window.location.pathname) {
    this.logEvent('page_view', {
      page_title: pageTitle,
      page_location: window.location.href,
      page_path: path
    });
  }

  /**
   * Tracks successful login WITHOUT any PII (no email, no phone, no real names).
   */
  public trackLogin(method: string, userType: string = 'member') {
    this.logEvent('login', {
      method: method, // 'google', 'phone_otp', 'email_password', 'instagram'
      user_type: userType,
      timestamp: Date.now()
    });
  }

  /**
   * Tracks user registration without PII
   */
  public trackSignUp(method: string) {
    this.logEvent('sign_up', {
      method: method
    });
  }

  public trackButtonClick(buttonName: string, location?: string) {
    this.logEvent('button_click', {
      button_name: buttonName,
      location: location || 'unknown'
    });
  }

  public trackContactFormSubmission(service?: string) {
    this.logEvent('contact_form_submit', {
      category: 'Lead Generation',
      service_type: service || 'General'
    });
  }

  public trackNewsletterSignup(source?: string) {
    this.logEvent('newsletter_opt_in', {
      category: 'Growth',
      source: source || 'footer'
    });
  }

  public trackFeedbackSubmission(rating: number) {
    this.logEvent('feedback_submitted', {
      rating: Math.round(rating)
    });
  }

  public trackConversion(conversionType: string, value?: number) {
    this.logEvent('conversion', {
      conversion_type: conversionType,
      value: value || 1
    });
  }

  public trackPetInteraction(action: 'view_pet' | 'contact_breeder' | 'filter_pets', petBreed?: string) {
    this.logEvent(action, {
      category: 'Pet Marketplace',
      breed: petBreed || 'unknown'
    });
  }

  public trackPetInquiry(petId: string, petBreed: string, price: number) {
    this.logEvent('inquiry_sent', {
      category: 'Pet Marketplace',
      item_id: petId,
      breed: petBreed,
      price: price
    });
  }

  public trackSupplyInteraction(action: 'view_supply' | 'order_whatsapp', supplyCategory?: string) {
    this.logEvent(action, {
      category: 'Pet Supplies',
      supply_category: supplyCategory || 'all'
    });
  }

  private logEvent(eventName: string, params: Record<string, any>) {
    // Sanitize any accidental PII from params (strict zero-PII guarantee)
    const sanitizedParams: Record<string, any> = {};
    for (const [key, val] of Object.entries(params)) {
      if (/email|phone|name|address|password|secret/i.test(key)) {
        continue; // Discard PII parameter
      }
      sanitizedParams[key] = val;
    }

    if (this.consentGiven && typeof window !== 'undefined' && (window as any).gtag) {
      try {
        (window as any).gtag('event', eventName, sanitizedParams);
      } catch (e) { /* ignore */ }
    }

    // Keep last 50 events in memory for live admin analytics inspector
    const evt: GA4Event = {
      eventName,
      timestamp: new Date().toLocaleTimeString(),
      params: sanitizedParams
    };
    this.recentEvents.unshift(evt);
    if (this.recentEvents.length > 50) this.recentEvents.pop();
  }

  public getRecentEvents(): GA4Event[] {
    return [...this.recentEvents];
  }

  public getMeasurementId(): string {
    return this.measurementId;
  }
}

export const ga4Service = new GA4AnalyticsService();
