import {
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
  signOut
} from 'firebase/auth';
import { auth, googleAuthProvider } from './firebase';
import { firestoreService } from './firestoreService';
import { storageService } from './storageService';
import { ga4Service } from './ga4Analytics';

export { auth };

export const DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/drive.metadata.readonly'
];

const driveProvider = new GoogleAuthProvider();
DRIVE_SCOPES.forEach(scope => driveProvider.addScope(scope));
driveProvider.setCustomParameters({
  prompt: 'consent',
  access_type: 'offline'
});

let isSigningIn = false;
let cachedAccessToken: string | null = null;
let currentGoogleUser: User | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token?: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    currentGoogleUser = user;
    if (user) {
      try {
        // Sync with Firestore profile & storageService
        const profile = await firestoreService.syncUserProfile(user);
        storageService.saveUser(profile);
      } catch (e) {
        console.warn('Profile sync in onAuthStateChanged:', e);
      }
      if (onAuthSuccess) {
        onAuthSuccess(user, cachedAccessToken || undefined);
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Standard Firebase Google Sign-In for website authentication.
 * Prompts Google account picker, syncs profile to Cloud Firestore,
 * records login event, and registers user session.
 */
export const googleSignIn = async (): Promise<{ user: User; profile: any } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleAuthProvider);
    const user = result.user;
    currentGoogleUser = user;

    // Synchronize user profile in Cloud Firestore
    const profile = await firestoreService.syncUserProfile(user);
    storageService.saveUser(profile);

    // Record login event in Firestore and storage service
    await firestoreService.recordLoginEvent(user, 'google', 'success');
    storageService.recordLogin({
      id: `log_${Date.now()}`,
      userId: user.uid,
      userEmail: user.email || 'N/A',
      userName: user.displayName || 'Member',
      timestamp: new Date().toISOString(),
      loginDate: new Date().toISOString().split('T')[0],
      loginTime: new Date().toTimeString().split(' ')[0],
      authMethod: 'google',
      device: typeof navigator !== 'undefined' ? (navigator.userAgent.includes('Mobile') ? 'Mobile Browser' : 'Desktop Browser') : 'Web',
      status: 'success'
    });

    // Track login in GA4 analytics (privacy-safe, no PII)
    ga4Service.trackLogin('google', profile.role || 'user');

    return { user, profile };
  } catch (error: any) {
    if (error?.code === 'auth/popup-closed-by-user') {
      console.info('Google Sign-In popup closed by user before completing authentication.');
      return null;
    }
    if (error?.code === 'auth/cancelled-popup-request') {
      return null;
    }
    console.error('Firebase Google Sign-In error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Enhanced sign-in with Google Drive Vault scopes
 */
export const googleSignInWithDrive = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, driveProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to obtain Google Drive OAuth access token from Firebase Auth');
    }

    cachedAccessToken = credential.accessToken;
    currentGoogleUser = result.user;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-In with Drive scopes error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const setManualAccessToken = (token: string) => {
  cachedAccessToken = token;
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const getCurrentGoogleUser = (): User | null => {
  return currentGoogleUser || auth.currentUser;
};

export const logoutGoogle = async () => {
  try {
    await signOut(auth);
  } catch (e) {
    console.warn('Sign out error:', e);
  }
  cachedAccessToken = null;
  currentGoogleUser = null;
};
