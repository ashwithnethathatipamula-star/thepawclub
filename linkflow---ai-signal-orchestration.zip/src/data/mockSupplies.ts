export interface PetSupplyItem {
  id: string;
  name: string;
  category: 'Nutrition' | 'Training Gear' | 'Grooming & Health' | 'Comfort & Beds' | 'Exotic Pets';
  priceINR: number;
  priceUSD: number;
  rating: number;
  imageUrl: string;
  description: string;
  inStock: boolean;
  tag?: string;
}

export const PET_SUPPLIES: PetSupplyItem[] = [
  {
    id: 'sup-1',
    name: 'Royal Canine Pro Golden & Lab Kibble (12kg)',
    category: 'Nutrition',
    priceINR: 4850,
    priceUSD: 58,
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?auto=format&fit=crop&w=700&q=80',
    description: 'High-protein, veterinarian-recommended formula fortified with DHA and glucosamine for hip & joint strength.',
    inStock: true,
    tag: 'Bestseller'
  },
  {
    id: 'sup-2',
    name: 'Pro Tactical No-Pull Training Harness & Leash',
    category: 'Training Gear',
    priceINR: 1499,
    priceUSD: 18,
    rating: 5.0,
    imageUrl: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?auto=format&fit=crop&w=700&q=80',
    description: 'Tested and certified by trainer Mr. Sai. Heavy-duty military nylon with padded chest plate and reflective 3M stitching.',
    inStock: true,
    tag: 'Trainer Choice'
  },
  {
    id: 'sup-3',
    name: 'Organic Neem & Oatmeal Herbal Dog Wash (500ml)',
    category: 'Grooming & Health',
    priceINR: 650,
    priceUSD: 8,
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1583511655826-05700d52f4d9?auto=format&fit=crop&w=700&q=80',
    description: '100% natural Ayurvedic tick and flea repelling shampoo. Soothes itchy skin and enhances glossy fur shine.',
    inStock: true,
    tag: 'Ayurvedic'
  },
  {
    id: 'sup-4',
    name: 'Orthopedic Memory Foam Pet Bed (Large/XL)',
    category: 'Comfort & Beds',
    priceINR: 3200,
    priceUSD: 39,
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1541599540903-216a46ca1dc0?auto=format&fit=crop&w=700&q=80',
    description: 'Premium dual-layer orthopedic foam bed with waterproof plush washable cover for deep joint relief.',
    inStock: true,
    tag: 'Comfort'
  },
  {
    id: 'sup-5',
    name: 'Agility Clicker & Treat Pouch Kit',
    category: 'Training Gear',
    priceINR: 799,
    priceUSD: 10,
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?auto=format&fit=crop&w=700&q=80',
    description: 'Essential behavior conditioning tools for positive reinforcement used in PawClub Kamareddy training classes.',
    inStock: true,
    tag: 'Essential'
  },
  {
    id: 'sup-6',
    name: 'Exotic Birds & Reptiles Fortified Blend (1kg)',
    category: 'Exotic Pets',
    priceINR: 1250,
    priceUSD: 15,
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1452570053594-1b985d6ea890?auto=format&fit=crop&w=700&q=80',
    description: 'Enriched seed, fruit, and calcium blend designed specifically for exotic birds, parrots, and pocket pets.',
    inStock: true,
    tag: 'Exotic'
  },
  {
    id: 'sup-7',
    name: 'Indestructible Natural Rubber Fetch & Chew Toy',
    category: 'Comfort & Beds',
    priceINR: 599,
    priceUSD: 7,
    rating: 5.0,
    imageUrl: 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=700&q=80',
    description: 'Durable non-toxic natural rubber ball designed for heavy chewers like Labradors and German Shepherds.',
    inStock: true,
    tag: 'High Durability'
  },
  {
    id: 'sup-8',
    name: 'Anti-Tick & Flea Herbal Collar (8-Month Protection)',
    category: 'Grooming & Health',
    priceINR: 890,
    priceUSD: 11,
    rating: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1568640347023-a616a30bc3bd?auto=format&fit=crop&w=700&q=80',
    description: 'Water-resistant, plant-based essential oil infused collar for 24/7 protection against pests in outdoor boarding.',
    inStock: true,
    tag: 'Protection'
  }
];
