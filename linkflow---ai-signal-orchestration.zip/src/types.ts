export interface PetListing {
  id: string;
  name: string;
  type: 'dog' | 'cat' | 'bird' | 'other';
  breed: string;
  age: string;
  gender: 'Male' | 'Female';
  price: number;
  location: string;
  imageUrl: string;
  vaccinated: boolean;
  microchipped: boolean;
  healthChecked: boolean;
  pedigree: boolean;
  description: string;
  sellerName: string;
  sellerPhone: string;
  sellerRating: number;
  sellerVerified: boolean;
  createdAt: string;
}

export interface UserSession {
  id?: string;
  name: string;
  phone: string;
  email?: string;
  role: 'buyer' | 'seller' | 'admin';
  avatar?: string;
  authMethod?: string;
  savedPets: string[];
}

export interface OwnerDetails {
  name: string;
  email: string;
  phone: string;
  formattedPhone: string;
  whatsapp: string;
  location: string;
  businessName: string;
  role: string;
  experience: string;
  kennelType: string;
  specialization: string;
  founderHandle: string;
  instagramOfficial: string;
  bio?: string;
}
