import React, { useRef, useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface Props {
  videoSrc: string;
  onEnter: () => void;
  brandName?: string;
  location?: string;
  trainerInfo?: string;
}

export default function OpeningIntroScreen({
  videoSrc,
  onEnter,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isEntering, setIsEntering] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  // Auto-play the plain intro video immediately
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = isMuted;
    const playPromise = video.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        // Browser autoplay policy requires muted
        video.muted = true;
        setIsMuted(true);
        video.play().catch(() => {});
      });
    }
  }, [videoSrc]);

  // Transition to main website interface smoothly
  const handleEnterWebsite = () => {
    if (isEntering) return;
    setIsEntering(true);
    setTimeout(() => {
      onEnter();
    }, 600);
  };

  // Keyboard shortcut: Esc / Space / Enter skips to interface
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        handleEnterWebsite();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // When intro video ends, automatically open the website interface
  const handleVideoEnded = () => {
    handleEnterWebsite();
  };

  // Safety fallback: if video errors, proceed to interface
  const handleVideoError = () => {
    handleEnterWebsite();
  };

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    const nextMuted = !videoRef.current.muted;
    videoRef.current.muted = nextMuted;
    setIsMuted(nextMuted);
    if (!nextMuted && videoRef.current.paused) {
      videoRef.current.play().catch(() => {});
    }
  };

  return (
    <div 
      onClick={handleEnterWebsite}
      className={`fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden cursor-pointer select-none transition-all duration-700 ease-in-out ${
        isEntering ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
      title="Intro video playing · Click anywhere to skip to website"
    >
      {/* Pure Plain Video without any overlays or bottom bar */}
      <video
        ref={videoRef}
        key={videoSrc}
        src={videoSrc}
        className="w-full h-full object-cover"
        autoPlay
        playsInline
        muted={isMuted}
        onEnded={handleVideoEnded}
        onError={handleVideoError}
        preload="auto"
      >
        <source src={videoSrc} type="video/mp4" />
        <source src="/INTRO.mp4" type="video/mp4" />
        <source src="/Scene-ezremove.mp4" type="video/mp4" />
        <source src="/intro.mp4" type="video/mp4" />
      </video>

      {/* Minimal Unobtrusive Controls in top corner */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2 opacity-50 hover:opacity-100 transition-opacity duration-200">
        <button
          onClick={toggleSound}
          className="p-2 rounded-full bg-black/40 hover:bg-black/75 text-white/80 hover:text-white backdrop-blur-md transition-all border border-white/10"
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            handleEnterWebsite();
          }}
          className="px-3 py-1 rounded-full bg-black/40 hover:bg-black/75 text-white/80 hover:text-white text-xs font-semibold backdrop-blur-md transition-all border border-white/10"
          title="Skip intro and open website"
        >
          Skip &rsaquo;
        </button>
      </div>
    </div>
  );
}
