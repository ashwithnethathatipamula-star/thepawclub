import React from 'react';
import './CapybaraLoader.css';

interface CapybaraLoaderProps {
  scale?: number;
  message?: string;
  submessage?: string;
  className?: string;
  color?: string;
  color2?: string;
}

export const CapybaraLoader: React.FC<CapybaraLoaderProps> = ({
  scale = 0.75,
  message,
  submessage,
  className = '',
  color,
  color2,
}) => {
  const customStyles: React.CSSProperties = {
    transform: `scale(${scale})`,
    ...(color ? { ['--color' as any]: color } : {}),
    ...(color2 ? { ['--color2' as any]: color2 } : {}),
  };

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className="capybaraloader" style={customStyles}>
        <div className="capybara">
          <div className="capyhead">
            <div className="capyear">
              <div className="capyear2" />
            </div>
            <div className="capyear" />
            <div className="capymouth">
              <div className="capylips" />
              <div className="capylips" />
            </div>
            <div className="capyeye" />
            <div className="capyeye" />
          </div>
          <div className="capyleg" />
          <div className="capyleg2" />
          <div className="capyleg2" />
          <div className="capy" />
        </div>
        <div className="loader">
          <div className="loaderline" />
        </div>
      </div>

      {message && (
        <p className="mt-3 text-sm font-bold text-amber-300 tracking-wide text-center drop-shadow">
          {message}
        </p>
      )}
      {submessage && (
        <p className="text-xs text-amber-100/70 text-center mt-0.5">
          {submessage}
        </p>
      )}
    </div>
  );
};

export default CapybaraLoader;
