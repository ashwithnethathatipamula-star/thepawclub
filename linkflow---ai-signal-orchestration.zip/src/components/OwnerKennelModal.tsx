import { useState, useEffect } from 'react';
import { 
  X, MapPin, Award, Clock, Phone, Instagram, MessageCircle, 
  ShieldCheck, Sparkles, ExternalLink, Heart, Edit3, Mail 
} from 'lucide-react';
import { OwnerDetails } from '../types';
import { detailsService } from '../services/detailsService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenSupplies: () => void;
  onOpenMarketplace: () => void;
  onOpenEditDetails?: () => void;
  isOwnerOrFounder?: boolean;
}

export const OWNER_DETAILS = detailsService.getDetails();

export default function OwnerKennelModal({ 
  isOpen, 
  onClose, 
  onOpenSupplies, 
  onOpenMarketplace,
  onOpenEditDetails,
  isOwnerOrFounder = false
}: Props) {
  const [details, setDetails] = useState<OwnerDetails>(detailsService.getDetails());

  useEffect(() => {
    const unsub = detailsService.subscribe((updated) => {
      setDetails(updated);
    });
    setDetails(detailsService.getDetails());
    return unsub;
  }, []);

  if (!isOpen) return null;

  const founderIgClean = details.founderHandle.replace('@', '');
  const officialIgClean = details.instagramOfficial.replace('@', '');
  const founderIgUrl = founderIgClean ? `https://instagram.com/${founderIgClean}` : '#';
  const officialIgUrl = officialIgClean ? `https://instagram.com/${officialIgClean}` : '#';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/75 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Banner with Warm Gradient */}
        <div className="relative bg-gradient-to-r from-[#2a170d] via-[#3d2012] to-[#78350f] p-6 sm:p-8 text-white">
          <div className="absolute top-5 right-5 flex items-center gap-2">
            {isOwnerOrFounder && onOpenEditDetails && (
              <button
                onClick={() => {
                  onClose();
                  onOpenEditDetails();
                }}
                className="px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 text-amber-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-white/20"
                title="Replace details with your own"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit My Details</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Verified Owner & Master Kennel Profile
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 p-0.5 shadow-xl flex-shrink-0">
              <div className="w-full h-full bg-[#2a170d] rounded-2xl flex items-center justify-center text-3xl font-extrabold text-amber-300">
                🐾
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                  {details.businessName || 'THE PAWCLUB'}
                </h2>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full">
                  <ShieldCheck className="w-3 h-3" /> Certified
                </span>
              </div>
              <p className="text-amber-200/90 text-sm font-medium mt-0.5">
                {details.specialization}
              </p>
              <div className="flex items-center gap-3 text-xs text-white/80 mt-2 flex-wrap">
                <span className="flex items-center gap-1 font-semibold text-amber-300">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" /> {details.location}
                </span>
                <span className="flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" /> {details.role}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" /> {details.experience}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 bg-[#fdfbf9]">
          
          {/* Founder & Official Handles Card */}
          <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-700" /> Founder & Kennel Leadership
              </h3>
              {isOwnerOrFounder && onOpenEditDetails && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenEditDetails();
                  }}
                  className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 cursor-pointer"
                >
                  <Edit3 className="w-3 h-3" /> Customize
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Founder */}
              <div className="bg-white p-3.5 rounded-xl border border-amber-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Founder / Owner</span>
                  <span className="text-sm font-extrabold text-[#2a170d]">{details.name}</span>
                  {details.founderHandle && (
                    <a
                      href={founderIgUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1 mt-0.5"
                    >
                      <Instagram className="w-3 h-3" /> {details.founderHandle}
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  )}
                  {details.email && (
                    <span className="text-[11px] text-gray-500 flex items-center gap-1 mt-0.5 font-medium">
                      <Mail className="w-2.5 h-2.5 text-gray-400" /> {details.email}
                    </span>
                  )}
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                    {details.role.includes('Trainer') ? 'Lead Trainer' : 'Owner'}
                  </span>
                </div>
              </div>

              {/* Official Instagram Page */}
              <div className="bg-white p-3.5 rounded-xl border border-amber-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Official Instagram</span>
                  <span className="text-sm font-extrabold text-[#2a170d]">{details.businessName}</span>
                  {details.instagramOfficial && (
                    <a
                      href={officialIgUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold text-pink-600 hover:text-pink-700 flex items-center gap-1 mt-0.5"
                    >
                      <Instagram className="w-3 h-3" /> {details.instagramOfficial}
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  )}
                </div>
                <span className="text-[11px] font-bold bg-pink-50 text-pink-700 border border-pink-200 px-2 py-0.5 rounded-full">
                  Official Page
                </span>
              </div>
            </div>

            {/* Main Phone Number Action Bar */}
            <div className="mt-3.5 bg-gradient-to-r from-[#1f1208] to-[#3a1d0f] text-white p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-300 block">Official Main Phone / WhatsApp</span>
                <span className="text-lg sm:text-xl font-extrabold tracking-wide text-white">{details.phone}</span>
                <span className="text-[11px] text-white/70 block">{details.location} · Direct Founder Contact</span>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href={`tel:${details.phone}`}
                  className="flex-1 sm:flex-none px-4 py-2 bg-amber-500 hover:bg-amber-600 text-amber-950 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow"
                >
                  <Phone className="w-3.5 h-3.5" /> Call Now
                </a>
                <a
                  href={`https://wa.me/${details.whatsapp}?text=Hello%20${encodeURIComponent(details.name)},%20I%20am%20inquiring%20about%20${encodeURIComponent(details.businessName)}%20Boarding,%20Training%20or%20Pet%20Supplies.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-none px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                </a>
              </div>
            </div>
          </div>

          {/* Core Services Offered */}
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-gray-500 mb-3">
              Services & Specialties in {details.location}
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-sm">
                <div className="text-2xl mb-1.5">🏡</div>
                <h4 className="text-sm font-bold text-gray-900">Boarding Kennel</h4>
                <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                  24/7 climate-controlled, hygienic boarding with individualized meal schedules and open play runs.
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-sm">
                <div className="text-2xl mb-1.5">🦮</div>
                <h4 className="text-sm font-bold text-gray-900">Certified Training</h4>
                <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                  Led by certified trainer with {details.experience}: obedience, leash mannerisms, agility & K9 training.
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-sm">
                <div className="text-2xl mb-1.5">🦜</div>
                <h4 className="text-sm font-bold text-gray-900">Exotic Pets Wing</h4>
                <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                  Specialized care, nutrition blends, and ethical rehoming for exotic birds, bunnies, and unique companions.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Navigation Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={() => { onClose(); onOpenSupplies(); }}
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow"
            >
              🥩 Browse Pet Supplies & Nutrition
            </button>
            <button
              onClick={() => { onClose(); onOpenMarketplace(); }}
              className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-[#2a170d] hover:bg-[#3d2012] text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow"
            >
              🐾 View Pets for Sale & Rehoming
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
