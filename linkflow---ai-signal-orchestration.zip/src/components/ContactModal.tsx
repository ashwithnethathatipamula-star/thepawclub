import { useState } from 'react';
import { X, Send, Phone, Mail, MapPin, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { firestoreService } from '../services/firestoreService';
import { ga4Service } from '../services/ga4Analytics';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  defaultService?: string;
}

export default function ContactModal({ isOpen, onClose, defaultService = 'Boarding & Training' }: Props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState(defaultService);
  const [message, setMessage] = useState('');
  const [honeypot, setHoneypot] = useState(''); // Anti-spam trap
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Honeypot check
    if (honeypot) {
      return; // Silently reject bots
    }

    if (!name.trim() || !email.trim() || !message.trim()) {
      setErrorMsg('Please complete all required fields (Name, Email, Message).');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Submit to server endpoint
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, service, message, honeypot })
      }).catch(() => null);

      // 2. Submit to Cloud Firestore
      await firestoreService.saveContactSubmission({
        name,
        email,
        phone,
        service,
        message
      });

      // 3. Track GA4 event without PII
      ga4Service.trackContactFormSubmission(service);

      setSubmitted(true);
      setTimeout(() => {
        setName('');
        setEmail('');
        setPhone('');
        setMessage('');
        setSubmitted(false);
        onClose();
      }, 2500);
    } catch (err: any) {
      setErrorMsg('Something went wrong. Please try calling directly or try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 flex flex-col">
        {/* Header */}
        <div className="p-6 bg-[#2a170d] text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold text-amber-400 uppercase tracking-widest block">
              Official Kennel Support
            </span>
            <h2 className="text-lg font-black text-white mt-0.5">Contact The PawClub</h2>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="py-10 text-center space-y-3 animate-in zoom-in-95">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="text-lg font-black text-gray-900">Inquiry Received!</h3>
              <p className="text-xs text-gray-600 max-w-sm mx-auto">
                Thank you! Our head trainer in Kamareddy will get back to you within 2 hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Anti-spam hidden field */}
              <input 
                type="text" 
                name="company_website_url" 
                value={honeypot} 
                onChange={(e) => setHoneypot(e.target.value)} 
                tabIndex={-1} 
                autoComplete="off" 
                className="hidden" 
              />

              <div>
                <label className="block text-xs font-bold text-gray-800 mb-1">Your Full Name *</label>
                <input 
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-800 mb-1">Email Address *</label>
                  <input 
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@gmail.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-800 mb-1">Phone Number (Optional)</label>
                  <input 
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 90145 08314"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-800 mb-1">Service Inquired *</label>
                <select
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                >
                  <option value="Boarding & Training">Dog Boarding & Hostel Facility (Kamareddy)</option>
                  <option value="Puppy Training">Obedience & Protection Dog Training</option>
                  <option value="Pet Adoption">Puppies & Exotic Pets Showcase</option>
                  <option value="Supplies & Food">Pet Supplies, Meat & Nutritional Food</option>
                  <option value="General Inquiry">General Kennel Question</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-800 mb-1">Message or Requirements *</label>
                <textarea 
                  rows={3}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us about your pet, dates needed for boarding, or training requirements..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden resize-none"
                />
              </div>

              {errorMsg && (
                <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-xl">{errorMsg}</p>
              )}

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-gray-500 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Secure SSL & Spam Protected
                </span>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-extrabold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-sm transition-all"
                >
                  <Send className="w-3.5 h-3.5 text-amber-400" />
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </button>
              </div>
            </form>
          )}

          {/* Quick Direct Contacts */}
          <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-gray-600">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-amber-700" /> Kamareddy, Telangana
            </span>
            <a href="tel:9014508314" className="font-extrabold text-amber-900 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-amber-700" /> Call: 9014508314
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
