import { useState, useEffect } from 'react';
import { X, Search, ShoppingBag, Phone, MessageCircle, Star, Sparkles, CheckCircle2, Tag } from 'lucide-react';
import { PET_SUPPLIES, PetSupplyItem } from '../data/mockSupplies';
import { detailsService } from '../services/detailsService';
import { OwnerDetails } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenOwner: () => void;
}

export default function PetSuppliesModal({ isOpen, onClose, onOpenOwner }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [orderedItem, setOrderedItem] = useState<PetSupplyItem | null>(null);
  const [details, setDetails] = useState<OwnerDetails>(detailsService.getDetails());

  useEffect(() => {
    const unsub = detailsService.subscribe((updated) => setDetails(updated));
    setDetails(detailsService.getDetails());
    return unsub;
  }, []);

  if (!isOpen) return null;

  const categories = ['All', 'Nutrition', 'Training Gear', 'Grooming & Health', 'Comfort & Beds', 'Exotic Pets'];

  const filteredSupplies = PET_SUPPLIES.filter((item) => {
    const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleQuickOrder = (item: PetSupplyItem) => {
    const message = encodeURIComponent(
      `Hello ${details.name} (${details.founderHandle || details.businessName}), I would like to order "${item.name}" (₹${item.priceINR}) from ${details.businessName} ${details.location}.`
    );
    window.open(`https://wa.me/${details.whatsapp}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/75 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#2a170d] via-[#432313] to-[#854d0e] p-6 text-white flex items-center justify-between border-b border-amber-700/30">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/30 text-xs font-bold text-amber-200 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              {details.businessName} Pet Supplies & Pantry · {details.location}
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Curated Supplies, Training Gear & Nutrition
            </h2>
            <p className="text-xs text-amber-100/80 mt-0.5">
              Tested & recommended by {details.role} {details.name} (📞 {details.phone}). Fast delivery in {details.location}.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenOwner}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 text-xs font-bold text-amber-200 transition-colors"
            >
              Kennel & Trainer Info
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        {/* Search & Categories Bar */}
        <div className="p-4 sm:p-6 bg-[#fbf9f6] border-b border-amber-100/80 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-amber-900/40 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search kibble, harnesses, tick spray, beds, exotic diets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-amber-200/90 text-xs sm:text-sm bg-white focus:border-amber-600 outline-none"
            />
          </div>

          <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#2a170d] text-amber-300 shadow-sm'
                    : 'bg-white text-gray-700 border border-amber-200/60 hover:bg-amber-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Supplies Grid */}
        <div className="p-4 sm:p-6 md:p-8 overflow-y-auto flex-1 bg-[#faf8f5]">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {filteredSupplies.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-amber-200/70 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col justify-between group"
              >
                <div>
                  <div className="relative aspect-square w-full overflow-hidden bg-amber-50/50">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    {item.tag && (
                      <span className="absolute top-2.5 left-2.5 bg-[#2a170d]/90 text-amber-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-sm">
                        {item.tag}
                      </span>
                    )}
                    <span className="absolute bottom-2.5 right-2.5 bg-white/90 backdrop-blur-sm text-xs font-bold text-gray-800 px-2 py-0.5 rounded-md flex items-center gap-0.5 shadow-sm">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {item.rating}
                    </span>
                  </div>

                  <div className="p-4">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800/80 block">
                      {item.category}
                    </span>
                    <h3 className="text-sm font-bold text-gray-900 mt-0.5 leading-snug group-hover:text-amber-800 transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-xs text-gray-600 mt-1.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="p-4 pt-0">
                  <div className="flex items-center justify-between mb-3 border-t border-gray-100 pt-2.5">
                    <div>
                      <span className="text-base font-extrabold text-[#2a170d]">₹{item.priceINR}</span>
                      <span className="text-[11px] text-gray-400 font-medium ml-1.5">(${item.priceUSD})</span>
                    </div>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold">
                      In Stock
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleQuickOrder(item)}
                      className="py-2 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-sm"
                    >
                      <MessageCircle className="w-3 h-3" /> WhatsApp
                    </button>
                    <a
                      href={`tel:${details.phone}`}
                      className="py-2 px-2 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1 shadow-sm"
                    >
                      <Phone className="w-3 h-3" /> Call Shop
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom Support Banner with Main Phone */}
          <div className="mt-8 bg-gradient-to-r from-amber-900 to-[#2a170d] rounded-2xl p-5 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
            <div>
              <h4 className="text-base font-bold text-amber-200">Need Custom Pet Diets or Bulk Boarding Supplies?</h4>
              <p className="text-xs text-white/80 mt-0.5">
                Speak directly with {details.role} {details.name} in {details.location}.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <a
                href={`tel:${details.phone}`}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-amber-950 font-extrabold text-xs rounded-xl transition-colors flex items-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5" /> Call: {details.phone}
              </a>
              <a
                href={`https://instagram.com/${details.instagramOfficial.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-white/15 hover:bg-white/25 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5"
              >
                {details.instagramOfficial}
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
