import { useState, useEffect } from 'react';
import { 
  X, Phone, Mail, Lock, User, CheckCircle2, Eye, EyeOff, 
  ShieldCheck, Sparkles, MessageCircle, Instagram, ExternalLink,
  ChevronDown, AlertCircle, Info, Trash2
} from 'lucide-react';
import { UserSession } from '../types';
import { storageService } from '../services/storageService';
import { detailsService } from '../services/detailsService';
import { ga4Service } from '../services/ga4Analytics';
import { googleSignIn } from '../services/googleAuth';
import CapybaraLoader from './CapybaraLoader';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (session: UserSession) => void;
  initialMode?: 'login' | 'signup';
}

const COUNTRY_CODES = [
  { code: '+91', country: 'India', flag: '🇮🇳' },
  { code: '+1', country: 'US / Canada', flag: '🇺🇸' },
  { code: '+44', country: 'United Kingdom', flag: '🇬🇧' },
  { code: '+61', country: 'Australia', flag: '🇦🇺' },
  { code: '+971', country: 'UAE', flag: '🇦🇪' },
  { code: '+49', country: 'Germany', flag: '🇩🇪' },
  { code: '+65', country: 'Singapore', flag: '🇸🇬' },
];

export default function AuthModal({ isOpen, onClose, onLoginSuccess, initialMode = 'login' }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [method, setMethod] = useState<'google' | 'phone' | 'email' | 'instagram'>('phone');
  
  // Google sign in states
  const [googleEmail, setGoogleEmail] = useState('');
  const [googleName, setGoogleName] = useState('');
  const [showGoogleAccountPicker, setShowGoogleAccountPicker] = useState(false);

  // Phone credentials
  const [countryCode, setCountryCode] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [useOtp, setUseOtp] = useState(true);
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [viaWhatsApp, setViaWhatsApp] = useState(true);
  
  // Instagram credentials
  const [instagramHandle, setInstagramHandle] = useState('@thepawclub_2');
  
  // General credentials
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [userRole, setUserRole] = useState<'buyer' | 'seller'>('buyer');
  const [rememberMe, setRememberMe] = useState(true);
  const [consentGiven, setConsentGiven] = useState(true);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showDeleteRequest, setShowDeleteRequest] = useState(false);
  const [deleteEmail, setDeleteEmail] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successToast, setSuccessToast] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyingText, setVerifyingText] = useState('Verifying credentials...');

  useEffect(() => {
    setMode(initialMode);
    setErrorMsg('');
    setSuccessToast('');
  }, [initialMode, isOpen]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((t) => t - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  if (!isOpen) return null;

  const handleSendOtp = () => {
    if (!phoneNumber || phoneNumber.replace(/\D/g, '').length < 7) {
      setErrorMsg('Please enter a valid phone number (at least 7 digits)');
      return;
    }
    setErrorMsg('');
    setOtpSent(true);
    setOtpTimer(30);
    setSuccessToast(`Verification code sent via ${viaWhatsApp ? 'WhatsApp' : 'SMS'} to ${countryCode} ${phoneNumber}! (Use demo code: 778899)`);
    setOtpCode('778899');
  };

  const handleDirectFirebaseGoogleSignIn = async () => {
    setErrorMsg('');
    setIsVerifying(true);
    setVerifyingText('Opening Google Sign-In...');
    try {
      const res = await googleSignIn();
      if (!res) {
        setIsVerifying(false);
        return; // User cancelled popup
      }

      const { user, profile } = res;
      const isFounder = user.email?.toLowerCase() === 'storybytech07@gmail.com' || user.email?.toLowerCase() === 'founder@thepawclub.in';
      const session: UserSession = {
        id: user.uid,
        name: user.displayName || profile.name || 'PawClub Member',
        phone: profile.phone || (isFounder ? '+91 9014508314' : ''),
        email: user.email || undefined,
        role: isFounder ? 'admin' : (profile.role === 'admin' ? 'admin' : profile.role === 'seller' ? 'seller' : 'buyer'),
        avatar: user.photoURL || profile.avatarUrl || undefined,
        authMethod: 'google',
        savedPets: []
      };

      setSuccessToast(`Welcome, ${session.name}! Signed in with Google.`);
      setTimeout(() => {
        setIsVerifying(false);
        onLoginSuccess(session);
        onClose();
      }, 500);
    } catch (err: any) {
      setIsVerifying(false);
      console.error('Google Sign-In Error:', err);
      if (err?.code === 'auth/unauthorized-domain') {
        setErrorMsg('Domain authorization required: please add your app domain to Firebase Console > Authentication > Settings > Authorized domains. In the meantime, you may use quick demo accounts.');
      } else if (err?.code === 'auth/operation-not-allowed') {
        setErrorMsg('Google Sign-In provider is disabled in Firebase. Enable Google in Firebase Console > Authentication > Sign-in method.');
      } else {
        setErrorMsg(err?.message || 'Google Sign-In encountered an issue. Please try again or use phone verification.');
      }
    }
  };

  const handleGoogleSignIn = (selectedEmail?: string, selectedName?: string, role: 'admin' | 'user' | 'seller' = 'user') => {
    setErrorMsg('');
    const targetEmail = (selectedEmail || googleEmail || 'storybytech07@gmail.com').trim().toLowerCase();
    const targetName = (selectedName || googleName || (targetEmail === 'storybytech07@gmail.com' ? (detailsService.getDetails().name || 'StoryByTech') : targetEmail.split('@')[0])).trim();

    if (!targetEmail || !targetEmail.includes('@')) {
      setErrorMsg('Please provide a valid Google email address.');
      return;
    }

    // Register or find existing user (prevents duplicates)
    const { user, isNew } = storageService.registerUser({
      name: targetName,
      email: targetEmail,
      phone: targetEmail === 'storybytech07@gmail.com' ? '+91 9014508314' : '+91 9876543210',
      role: targetEmail === 'storybytech07@gmail.com' ? 'admin' : (role === 'admin' ? 'admin' : userRole === 'seller' ? 'seller' : 'user'),
      authMethod: 'google',
      consentGiven: true
    });

    // Record discrete login
    storageService.recordSuccessfulLogin(user, 'google');

    // GA4 telemetry without PII
    if (isNew) {
      ga4Service.trackSignUp('google');
    }
    ga4Service.trackLogin('google', user.role);

    const session: UserSession = {
      id: user.id,
      name: user.name,
      phone: user.phone || '',
      email: user.email,
      role: user.role === 'admin' ? 'admin' : (user.role === 'seller' ? 'seller' : 'buyer'),
      authMethod: 'google',
      savedPets: []
    };

    setIsVerifying(true);
    setVerifyingText(`Signing in with Google as ${targetName}...`);
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess(session);
      onClose();
    }, 700);
  };

  const handleInstagramSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const handle = instagramHandle.trim() || '@thepawclub_2';
    const isOfficial = handle === '@thepawclub_2';
    const igEmail = `${handle.replace('@', '')}@thepawclub.in`;
    const igName = isOfficial ? 'The Paw Club Official' : handle.replace('@', '');

    const { user, isNew } = storageService.registerUser({
      name: igName,
      email: igEmail,
      phone: '+91 9014508314',
      role: isOfficial ? 'admin' : 'seller',
      authMethod: 'instagram',
      consentGiven: true
    });

    storageService.recordSuccessfulLogin(user, 'instagram');
    if (isNew) ga4Service.trackSignUp('instagram');
    ga4Service.trackLogin('instagram', user.role);

    const session: UserSession = {
      id: user.id,
      name: user.name,
      phone: user.phone || '',
      email: user.email,
      role: user.role === 'admin' ? 'admin' : 'seller',
      authMethod: 'instagram',
      savedPets: []
    };

    setIsVerifying(true);
    setVerifyingText(`Verifying Instagram account ${handle}...`);
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess(session);
      onClose();
    }, 700);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (mode === 'signup' && !consentGiven) {
      setErrorMsg('Please accept the consent terms to create your account.');
      return;
    }

    if (method === 'phone') {
      if (!phoneNumber.trim()) {
        setErrorMsg('Please enter your contact phone number');
        return;
      }
      if (useOtp && (!otpSent || !otpCode.trim())) {
        setErrorMsg('Please request and enter your OTP verification code');
        return;
      }
      if (!useOtp && !password.trim()) {
        setErrorMsg('Please enter your password');
        return;
      }
    } else if (method === 'email') {
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('Please enter a valid email address');
        return;
      }
      if (!password.trim()) {
        setErrorMsg('Please enter your password');
        return;
      }
    }

    const formattedPhone = `${countryCode} ${phoneNumber.trim()}`;
    const targetEmail = email.trim().toLowerCase() || `${phoneNumber.replace(/\D/g, '')}@phone.pawclub.in`;
    const targetName = fullName.trim() || (method === 'phone' ? `Member (${phoneNumber.slice(-4)})` : targetEmail.split('@')[0]);

    // Save/update user profile in storage (prevents duplicates)
    const { user, isNew } = storageService.registerUser({
      name: targetName,
      email: targetEmail,
      phone: formattedPhone,
      role: userRole === 'seller' ? 'seller' : 'user',
      authMethod: method === 'phone' ? 'phone_otp' : 'email_password',
      consentGiven
    });

    // Record discrete login
    storageService.recordSuccessfulLogin(user, method === 'phone' ? 'phone_otp' : 'email_password');

    // GA4 tracking without PII
    if (isNew) ga4Service.trackSignUp(method);
    ga4Service.trackLogin(method, user.role);

    const session: UserSession = {
      id: user.id,
      name: user.name,
      phone: user.phone || '',
      email: user.email,
      role: user.role === 'admin' ? 'admin' : (userRole === 'seller' ? 'seller' : 'buyer'),
      authMethod: method,
      savedPets: []
    };

    setIsVerifying(true);
    setVerifyingText(mode === 'signup' ? `Creating ${targetName}'s PawClub profile...` : `Welcome back, ${targetName}! Logging in...`);
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess(session);
      onClose();
    }, 700);
  };

  const handleQuickDemoLogin = (role: 'founder' | 'buyer') => {
    if (role === 'founder') {
      handleGoogleSignIn('storybytech07@gmail.com', 'Mr. Sai (Founder & Trainer)', 'admin');
    } else {
      handleGoogleSignIn('priya@pawclub.in', 'Priya Sharma (Pet Parent)', 'user');
    }
  };

  const handleDeleteAccountRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deleteEmail.trim()) {
      setErrorMsg('Please provide your registered email or phone to delete account.');
      return;
    }
    const targetUser = storageService.findUserByEmail(deleteEmail.trim()) || storageService.findUserByPhone(deleteEmail.trim());
    if (targetUser) {
      storageService.deleteUser(targetUser.id);
      setSuccessToast(`Account and all personal login records for ${targetUser.name} have been completely deleted.`);
      setShowDeleteRequest(false);
      setDeleteEmail('');
    } else {
      setErrorMsg('No user profile found matching that email or phone number.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/75 backdrop-blur-md transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Capybara Verification Loader Overlay */}
        {isVerifying && (
          <div className="absolute inset-0 z-50 bg-[#1e1108]/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
            <CapybaraLoader
              scale={0.8}
              message={verifyingText}
              submessage="The PawClub Secure Session · Kamareddy"
            />
          </div>
        )}

        {/* Header banner */}
        <div className="bg-gradient-to-r from-[#2a170d] via-[#3a1d0f] to-[#78350f] px-6 sm:px-8 pt-6 pb-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4 text-white" />
          </button>
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/30 text-xs font-bold text-amber-200 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            PawClub · Kamareddy, India
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight">
            {mode === 'login' ? 'Welcome to PawClub' : 'Create Your PawClub Profile'}
          </h2>
          <p className="text-amber-100/80 text-xs sm:text-sm mt-1">
            Boarding & Training Kennel · Certified Trainer Mr. Sai (📞 9014508314)
          </p>

          {/* Official Instagram Pill */}
          <div className="mt-3 flex items-center gap-2">
            <a
              href="https://instagram.com/thepawclub_2"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 text-white text-[11px] font-bold shadow hover:opacity-95 transition-opacity"
            >
              <Instagram className="w-3 h-3" /> Official Page: @thepawclub_2
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex bg-white/15 p-1 rounded-xl mt-4">
            <button
              type="button"
              onClick={() => { setMode('login'); setErrorMsg(''); }}
              className={`flex-1 py-1.5 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer ${
                mode === 'login' ? 'bg-amber-400 text-amber-950 shadow-sm' : 'text-white/80 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setErrorMsg(''); }}
              className={`flex-1 py-1.5 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer ${
                mode === 'signup' ? 'bg-amber-400 text-amber-950 shadow-sm' : 'text-white/80 hover:text-white'
              }`}
            >
              Register Account
            </button>
          </div>
        </div>

        {/* Body Form */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto bg-[#fefdfb]">
          
          {/* Professional Continue with Google Button (Firebase Auth) */}
          <div className="mb-5 flex flex-col items-center">
            <button
              type="button"
              onClick={handleDirectFirebaseGoogleSignIn}
              className="gsi-material-button w-full shadow-xs hover:shadow transition-all cursor-pointer"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span className="gsi-material-button-contents font-extrabold text-sm text-gray-800">
                  Continue with Google
                </span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setShowGoogleAccountPicker(prev => !prev)}
              className="text-[10px] text-amber-900 font-bold hover:underline mt-2 cursor-pointer flex items-center gap-1"
            >
              <span>🧪 Demo accounts / Manual test picker</span>
              <ChevronDown className={`w-3 h-3 transition-transform ${showGoogleAccountPicker ? 'rotate-180' : ''}`} />
            </button>

            <div className="relative w-full my-3">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200"></div></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-[#fefdfb] px-2 text-gray-400 font-semibold">Or use phone / email</span></div>
            </div>
          </div>

          {/* Google Account Selector Dialog */}
          {showGoogleAccountPicker && (
            <div className="mb-5 p-4 bg-amber-50/80 rounded-2xl border border-amber-300 animate-in fade-in">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-amber-950 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Select Google Account
                </span>
                <button
                  type="button"
                  onClick={() => setShowGoogleAccountPicker(false)}
                  className="text-xs text-gray-500 hover:text-gray-800"
                >
                  Cancel
                </button>
              </div>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    handleGoogleSignIn('storybytech07@gmail.com', detailsService.getDetails().name, 'admin');
                    setShowGoogleAccountPicker(false);
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-white border border-amber-200 hover:border-amber-500 flex items-center justify-between cursor-pointer transition-all shadow-xs"
                >
                  <div>
                    <div className="text-xs font-bold text-gray-900">{detailsService.getDetails().name} (storybytech07@gmail.com)</div>
                    <div className="text-[10px] text-amber-900 font-semibold">{detailsService.getDetails().role} · Admin Access</div>
                  </div>
                  <span className="text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-extrabold">Admin</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleGoogleSignIn('priya@pawclub.in', 'Priya Sharma (Pet Parent)', 'user');
                    setShowGoogleAccountPicker(false);
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-white border border-gray-200 hover:border-emerald-500 flex items-center justify-between cursor-pointer transition-all shadow-xs"
                >
                  <div>
                    <div className="text-xs font-bold text-gray-900">Priya Sharma (priya@pawclub.in)</div>
                    <div className="text-[10px] text-gray-500 font-semibold">Pet Buyer & Community Member</div>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">User</span>
                </button>

                <div className="pt-2 flex gap-2">
                  <input
                    type="email"
                    placeholder="or type your google email..."
                    value={googleEmail}
                    onChange={(e) => setGoogleEmail(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-gray-200 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (googleEmail) {
                        handleGoogleSignIn(googleEmail, googleName || googleEmail.split('@')[0], 'user');
                        setShowGoogleAccountPicker(false);
                      }
                    }}
                    className="px-3 py-1.5 bg-[#2a170d] text-amber-300 text-xs font-bold rounded-xl"
                  >
                    Sign In
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Method selector (Phone vs Email vs Instagram) */}
          <div className="flex items-center justify-between pb-3.5 border-b border-gray-100 mb-4">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Sign-in With</span>
            <div className="flex gap-1 bg-gray-100 p-0.5 rounded-lg text-xs font-semibold">
              <button
                type="button"
                onClick={() => setMethod('phone')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  method === 'phone' ? 'bg-white text-[#2a170d] shadow-sm font-bold' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Phone className="w-3 h-3 text-amber-700" />
                Phone
              </button>
              <button
                type="button"
                onClick={() => setMethod('instagram')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  method === 'instagram' ? 'bg-white text-pink-700 shadow-sm font-bold' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Instagram className="w-3 h-3 text-pink-600" />
                Instagram
              </button>
              <button
                type="button"
                onClick={() => setMethod('email')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  method === 'email' ? 'bg-white text-[#2a170d] shadow-sm font-bold' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Mail className="w-3 h-3 text-gray-500" />
                Email
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <span className="font-bold">Error:</span> {errorMsg}
            </div>
          )}

          {successToast && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>{successToast}</span>
            </div>
          )}

          {/* INSTAGRAM OFFICIAL LOGIN PAGE / TAB */}
          {method === 'instagram' ? (
            <form onSubmit={handleInstagramSubmit} className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-50 via-purple-50 to-amber-50 border border-pink-200/80 text-center">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] mx-auto flex items-center justify-center text-white shadow-md mb-2">
                  <Instagram className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-extrabold text-[#2a170d]">Official Instagram Login</h3>
                <p className="text-xs text-gray-600 mt-1">
                  Connect your Instagram account or sign in directly with PawClub official page <strong className="text-pink-600">@thepawclub_2</strong>.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Instagram Username / Handle</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-gray-400 font-bold text-sm">@</span>
                  <input
                    type="text"
                    required
                    placeholder="thepawclub_2"
                    value={instagramHandle.replace('@', '')}
                    onChange={(e) => setInstagramHandle(`@${e.target.value.replace('@', '')}`)}
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 outline-none text-sm font-semibold"
                  />
                </div>
                <span className="text-[11px] text-gray-500 mt-1 block">
                  Founder handle: <strong className="text-amber-800">@mr_sai_official_o6</strong>
                </span>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-[#833ab4] via-[#fd1d1d] to-[#fcb045] hover:opacity-95 text-white font-extrabold text-xs sm:text-sm py-3 rounded-full transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Instagram className="w-4 h-4" />
                Continue with Instagram ({instagramHandle || '@thepawclub_2'})
              </button>

              <div className="text-center pt-2">
                <a
                  href="https://instagram.com/thepawclub_2"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-pink-600 hover:underline inline-flex items-center gap-1"
                >
                  Visit official profile @thepawclub_2 on Instagram <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </form>
          ) : (
            /* PHONE / EMAIL FORM */
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* If Sign Up, show Full Name and Role */}
              {mode === 'signup' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Full Name</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        placeholder="e.g. Rahul Reddy"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#78350f] focus:ring-2 focus:ring-amber-500/20 outline-none text-sm transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Account Purpose:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setUserRole('buyer')}
                        className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all cursor-pointer ${
                          userRole === 'buyer'
                            ? 'border-amber-700 bg-amber-50 text-[#2a170d] ring-1 ring-amber-700'
                            : 'border-gray-200 text-gray-600 hover:border-gray-300'
                        }`}
                      >
                        🐾 Buy Pets & Supplies
                        <span className="block text-[10px] font-normal text-gray-500 mt-0.5">Puppies, food & boarding</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUserRole('seller')}
                        className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all cursor-pointer ${
                          userRole === 'seller'
                            ? 'border-amber-700 bg-amber-50 text-[#2a170d] ring-1 ring-amber-700'
                            : 'border-gray-200 text-gray-600 hover:border-gray-300'
                        }`}
                      >
                        🏡 Sell & Kennel Services
                        <span className="block text-[10px] font-normal text-gray-500 mt-0.5">Boarding & trainer access</span>
                      </button>
                    </div>
                  </div>
                </>
              )}

              {/* PHONE NUMBER FIELD */}
              {method === 'phone' ? (
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    Contact Phone Number (India & Global)
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="w-32 px-2.5 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-xs font-semibold focus:border-amber-700 outline-none cursor-pointer"
                    >
                      {COUNTRY_CODES.map((item) => (
                        <option key={item.code + item.country} value={item.code}>
                          {item.flag} {item.code} ({item.country})
                        </option>
                      ))}
                    </select>

                    <div className="relative flex-1">
                      <Phone className="w-4 h-4 text-amber-800 absolute left-3.5 top-3" />
                      <input
                        type="tel"
                        required
                        placeholder="9014508314"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none text-sm font-semibold transition-all"
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-1 text-[11px] text-gray-500">
                    <span>Main Kennel Phone: <strong className="text-amber-900">9014508314</strong></span>
                    <label className="inline-flex items-center gap-1 cursor-pointer hover:text-emerald-700 font-semibold">
                      <input
                        type="checkbox"
                        checked={viaWhatsApp}
                        onChange={(e) => setViaWhatsApp(e.target.checked)}
                        className="rounded text-emerald-600 w-3 h-3"
                      />
                      <MessageCircle className="w-3 h-3 text-emerald-600" />
                      Via WhatsApp
                    </label>
                  </div>

                  {/* Sub-toggle: OTP vs Password */}
                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="text-gray-600 font-semibold">Verification mode:</span>
                    <div className="flex gap-1.5">
                      <button
                        type="button"
                        onClick={() => setUseOtp(true)}
                        className={`text-xs px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                          useOtp ? 'bg-[#2a170d] text-amber-300 font-bold' : 'text-gray-500 hover:text-gray-800'
                        }`}
                      >
                        SMS / WhatsApp OTP
                      </button>
                      <button
                        type="button"
                        onClick={() => setUseOtp(false)}
                        className={`text-xs px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                          !useOtp ? 'bg-[#2a170d] text-amber-300 font-bold' : 'text-gray-500 hover:text-gray-800'
                        }`}
                      >
                        Password
                      </button>
                    </div>
                  </div>

                  {/* OTP Input Block */}
                  {useOtp ? (
                    <div className="mt-3 bg-amber-50/60 p-3 rounded-2xl border border-amber-200/80">
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs font-bold text-amber-950">6-Digit Code</label>
                        <button
                          type="button"
                          onClick={handleSendOtp}
                          disabled={otpTimer > 0}
                          className={`text-xs font-bold transition-colors cursor-pointer ${
                            otpTimer > 0 ? 'text-gray-400 cursor-not-allowed' : 'text-amber-800 hover:underline'
                          }`}
                        >
                          {otpTimer > 0 ? `Resend in ${otpTimer}s` : otpSent ? 'Resend Code' : 'Send Code'}
                        </button>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={6}
                          placeholder="778899"
                          value={otpCode}
                          onChange={(e) => setOtpCode(e.target.value)}
                          className="flex-1 px-3 py-2 rounded-xl border border-amber-200 tracking-widest text-center font-mono text-base focus:border-amber-700 outline-none bg-white font-bold"
                        />
                        {!otpSent && (
                          <button
                            type="button"
                            onClick={handleSendOtp}
                            className="px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                          >
                            Send OTP
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3">
                      <label className="block text-xs font-bold text-gray-700 mb-1">Account Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          placeholder="Enter your password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-gray-200 focus:border-amber-700 outline-none text-sm transition-all"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-3 text-gray-400 hover:text-gray-600 cursor-pointer"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* EMAIL FIELD */
                <>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Email Address</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        required
                        placeholder="name@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-amber-700 outline-none text-sm transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-gray-700">Password</label>
                      {mode === 'login' && (
                        <a href="#reset" className="text-[11px] text-amber-800 hover:underline">
                          Forgot password?
                        </a>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-gray-200 focus:border-amber-700 outline-none text-sm transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-3 text-gray-400 hover:text-gray-600 cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </>
              )}

              {/* Consent Checkbox */}
              {mode === 'signup' && (
                <div className="bg-amber-50/80 p-3 rounded-xl border border-amber-200 text-xs text-gray-800">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={consentGiven}
                      onChange={(e) => setConsentGiven(e.target.checked)}
                      className="rounded text-amber-800 w-4 h-4 mt-0.5 accent-amber-700"
                    />
                    <span className="leading-tight">
                      <strong>Privacy Consent:</strong> I agree to PawClub collecting my name, contact number, and email only for secure authentication, pet inquiries, and kennel records.
                    </span>
                  </label>
                </div>
              )}

              {/* Remember Me */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="inline-flex items-center gap-2 text-gray-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded text-amber-700 w-3.5 h-3.5"
                  />
                  Remember me on this browser
                </label>
                <span className="text-[11px] text-gray-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Verified Kamareddy Kennel
                </span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-bold text-sm py-3 rounded-full transition-all duration-200 shadow-md hover:shadow-lg cursor-pointer"
              >
                {mode === 'login'
                  ? method === 'phone' ? 'Log In with Phone Number' : 'Log In with Email'
                  : 'Create PawClub Account'}
              </button>
            </form>
          )}

          {/* Privacy & Account Rights Section */}
          <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-500">
            <button
              type="button"
              onClick={() => setShowPrivacyPolicy(!showPrivacyPolicy)}
              className="text-amber-800 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
            >
              <Info className="w-3 h-3 text-amber-700" />
              {showPrivacyPolicy ? 'Hide Privacy Notice' : 'Privacy & Data Notice'}
            </button>
            
            <button
              type="button"
              onClick={() => setShowDeleteRequest(!showDeleteRequest)}
              className="text-gray-500 hover:text-red-700 flex items-center gap-1 font-semibold cursor-pointer"
            >
              <Trash2 className="w-3 h-3 text-red-500" />
              Request Account Deletion
            </button>
          </div>

          {/* Privacy Notice Drawer */}
          {showPrivacyPolicy && (
            <div className="mt-2 p-3.5 bg-gray-50 rounded-2xl border border-gray-200 text-xs text-gray-600 space-y-1.5 animate-in fade-in">
              <h4 className="font-bold text-gray-800 text-[11px] uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> PawClub Privacy & Security Policy
              </h4>
              <p>
                <strong>1. Data Minimization:</strong> We only collect your name, phone number, and email with your explicit consent to facilitate pet bookings and kennel inquiries.
              </p>
              <p>
                <strong>2. Website Analytics:</strong> Google Analytics 4 tracks page visits and login events in an anonymized manner with zero Personally Identifiable Information (no emails or phone numbers).
              </p>
              <p>
                <strong>3. Google Sheets Integration:</strong> User rosters and login telemetry are maintained in authorized admin-only worksheets.
              </p>
              <p>
                <strong>4. Right to Deletion:</strong> You may request immediate permanent deletion of your profile and login history at any time.
              </p>
            </div>
          )}

          {/* Request Account Deletion Box */}
          {showDeleteRequest && (
            <form onSubmit={handleDeleteAccountRequest} className="mt-2 p-3.5 bg-red-50/70 rounded-2xl border border-red-200 text-xs animate-in fade-in">
              <h4 className="font-bold text-red-900 text-[11px] uppercase tracking-wider flex items-center gap-1 mb-1">
                <AlertCircle className="w-3.5 h-3.5 text-red-600" /> Request Account & Data Removal
              </h4>
              <p className="text-red-700 text-[11px] mb-2 leading-tight">
                Enter your registered email address or phone number to permanently erase your profile and login event history.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="Enter email or phone number"
                  value={deleteEmail}
                  onChange={(e) => setDeleteEmail(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-xl border border-red-200 bg-white text-xs outline-none"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Delete Data
                </button>
              </div>
            </form>
          )}

          {/* Quick Demo Profiles */}
          <div className="mt-6 pt-5 border-t border-gray-100">
            <span className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider text-center mb-3">
              One-Click Quick Login
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('founder')}
                className="flex items-center gap-2.5 p-2.5 rounded-xl border border-amber-200 hover:border-amber-500 hover:bg-amber-50/70 text-left transition-all cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-full bg-amber-200 text-amber-950 flex items-center justify-center font-bold text-xs flex-shrink-0 group-hover:scale-105 transition-transform">
                  MS
                </div>
                <div className="overflow-hidden">
                  <div className="text-xs font-bold text-gray-900 truncate">Mr. Sai (Founder)</div>
                  <div className="text-[10px] text-amber-900 font-semibold truncate">+91 9014508314</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('buyer')}
                className="flex items-center gap-2.5 p-2.5 rounded-xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 text-left transition-all cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs flex-shrink-0 group-hover:scale-105 transition-transform">
                  PS
                </div>
                <div className="overflow-hidden">
                  <div className="text-xs font-bold text-gray-900 truncate">Priya (Pet Parent)</div>
                  <div className="text-[10px] text-gray-500 truncate">+91 9876543210</div>
                </div>
              </button>
            </div>
          </div>

          {/* Bottom Owner Contact Bar */}
          <div className="mt-4 p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-center text-[11px] text-amber-950">
            <span>Direct Kennel Support: </span>
            <a href="tel:9014508314" className="font-bold underline text-amber-800">
              📞 9014508314
            </a>
            <span className="mx-1.5">·</span>
            <a href="https://instagram.com/thepawclub_2" target="_blank" rel="noopener noreferrer" className="font-bold text-pink-600 hover:underline">
              @thepawclub_2
            </a>
          </div>

        </div>
      </div>
    </div>
  );
}
