import { useState } from 'react';
import { 
  Share2, Mail, Check, Copy, MessageCircle, Twitter, Facebook, 
  Linkedin, Sparkles, Shield, Send, CheckCircle2, Heart, Award
} from 'lucide-react';
import { ga4Service } from '../services/ga4Analytics';
import { firestoreService } from '../services/firestoreService';

interface Props {
  onOpenAuth: () => void;
  onOpenContact: () => void;
  onOpenFeedback: () => void;
  onOpenPrivacy: () => void;
  currentUser?: any;
}

export default function GrowthBar({ onOpenAuth, onOpenContact, onOpenFeedback, onOpenPrivacy, currentUser }: Props) {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [consentGiven, setConsentGiven] = useState(true);
  const [newsletterStatus, setNewsletterStatus] = useState<string>('');
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showConsentBanner, setShowConsentBanner] = useState(() => {
    return typeof localStorage !== 'undefined' ? localStorage.getItem('pawclub_cookie_consent') === null : false;
  });

  const websiteUrl = typeof window !== 'undefined' ? window.location.origin : 'https://thepawclub.in';
  const referralCode = currentUser?.id ? currentUser.id.substring(0, 8) : 'PAWCLUBVIP';
  const shareUrl = `${websiteUrl}?ref=${referralCode}&utm_source=user_share&utm_medium=growth_bar`;

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
      ga4Service.trackButtonClick('copy_referral_link', 'growth_bar');
    }
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`Check out The PawClub in Kamareddy - Certified Dog Boarding, Training Kennel & Exotic Pets!\n${shareUrl}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
    ga4Service.trackButtonClick('share_whatsapp', 'growth_bar');
  };

  const handleShareTwitter = () => {
    const text = encodeURIComponent(`The PawClub - Kamareddy Dog Boarding & Training Kennel! 🐾`);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(shareUrl)}`, '_blank');
    ga4Service.trackButtonClick('share_twitter', 'growth_bar');
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      setNewsletterStatus('Please enter a valid email.');
      return;
    }
    if (!consentGiven) {
      setNewsletterStatus('Please check the consent box.');
      return;
    }

    setIsSubscribing(true);
    try {
      await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail, consent: consentGiven })
      }).catch(() => null);

      await firestoreService.saveNewsletterSubscriber(newsletterEmail, 'growth_bar');
      ga4Service.trackNewsletterSignup('growth_bar');

      setNewsletterStatus('✅ Subscribed! Welcome to the PawClub VIP updates.');
      setNewsletterEmail('');
      setTimeout(() => setNewsletterStatus(''), 4000);
    } catch {
      setNewsletterStatus('Subscription error. Please try again.');
    } finally {
      setIsSubscribing(false);
    }
  };

  const handleAcceptConsent = () => {
    localStorage.setItem('pawclub_cookie_consent', 'granted');
    setShowConsentBanner(false);
    ga4Service.setConsent(true);
  };

  const handleDeclineConsent = () => {
    localStorage.setItem('pawclub_cookie_consent', 'denied');
    setShowConsentBanner(false);
    ga4Service.setConsent(false);
  };

  return (
    <>
      {/* Analytics Cookie Consent Banner */}
      {showConsentBanner && (
        <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-md z-50 bg-[#1e1108]/95 backdrop-blur-md text-white p-4 rounded-2xl border border-amber-600/40 shadow-2xl animate-in slide-in-from-bottom-5 text-xs">
          <div className="flex items-start gap-2.5">
            <Shield className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-white leading-relaxed">
                We use privacy-friendly Google Analytics (zero PII) to analyze site performance and provide the best experience.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAcceptConsent}
                  className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-amber-950 font-extrabold rounded-lg text-xs cursor-pointer shadow-xs"
                >
                  Accept All
                </button>
                <button
                  type="button"
                  onClick={handleDeclineConsent}
                  className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white font-medium rounded-lg text-xs cursor-pointer"
                >
                  Necessary Only
                </button>
                <button
                  type="button"
                  onClick={onOpenPrivacy}
                  className="text-amber-300 underline text-[11px] ml-auto cursor-pointer"
                >
                  Privacy Policy
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Bottom Website Growth & Community Hub Bar */}
      <aside aria-label="Website Growth and Community Actions" className="fixed bottom-3 left-1/2 -translate-x-1/2 z-30 w-[94%] max-w-4xl bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-amber-900/15 p-2.5 sm:px-4 sm:py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Left: Quick Community Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={onOpenContact}
            className="flex items-center gap-1.5 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-extrabold px-3 py-1.5 rounded-xl cursor-pointer transition-colors shadow-xs"
          >
            <Mail className="w-3.5 h-3.5 text-amber-400" />
            <span>Contact Kennel</span>
          </button>

          <button
            type="button"
            onClick={onOpenFeedback}
            className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-950 font-bold px-3 py-1.5 rounded-xl border border-amber-200 cursor-pointer transition-colors"
          >
            <Heart className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden sm:inline">Rate Experience</span>
            <span className="sm:hidden">Review</span>
          </button>

          {/* Social Share Group */}
          <div className="flex items-center gap-1 pl-1 border-l border-gray-200">
            <button
              type="button"
              onClick={handleShareWhatsApp}
              title="Share on WhatsApp"
              className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleShareTwitter}
              title="Share on X / Twitter"
              className="p-1.5 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 transition-colors cursor-pointer"
            >
              <Twitter className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleCopyLink}
              title="Copy referral invite link"
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors cursor-pointer text-[11px] font-bold"
            >
              {copiedLink ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
              <span>{copiedLink ? 'Link Copied!' : 'Share & Invite'}</span>
            </button>
          </div>
        </div>

        {/* Right: VIP Newsletter Signup with explicit consent */}
        <form onSubmit={handleNewsletterSubmit} className="flex items-center gap-2 flex-grow sm:flex-grow-0">
          <div className="relative flex-grow sm:w-56">
            <input
              type="email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Join VIP newsletter (email)..."
              className="w-full px-3 py-1.5 rounded-xl border border-amber-200 text-xs bg-amber-50/40 focus:outline-hidden focus:ring-1 focus:ring-amber-500 pr-7"
            />
            <button
              type="submit"
              disabled={isSubscribing}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 text-amber-800 hover:text-amber-950 p-1 cursor-pointer"
              title="Subscribe"
            >
              <Send className="w-3 h-3" />
            </button>
          </div>
          <button
            type="button"
            onClick={onOpenPrivacy}
            className="text-[10px] text-gray-400 hover:text-gray-600 underline cursor-pointer hidden md:inline"
          >
            Privacy
          </button>
        </form>

        {newsletterStatus && (
          <div className="w-full text-center text-[11px] font-bold text-amber-900 bg-amber-50 py-1 rounded-lg">
            {newsletterStatus}
          </div>
        )}
      </aside>
    </>
  );
}
