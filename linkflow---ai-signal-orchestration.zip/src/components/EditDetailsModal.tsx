import React, { useState, useEffect, useRef } from 'react';
import { 
  X, User, Mail, Phone, MapPin, Instagram, Award, 
  Sparkles, Save, RotateCcw, CheckCircle2, ShieldCheck, 
  MessageCircle, Building2, Globe, Film, Upload, RefreshCw
} from 'lucide-react';
import { OwnerDetails } from '../types';
import { detailsService } from '../services/detailsService';
import { getCurrentGoogleUser } from '../services/googleAuth';
import { videoStorageService } from '../services/videoStorageService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSaved?: (details: OwnerDetails) => void;
}

export default function EditDetailsModal({ isOpen, onClose, onSaved }: Props) {
  const [form, setForm] = useState<OwnerDetails>(detailsService.getDetails());
  const [toast, setToast] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [videoInfo, setVideoInfo] = useState<{ isCustom: boolean; name?: string } | null>(null);

  const checkVideo = async () => {
    const custom = await videoStorageService.getCustomVideo();
    if (custom) {
      setVideoInfo({ isCustom: true, name: custom.metadata.name });
    } else {
      setVideoInfo({ isCustom: false, name: 'labrador-hero.mp4 (Default Kennel Video)' });
    }
  };

  useEffect(() => {
    if (isOpen) {
      setForm(detailsService.getDetails());
      setToast('');
      checkVideo();
    }
  }, [isOpen]);

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await videoStorageService.saveCustomVideo(file);
      setToast(`Starting video updated to "${file.name}"!`);
      checkVideo();
    } catch (err: any) {
      setToast(`Failed to upload video: ${err.message}`);
    }
  };

  const handleResetVideo = async () => {
    await videoStorageService.clearCustomVideo();
    setToast('Reset starting video to default Labrador kennel showcase.');
    checkVideo();
  };

  if (!isOpen) return null;

  const handleChange = (field: keyof OwnerDetails, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = detailsService.saveDetails(form);
    setToast('Details updated successfully! Changes applied across THE PAWCLUB.');
    if (onSaved) onSaved(updated);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  const handlePullFromGoogle = () => {
    const cached = getCurrentGoogleUser();
    if (cached) {
      setForm(prev => ({
        ...prev,
        email: cached.email || prev.email,
        name: cached.displayName || prev.name
      }));
      setToast(`Loaded profile from Google: ${cached.email}`);
    } else {
      // Default to known user details from metadata
      setForm(prev => ({
        ...prev,
        email: 'storybytech07@gmail.com',
        name: 'StoryByTech'
      }));
      setToast('Applied user account details: storybytech07@gmail.com');
    }
  };

  const handleReset = () => {
    const res = detailsService.resetToDefaults();
    setForm(res);
    setToast('Reset to default PawClub credentials.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="relative bg-gradient-to-r from-[#2a170d] via-[#3d2012] to-[#78350f] p-5 sm:p-6 text-white flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-[11px] font-semibold mb-1">
              <Sparkles className="w-3 h-3" />
              Custom Business & Profile Settings
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
              Replace With My Details
            </h2>
            <p className="text-amber-200/80 text-xs font-medium">
              Update owner name, email, contact numbers & handles across all pages
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer flex-shrink-0"
            aria-label="Close"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Quick Autofill Actions */}
        <div className="bg-amber-50/90 border-b border-amber-200/80 px-5 py-3 flex items-center justify-between gap-2 flex-wrap">
          <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
            Quick Setup:
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePullFromGoogle}
              className="px-3 py-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
            >
              <Mail className="w-3 h-3 text-red-500" />
              Use My Google Email (storybytech07@gmail.com)
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="px-2.5 py-1 bg-white/60 hover:bg-white text-gray-600 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              Reset
            </button>
          </div>
        </div>

        {/* Toast */}
        {toast && (
          <div className="mx-5 mt-3 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2 font-medium animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>{toast}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 sm:p-6 overflow-y-auto space-y-4 bg-[#fdfbf9] flex-1">
          
          {/* Identity & Business */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <User className="w-3 h-3 text-amber-700" /> Your Name / Founder Name
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g. StoryByTech or Mr. Sai"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-amber-700" /> Business / Club Name
              </label>
              <input
                type="text"
                required
                value={form.businessName}
                onChange={(e) => handleChange('businessName', e.target.value)}
                placeholder="e.g. THE PAWCLUB"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>
          </div>

          {/* Email & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Mail className="w-3 h-3 text-amber-700" /> Support / Admin Email
              </label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="e.g. storybytech07@gmail.com"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Phone className="w-3 h-3 text-amber-700" /> Main Phone / WhatsApp Number
              </label>
              <input
                type="text"
                required
                value={form.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="e.g. 9014508314"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>
          </div>

          {/* Location & Title */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-700" /> Location / City, Country
              </label>
              <input
                type="text"
                required
                value={form.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="e.g. Kamareddy, India"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Award className="w-3 h-3 text-amber-700" /> Role / Title
              </label>
              <input
                type="text"
                required
                value={form.role}
                onChange={(e) => handleChange('role', e.target.value)}
                placeholder="e.g. Certified Dog Trainer & Founder"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>
          </div>

          {/* Handles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Instagram className="w-3 h-3 text-pink-600" /> Personal / Founder Handle
              </label>
              <input
                type="text"
                value={form.founderHandle}
                onChange={(e) => handleChange('founderHandle', e.target.value)}
                placeholder="e.g. @storybytech"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1 flex items-center gap-1">
                <Instagram className="w-3 h-3 text-pink-600" /> Official Business Instagram
              </label>
              <input
                type="text"
                value={form.instagramOfficial}
                onChange={(e) => handleChange('instagramOfficial', e.target.value)}
                placeholder="e.g. @thepawclub_2"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>
          </div>

          {/* Experience & Specialization */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">
                Experience Badge
              </label>
              <input
                type="text"
                value={form.experience}
                onChange={(e) => handleChange('experience', e.target.value)}
                placeholder="e.g. 4+ Yrs Experience"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">
                Specialization Tagline
              </label>
              <input
                type="text"
                value={form.specialization}
                onChange={(e) => handleChange('specialization', e.target.value)}
                placeholder="e.g. Boarding & Training | 🐶 Exotic Pets"
                className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none"
              />
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">
              About & Kennel Bio
            </label>
            <textarea
              rows={2}
              value={form.bio || ''}
              onChange={(e) => handleChange('bio', e.target.value)}
              placeholder="Tell pet parents about your philosophy, training certifications, and facility."
              className="w-full px-3 py-2 rounded-xl border border-gray-200 text-xs font-medium bg-white focus:border-amber-700 focus:ring-1 focus:ring-amber-700 outline-none resize-none"
            />
          </div>

          {/* Starting Page Video Settings */}
          <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-950">
                <Film className="w-4 h-4 text-amber-700" />
                <span>Starting Page Video (Plays on Website Opening)</span>
              </div>
              {videoInfo?.isCustom && (
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                  Custom Video Active
                </span>
              )}
            </div>

            <p className="text-[11px] text-gray-600 mb-2.5">
              Active video: <strong>{videoInfo?.name}</strong>. You can upload any new video (.mp4, .webm) to play at the website opening page.
            </p>

            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleVideoUpload}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                Upload New Starting Video
              </button>

              {videoInfo?.isCustom && (
                <button
                  type="button"
                  onClick={handleResetVideo}
                  className="px-3 py-1.5 bg-white hover:bg-gray-100 text-gray-700 text-xs font-bold rounded-xl border border-gray-300 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-gray-500" />
                  Reset to Default
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-gray-300 text-gray-700 text-xs font-bold hover:bg-gray-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
            >
              <Save className="w-3.5 h-3.5" />
              Save & Apply My Details
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
