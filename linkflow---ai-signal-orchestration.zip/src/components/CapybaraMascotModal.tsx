import React, { useState, useEffect } from 'react';
import { X, Sparkles, Heart, Award, MapPin, Phone, RefreshCw, Volume2, Music, Check } from 'lucide-react';
import CapybaraLoader from './CapybaraLoader';
import { detailsService } from '../services/detailsService';
import { OwnerDetails } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenOwner?: () => void;
}

export default function CapybaraMascotModal({ isOpen, onClose, onOpenOwner }: Props) {
  const [details, setDetails] = useState<OwnerDetails>(detailsService.getDetails());
  const [scale, setScale] = useState(0.85);
  const [mood, setMood] = useState<'chill' | 'snacking' | 'training'>('chill');
  const [treatCount, setTreatCount] = useState(0);
  const [lastTreat, setLastTreat] = useState<string | null>(null);
  const [customText, setCustomText] = useState('THE PAWCLUB · EXOTIC PETS & KENNEL');

  useEffect(() => {
    const unsub = detailsService.subscribe((updated) => setDetails(updated));
    setDetails(detailsService.getDetails());
    return unsub;
  }, []);

  if (!isOpen) return null;

  const handleFeed = (treat: string) => {
    setTreatCount((prev) => prev + 1);
    setLastTreat(treat);
    setMood('snacking');
    setTimeout(() => {
      setMood('chill');
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#120a05]/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#25160c] to-[#170e08] rounded-3xl border border-amber-500/30 shadow-2xl text-white overflow-hidden z-10 p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-amber-900/40 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl">
              🦫
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-amber-200 tracking-tight">
                  The PawClub Capybara Mascot
                </h3>
                <span className="bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border border-amber-500/30">
                  Exotic VIP
                </span>
              </div>
              <p className="text-xs text-amber-100/70">
                Official animated mascot & exotic pet boarding showcase · Kamareddy, India
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* The Animated Capybara Loader Centerpiece */}
        <div className="bg-[#1a0f07] border border-amber-900/50 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
          {/* Subtle Ambient Glow */}
          <div className="absolute inset-0 bg-gradient-radial from-amber-600/10 via-transparent to-transparent pointer-events-none" />

          {/* Status Badge */}
          <div className="mb-2 flex items-center gap-2 bg-amber-950/80 px-3 py-1 rounded-full border border-amber-600/30 text-xs font-semibold text-amber-300">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span>
              {mood === 'snacking'
                ? `Munching on ${lastTreat}! (+${treatCount} treats)`
                : mood === 'training'
                ? 'Trainer Sai coaching Capybara agility!'
                : 'Pacing peacefully on the PawClub trail...'}
            </span>
          </div>

          {/* The Exact Uiverse Capybara Loader Component */}
          <div className="my-2 flex items-center justify-center min-h-[160px]">
            <CapybaraLoader
              scale={scale}
              message={customText}
              submessage="Certified Boarding & Training Kennel · Kamareddy"
            />
          </div>

          {/* Interactive Treat Buttons */}
          <div className="mt-4 pt-4 border-t border-amber-900/40 w-full flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs font-bold text-amber-200/80 mr-1">Feed Treats:</span>
            <button
              onClick={() => handleFeed('Fresh Watermelon 🍉')}
              className="bg-amber-900/60 hover:bg-amber-800 text-amber-100 text-xs font-bold px-3 py-1.5 rounded-xl border border-amber-700/40 flex items-center gap-1 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              🍉 Watermelon
            </button>
            <button
              onClick={() => handleFeed('Sweet Baby Carrots 🥕')}
              className="bg-amber-900/60 hover:bg-amber-800 text-amber-100 text-xs font-bold px-3 py-1.5 rounded-xl border border-amber-700/40 flex items-center gap-1 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              🥕 Carrots
            </button>
            <button
              onClick={() => handleFeed('Organic Meadow Grass 🌾')}
              className="bg-amber-900/60 hover:bg-amber-800 text-amber-100 text-xs font-bold px-3 py-1.5 rounded-xl border border-amber-700/40 flex items-center gap-1 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              🌾 Meadow Grass
            </button>
            <button
              onClick={() => setTreatCount(0)}
              className="text-white/40 hover:text-white/80 text-xs px-2 py-1 transition-colors cursor-pointer"
              title="Reset treat counter"
            >
              <RefreshCw className="w-3 h-3 inline" />
            </button>
          </div>
        </div>

        {/* Scale & Caption Controls */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-[#1f130a] p-3 rounded-xl border border-amber-900/30 flex items-center justify-between">
            <span className="text-amber-200/80 font-bold">Loader Size / Scale:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setScale(0.6)}
                className={`px-2 py-1 rounded text-[11px] font-bold ${
                  scale === 0.6 ? 'bg-amber-500 text-amber-950' : 'bg-white/10 text-white/80'
                }`}
              >
                Small (0.6x)
              </button>
              <button
                onClick={() => setScale(0.85)}
                className={`px-2 py-1 rounded text-[11px] font-bold ${
                  scale === 0.85 ? 'bg-amber-500 text-amber-950' : 'bg-white/10 text-white/80'
                }`}
              >
                Default (0.85x)
              </button>
              <button
                onClick={() => setScale(1.05)}
                className={`px-2 py-1 rounded text-[11px] font-bold ${
                  scale === 1.05 ? 'bg-amber-500 text-amber-950' : 'bg-white/10 text-white/80'
                }`}
              >
                Large (1.05x)
              </button>
            </div>
          </div>

          <div className="bg-[#1f130a] p-3 rounded-xl border border-amber-900/30 flex items-center justify-between gap-2">
            <span className="text-amber-200/80 font-bold shrink-0">Caption:</span>
            <input
              type="text"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              className="w-full bg-[#140c06] border border-amber-800/40 rounded-lg px-2.5 py-1 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400"
              placeholder="Loader caption text..."
            />
          </div>
        </div>

        {/* Kennel Exotic Pets Details */}
        <div className="mt-4 bg-gradient-to-r from-amber-950/40 via-amber-900/20 to-amber-950/40 p-4 rounded-2xl border border-amber-700/30">
          <div className="flex items-center gap-2 mb-2">
            <Award className="w-4 h-4 text-amber-400" />
            <h4 className="font-bold text-amber-200 text-sm">
              Exotic Pets & Boarding Services at {details.businessName}
            </h4>
          </div>
          <p className="text-xs text-amber-100/80 leading-relaxed mb-3">
            Capybaras are the world's largest rodents and known as nature's gentlest friend, getting along with dogs, cats, and birds alike! Whether you have exotic animals, champion canines, or gentle companions, {details.name} provides safe boarding facilities with spacious natural runs in {details.location}.
          </p>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-amber-900/30 text-xs">
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>Direct Hotline: {details.formattedPhone}</span>
            </div>

            <div className="flex items-center gap-2">
              {onOpenOwner && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenOwner();
                  }}
                  className="bg-amber-500 hover:bg-amber-400 text-amber-950 font-black px-4 py-1.5 rounded-xl transition-all cursor-pointer text-xs flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5" /> Kennel & Trainer Profile
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
