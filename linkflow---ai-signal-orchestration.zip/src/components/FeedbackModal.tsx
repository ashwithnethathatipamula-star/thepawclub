import { useState } from 'react';
import { X, Star, Send, CheckCircle2 } from 'lucide-react';
import { firestoreService } from '../services/firestoreService';
import { ga4Service } from '../services/ga4Analytics';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: { name?: string; email?: string } | null;
}

export default function FeedbackModal({ isOpen, onClose, currentUser }: Props) {
  const [rating, setRating] = useState(5);
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;

    setIsSubmitting(true);
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, comment, name, email })
      }).catch(() => null);

      await firestoreService.saveFeedback({
        rating,
        comment,
        name: name || 'PawClub Guest',
        email
      });

      ga4Service.trackFeedbackSubmission(rating);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setComment('');
        onClose();
      }, 2000);
    } catch {
      // fallback
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 flex flex-col">
        {/* Header */}
        <div className="p-5 bg-[#2a170d] text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
              Member Feedback
            </span>
            <h2 className="text-base font-extrabold text-white">Rate Your Experience</h2>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {submitted ? (
            <div className="py-8 text-center space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <h3 className="text-base font-bold text-gray-900">Thank You!</h3>
              <p className="text-xs text-gray-500">Your feedback helps us provide the best care for every pet.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Star rating selector */}
              <div className="flex flex-col items-center gap-2 py-2">
                <span className="text-xs font-bold text-gray-700">How would you rate The PawClub?</span>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="cursor-pointer transition-transform hover:scale-110"
                    >
                      <Star 
                        className={`w-7 h-7 ${star <= rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} 
                      />
                    </button>
                  ))}
                </div>
                <span className="text-[11px] font-bold text-amber-900">
                  {rating === 5 ? '⭐⭐⭐⭐⭐ Outstanding!' : rating === 4 ? 'Great Service' : rating === 3 ? 'Good' : 'Needs Improvement'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Your Name (Optional)</label>
                <input 
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Anand"
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Your Review / Comments *</label>
                <textarea 
                  rows={3}
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Tell us what you loved or how we can improve..."
                  className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                {isSubmitting ? 'Submitting...' : 'Submit Review'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
