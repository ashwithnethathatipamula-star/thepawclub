import { useState, useEffect } from 'react';
import { X, Phone, MessageCircle, ShieldCheck, MapPin, CheckCircle2, Heart, Instagram } from 'lucide-react';
import { PetListing, UserSession, OwnerDetails } from '../types';
import { ga4Service } from '../services/ga4Analytics';
import { detailsService } from '../services/detailsService';

interface Props {
  pet: PetListing | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserSession | null;
}

export default function PetInquiryModal({ pet, isOpen, onClose, currentUser }: Props) {
  const [details, setDetails] = useState<OwnerDetails>(detailsService.getDetails());
  const [buyerName, setBuyerName] = useState(currentUser?.name || '');
  const [buyerPhone, setBuyerPhone] = useState(currentUser?.phone || '');
  const [buyerMessage, setBuyerMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const unsub = detailsService.subscribe((updated) => setDetails(updated));
    setDetails(detailsService.getDetails());
    return unsub;
  }, []);

  useEffect(() => {
    if (pet) {
      setBuyerMessage(`Hello ${details.name}, I am interested in adopting/purchasing ${pet.name} (${pet.breed}) from ${details.businessName} ${details.location}.`);
    }
  }, [pet, details]);

  if (!isOpen || !pet) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Track non-PII inquiry event in GA4
    ga4Service.trackPetInquiry(pet.id, pet.breed, pet.price);
    // Also trigger whatsapp directly
    const text = encodeURIComponent(
      `Hello ${details.name} (${details.founderHandle || details.businessName}), I am interested in ${pet.name} (${pet.breed}) listed for ₹${pet.price}.\nMy Name: ${buyerName}\nMy Contact: ${buyerPhone}\nMessage: ${buyerMessage}`
    );
    window.open(`https://wa.me/${details.whatsapp}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/75 backdrop-blur-md transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal */}
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-amber-100 bg-gradient-to-r from-[#2a170d] to-[#4b2612] text-white">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-amber-200">
              Direct Breeder & Kennel Contact
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        <div className="p-6 max-h-[80vh] overflow-y-auto bg-[#fefdfb]">
          {/* Pet Snapshot Card */}
          <div className="flex gap-4 p-3 bg-amber-50/70 rounded-2xl border border-amber-200/80 mb-5">
            <img
              src={pet.imageUrl}
              alt={pet.name}
              className="w-20 h-20 rounded-xl object-cover shadow-sm flex-shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 truncate">{pet.name}</h3>
                <span className="text-base font-extrabold text-amber-900">${pet.price}</span>
              </div>
              <p className="text-xs text-amber-950 font-semibold truncate">{pet.breed} · {pet.age} ({pet.gender})</p>
              <div className="flex items-center gap-1 text-[11px] text-gray-600 mt-1">
                <MapPin className="w-3 h-3 text-amber-700" />
                <span>{pet.location}</span>
              </div>
            </div>
          </div>

          {/* Seller Verified Contact Section */}
          <div className="p-4 rounded-2xl bg-white border border-amber-200/80 shadow-sm mb-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Certified Breeder / Kennel</span>
                <div className="text-sm font-extrabold text-[#2a170d] flex items-center gap-1.5">
                  {pet.sellerName}
                  {pet.sellerVerified && (
                    <span className="inline-flex items-center gap-0.5 text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-full font-bold">
                      <ShieldCheck className="w-3 h-3 text-amber-700" /> Verified Trainer
                    </span>
                  )}
                </div>
              </div>
              <span className="text-xs font-bold text-amber-800 bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
                ★ {pet.sellerRating} Rating
              </span>
            </div>

            {/* Seller Contact Number Direct Action */}
            <div className="bg-[#2a170d] text-white p-3.5 rounded-xl flex items-center justify-between shadow-sm">
              <div>
                <span className="text-[10px] text-amber-300 block font-bold">Direct Main Phone / WhatsApp</span>
                <span className="text-sm font-extrabold tracking-wide text-white">9014508314</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={`tel:9014508314`}
                  className="px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white text-xs font-bold flex items-center gap-1 transition-colors"
                >
                  <Phone className="w-3 h-3" /> Call
                </a>
                <a
                  href={`https://wa.me/919014508314?text=Hello%20Mr.%20Sai,%20I%20am%20interested%20in%20${encodeURIComponent(pet.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 transition-colors shadow"
                >
                  <MessageCircle className="w-3 h-3" /> WhatsApp
                </a>
              </div>
            </div>

            <div className="mt-2.5 flex items-center justify-between text-[11px] text-gray-500 pt-1">
              <span>📍 Kamareddy, India</span>
              <a href="https://instagram.com/thepawclub_2" target="_blank" rel="noopener noreferrer" className="text-pink-600 font-bold hover:underline flex items-center gap-0.5">
                <Instagram className="w-3 h-3" /> @thepawclub_2
              </a>
            </div>
          </div>

          {/* Inquiry form */}
          {submitted ? (
            <div className="p-6 rounded-2xl bg-amber-50/80 text-center border border-amber-200 animate-in fade-in">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h4 className="text-base font-bold text-gray-900">Inquiry Request Sent!</h4>
              <p className="text-xs text-gray-600 mt-1 max-w-xs mx-auto">
                {details.name} ({details.founderHandle || details.businessName}) has received your request. You can also directly call or WhatsApp{' '}
                <strong className="text-amber-950 font-bold">{details.phone}</strong>.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-4 px-6 py-2 bg-[#2a170d] text-amber-300 text-xs font-bold rounded-full hover:bg-[#3d2012] transition-colors cursor-pointer shadow"
              >
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <span className="text-xs font-bold text-gray-800 block">Send Direct Message to Owner / Trainer</span>
              
              <div>
                <label className="block text-[11px] font-bold text-gray-600 mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:border-amber-700 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-600 mb-1">
                  Your Contact Phone Number (Required for Call / WhatsApp)
                </label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-amber-700 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    placeholder="+91 9014508314"
                    value={buyerPhone}
                    onChange={(e) => setBuyerPhone(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:border-amber-700 outline-none font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-600 mb-1">Message to Mr. Sai</label>
                <textarea
                  rows={3}
                  required
                  value={buyerMessage}
                  onChange={(e) => setBuyerMessage(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-200 text-xs focus:border-amber-700 outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs font-extrabold py-3 rounded-full transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Heart className="w-4 h-4 fill-amber-300 text-amber-300" />
                Submit Inquiry & Open WhatsApp (9014508314)
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
