import { X, ShieldCheck, Lock, Trash2, Eye, Server } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenDelete?: () => void;
}

export default function PrivacyNoticeModal({ isOpen, onClose, onOpenDelete }: Props) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-[#2a170d] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-extrabold text-white">Privacy Notice & Security Policy</h2>
              <span className="text-[10px] text-amber-300">The PawClub · Kamareddy, Telangana</span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-gray-700 leading-relaxed">
          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-amber-950 font-medium">
            At <strong>The PawClub</strong>, your privacy and data sovereignty are paramount. We strictly limit personal data collection to what is essential for kennel booking, puppy training, and community membership.
          </div>

          <div>
            <h3 className="font-extrabold text-gray-900 text-sm mb-1 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-amber-700" /> 1. Information We Collect
            </h3>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Google Authentication:</strong> When you choose "Continue with Google", Firebase Authentication provides your display name, email, profile picture, and unique Firebase UID.</li>
              <li><strong>Never Collected:</strong> Passwords are never stored on our servers or databases. Google handles OAuth authentication directly.</li>
              <li><strong>Phone Numbers:</strong> Voluntarily provided only if you request direct WhatsApp or phone coordination for pet boarding or puppies.</li>
            </ul>
          </div>

          <div>
            <h3 className="font-extrabold text-gray-900 text-sm mb-1 flex items-center gap-1.5">
              <Server className="w-4 h-4 text-amber-700" /> 2. Cloud Firestore & Security Rules
            </h3>
            <p>
              Your user profile is stored securely in <strong>Google Cloud Firestore</strong> under document ID matching your unique Firebase User ID. Access controls (ABAC) mathematically prevent any ordinary user from accessing, listing, or modifying other members' private records.
            </p>
          </div>

          <div>
            <h3 className="font-extrabold text-gray-900 text-sm mb-1 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-amber-700" /> 3. Analytics & Telemetry (Zero-PII)
            </h3>
            <p>
              Google Analytics 4 is strictly configured with IP anonymization and zero-PII transmission. No names, email addresses, or phone numbers are ever sent to analytics trackers.
            </p>
          </div>

          <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-200">
            <h3 className="font-extrabold text-gray-900 text-xs mb-1 flex items-center gap-1.5">
              <Trash2 className="w-4 h-4 text-red-600" /> 4. Right to Account Deletion & Erasure
            </h3>
            <p className="text-[11px] text-gray-600 mb-2">
              You retain the right to delete your profile and purge your records at any time directly through your Account Settings modal or by contacting the founder.
            </p>
            {onOpenDelete && (
              <button
                type="button"
                onClick={() => { onClose(); onOpenDelete(); }}
                className="text-xs font-bold text-red-600 hover:text-red-800 underline cursor-pointer"
              >
                Go to Account Settings to delete account →
              </button>
            )}
          </div>

          <div className="pt-2 text-[11px] text-gray-500">
            For privacy inquiries, contact our Data Protection Officer at: <a href="mailto:storybytech07@gmail.com" className="font-bold text-amber-900 underline">storybytech07@gmail.com</a>
          </div>
        </div>
      </div>
    </div>
  );
}
