import React, { useState, useEffect } from 'react';
import {
  X,
  HardDrive,
  FolderPlus,
  Upload,
  FileText,
  Trash2,
  ExternalLink,
  Download,
  Search,
  RefreshCw,
  Folder,
  FileCode,
  FileCheck,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
  Plus,
  Database,
  HeartHandshake,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { googleDriveService, DriveFileItem, DriveStorageInfo } from '../services/googleDriveService';
import {
  googleSignIn,
  getAccessToken,
  logoutGoogle,
  getCurrentGoogleUser,
  initAuth,
  setManualAccessToken
} from '../services/googleAuth';
import { storageService } from '../services/storageService';
import { detailsService } from '../services/detailsService';
import CapybaraLoader from './CapybaraLoader';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: { email?: string; role?: string; name?: string } | null;
  isOwnerOrFounder?: boolean;
}

export default function GoogleDriveVaultModal({ 
  isOpen, 
  onClose,
  currentUser,
  isOwnerOrFounder = false
}: Props) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [accountInfo, setAccountInfo] = useState<DriveStorageInfo | null>(null);
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('Syncing with Google Drive...');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'folders' | 'dossiers' | 'documents'>('all');
  const [statusNotification, setStatusNotification] = useState<string | null>(null);

  // New folder dialog state
  const [showNewFolderModal, setShowNewFolderModal] = useState<boolean>(false);
  const [newFolderName, setNewFolderName] = useState<string>('');

  // New pet dossier generator dialog
  const [showDossierModal, setShowDossierModal] = useState<boolean>(false);
  const [dossierPetName, setDossierPetName] = useState<string>('Bruno (Golden Retriever)');
  const [dossierBreed, setDossierBreed] = useState<string>('Golden Retriever');
  const [dossierAge, setDossierAge] = useState<string>('1.5 Years');
  const [dossierGender, setDossierGender] = useState<string>('Male');
  const [dossierOwner, setDossierOwner] = useState<string>(() => detailsService.getDetails().name);
  const [dossierPhone, setDossierPhone] = useState<string>(() => detailsService.getDetails().formattedPhone);

  // Destructive Action Confirmation Modal (MANDATORY per Google Workspace skill)
  const [itemToDelete, setItemToDelete] = useState<DriveFileItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Manual token input state (as fallback for restricted iframe popup environments)
  const [showTokenInput, setShowTokenInput] = useState<boolean>(false);
  const [manualToken, setManualToken] = useState<string>('');

  // Check auth state on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, _token) => {
        setIsAuthenticated(true);
        setGoogleUser(user);
        loadDriveData();
      },
      () => {
        setIsAuthenticated(false);
        setGoogleUser(null);
      }
    );

    // Initial check
    checkExistingAuth();

    return () => {
      unsubscribe();
    };
  }, []);

  const checkExistingAuth = async () => {
    const token = await getAccessToken();
    const user = getCurrentGoogleUser();
    if (token) {
      setIsAuthenticated(true);
      setGoogleUser(user);
      loadDriveData();
    }
  };

  const loadDriveData = async () => {
    try {
      setLoading(true);
      setLoadingMessage('Loading your Google Drive files...');
      const [filesList, accInfo] = await Promise.all([
        googleDriveService.listFiles({ pageSize: 50 }),
        googleDriveService.getAccountInfo()
      ]);
      setFiles(filesList);
      if (accInfo) {
        setAccountInfo(accInfo);
      }
    } catch (err: any) {
      console.error('Error fetching Google Drive data:', err);
      // If unauthorized, token may have expired
      if (err.message?.includes('401') || err.message?.includes('Token not found')) {
        setIsAuthenticated(false);
      }
      setStatusNotification('Notice: Please ensure you are signed in to Google with Drive permissions.');
      setTimeout(() => setStatusNotification(null), 5000);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setLoadingMessage('Authorizing with Google Drive...');
      const result = await googleSignIn();
      if (result) {
        setIsAuthenticated(true);
        setGoogleUser(result.user);
        setStatusNotification('Successfully connected to Google Drive!');
        await loadDriveData();
      }
    } catch (err: any) {
      console.warn('Google Sign-In popup notice:', err);
      setStatusNotification(`Google Auth Notice: ${err.message || 'Popups may be blocked in iframe.'}`);
      setShowTokenInput(true);
    } finally {
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 6000);
    }
  };

  const handleManualTokenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualToken.trim()) return;
    setManualAccessToken(manualToken.trim());
    setIsAuthenticated(true);
    setShowTokenInput(false);
    await loadDriveData();
    setStatusNotification('OAuth Access Token applied for Google Drive session!');
    setTimeout(() => setStatusNotification(null), 5000);
  };

  const handleLogout = async () => {
    await logoutGoogle();
    setIsAuthenticated(false);
    setGoogleUser(null);
    setAccountInfo(null);
    setFiles([]);
    setStatusNotification('Disconnected from Google Drive.');
    setTimeout(() => setStatusNotification(null), 3000);
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;

    try {
      setLoading(true);
      setLoadingMessage(`Creating folder "${newFolderName}" on Google Drive...`);
      await googleDriveService.createFolder(newFolderName.trim());
      setShowNewFolderModal(false);
      setNewFolderName('');
      setStatusNotification(`Folder "${newFolderName}" created successfully in Google Drive!`);
      await loadDriveData();
    } catch (err: any) {
      console.error('Create folder error:', err);
      alert(`Could not create folder: ${err.message}`);
    } finally {
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 5000);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      setLoadingMessage(`Uploading "${file.name}" to Google Drive...`);
      await googleDriveService.uploadFile(
        file.name,
        file,
        file.type || 'application/octet-stream',
        undefined,
        'Uploaded via The Paw Club Vault'
      );
      setStatusNotification(`File "${file.name}" uploaded to Google Drive!`);
      await loadDriveData();
    } catch (err: any) {
      console.error('File upload error:', err);
      alert(`Upload failed: ${err.message}`);
    } finally {
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 5000);
      e.target.value = '';
    }
  };

  const handleGeneratePetDossier = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setLoadingMessage(`Generating official pet dossier for ${dossierPetName} to Google Drive...`);
      await googleDriveService.savePetDossierToDrive({
        name: dossierPetName,
        breed: dossierBreed,
        age: dossierAge,
        gender: dossierGender,
        vaccinated: true,
        microchipped: true,
        healthChecked: true,
        pedigree: true,
        ownerOrSeller: dossierOwner,
        contact: dossierPhone
      });
      setShowDossierModal(false);
      setStatusNotification(`Pet health dossier for ${dossierPetName} stored to Google Drive!`);
      await loadDriveData();
    } catch (err: any) {
      console.error('Error generating dossier:', err);
      alert(`Could not save dossier: ${err.message}`);
    } finally {
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 5000);
    }
  };

  const handleBackupPawClubToDrive = async () => {
    try {
      setLoading(true);
      setLoadingMessage('Backing up PawClub user records & analytics to Google Drive...');
      const users = storageService.getUsers();
      const logins = storageService.getLogins();
      const analytics = storageService.getAnalytics();

      await googleDriveService.saveAnalyticsReportToDrive({
        exportDate: new Date().toISOString(),
        pawClubBranch: 'Kamareddy, Telangana, India',
        founder: 'Mr. Sai (+91 9014508314)',
        stats: {
          totalUsers: users.length,
          totalLogins: logins.length,
          totalDailyAnalyticsDays: analytics.length
        },
        users,
        recentLogins: logins.slice(0, 50),
        analytics
      });

      setStatusNotification('PawClub database & analytics backed up to Google Drive!');
      await loadDriveData();
    } catch (err: any) {
      console.error('Backup error:', err);
      alert(`Backup failed: ${err.message}`);
    } finally {
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 5000);
    }
  };

  // MANDATORY: User confirmation before executing destructive delete operations
  const confirmAndDelete = async () => {
    if (!itemToDelete) return;
    try {
      setIsDeleting(true);
      setLoading(true);
      setLoadingMessage(`Permanently deleting "${itemToDelete.name}" from Google Drive...`);
      await googleDriveService.deleteFile(itemToDelete.id);
      setStatusNotification(`"${itemToDelete.name}" was permanently removed from Google Drive.`);
      setItemToDelete(null);
      await loadDriveData();
    } catch (err: any) {
      console.error('Delete error:', err);
      alert(`Delete failed: ${err.message}`);
    } finally {
      setIsDeleting(false);
      setLoading(false);
      setTimeout(() => setStatusNotification(null), 5000);
    }
  };

  const filteredFiles = files.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;

    if (activeFilter === 'folders') return f.isFolder;
    if (activeFilter === 'dossiers') return f.name.includes('Health_Record') || f.name.includes('.md');
    if (activeFilter === 'documents') return !f.isFolder;
    return true;
  });

  const formatFileSize = (bytes?: string) => {
    if (!bytes) return 'Folder';
    const num = parseInt(bytes, 10);
    if (isNaN(num)) return '—';
    if (num < 1024) return `${num} B`;
    if (num < 1024 * 1024) return `${(num / 1024).toFixed(1)} KB`;
    return `${(num / (1024 * 1024)).toFixed(1)} MB`;
  };

  if (!isOpen) return null;

  if (!isOwnerOrFounder) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
        <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-amber-900/20 p-6 sm:p-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-700 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-extrabold text-[#2a170d] mb-2">
            Owner & Founder Vault Only
          </h3>
          <p className="text-xs text-gray-600 mb-6 leading-relaxed">
            Google Drive Pet Health Dossiers and member spreadsheets are confidential and only accessible by PawClub owner and founder accounts.
          </p>
          <button
            onClick={onClose}
            className="w-full py-3 rounded-full bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-extrabold text-xs transition-colors cursor-pointer"
          >
            Close Vault
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Modal Container */}
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-amber-900/30 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Loading Overlay with Capybara Loader */}
        {loading && (
          <div className="absolute inset-0 bg-white/92 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
            <CapybaraLoader scale={0.8} />
            <div className="mt-4 text-[#2a170d] font-extrabold text-base flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-600 animate-spin" />
              {loadingMessage}
            </div>
            <p className="text-xs text-amber-900/80 mt-1 max-w-sm">
              Communicating securely with Google Drive v3 API...
            </p>
          </div>
        )}

        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#241308] via-[#3a1d0f] to-[#5a2e16] px-6 sm:px-8 py-5 text-white flex items-center justify-between border-b border-amber-900/40 relative">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 shadow-inner">
              <HardDrive className="w-6 h-6" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-[11px] font-bold text-emerald-300 mb-0.5">
                <ShieldCheck className="w-3 h-3" />
                Google Workspace OAuth 2.0 Integration
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
                PawClub Pet Vault on Google Drive
              </h2>
              <p className="text-amber-200/80 text-xs">
                Securely store pet vaccination records, medical certificates, pedigree papers, and backups
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Notification Banner */}
        {statusNotification && (
          <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 text-xs text-amber-900 font-bold flex items-center gap-2 animate-in fade-in">
            <Sparkles className="w-4 h-4 text-amber-600" />
            {statusNotification}
          </div>
        )}

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-[#fdfbf7]">
          
          {/* Authentication State */}
          {!isAuthenticated ? (
            <div className="bg-white rounded-3xl p-8 border border-amber-900/15 shadow-sm text-center max-w-2xl mx-auto my-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center mx-auto mb-4 text-amber-800">
                <HardDrive className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-black text-[#2a170d] mb-2">
                Connect Your Google Drive
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 mb-6 max-w-lg mx-auto leading-relaxed">
                Connect Google Drive to allow PawClub to save certified pet health dossiers, store veterinary certificates, microchip registration contracts, and create automatic backups in your personal Google Drive storage with your permission.
              </p>

              {/* Official Google Sign-In Button as mandated by Workspace skill */}
              <div className="flex justify-center mb-4">
                <button
                  type="button"
                  className="gsi-material-button shadow-md hover:shadow-lg transition-all"
                  onClick={handleGoogleSignIn}
                >
                  <div className="gsi-material-button-state"></div>
                  <div className="gsi-material-button-content-wrapper">
                    <div className="gsi-material-button-icon">
                      <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                        <path fill="none" d="M0 0h48v48H0z"></path>
                      </svg>
                    </div>
                    <span className="gsi-material-button-contents">Sign in with Google (Google Drive)</span>
                  </div>
                </button>
              </div>

              {/* Security guarantee */}
              <div className="flex items-center justify-center gap-2 text-[11px] text-gray-500 font-semibold mb-4">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                OAuth 2.0 In-Memory Tokens Only · No tokens stored in localStorage
              </div>

              {/* Fallback Access Token Drawer for sandboxed preview */}
              <div className="pt-4 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setShowTokenInput(!showTokenInput)}
                  className="text-xs text-amber-800 hover:text-amber-950 font-bold underline cursor-pointer"
                >
                  {showTokenInput ? 'Hide Token Input' : 'Preview Note: If browser blocks popups, enter an OAuth Bearer Token directly'}
                </button>

                {showTokenInput && (
                  <form onSubmit={handleManualTokenSubmit} className="mt-3 flex gap-2 max-w-md mx-auto">
                    <input
                      type="text"
                      placeholder="Paste Google OAuth Access Token..."
                      value={manualToken}
                      onChange={(e) => setManualToken(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs rounded-xl border border-gray-300 focus:outline-amber-600 font-mono"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-[#2a170d] text-amber-300 text-xs font-bold rounded-xl"
                    >
                      Connect
                    </button>
                  </form>
                )}
              </div>
            </div>
          ) : (
            <div>
              {/* Connected Account & Action Bar */}
              <div className="bg-white rounded-3xl p-5 border border-amber-900/15 shadow-sm mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                
                {/* User & Storage Details */}
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-amber-600 to-amber-800 text-white flex items-center justify-center font-black text-sm shadow-md">
                    {accountInfo?.userName ? accountInfo.userName.charAt(0) : (googleUser?.displayName?.charAt(0) || 'G')}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-[#2a170d] text-sm">
                        {accountInfo?.userName || googleUser?.displayName || 'Connected Google Account'}
                      </span>
                      <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        Drive Active
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 font-medium">
                      {accountInfo?.userEmail || googleUser?.email || 'Google Drive Connected'}
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowDossierModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
                  >
                    <FileCheck className="w-3.5 h-3.5" />
                    + New Pet Health Dossier
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowNewFolderModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold border border-amber-200 transition-all cursor-pointer"
                  >
                    <FolderPlus className="w-3.5 h-3.5" />
                    New Folder
                  </button>

                  <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold border border-amber-200 transition-all cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    Upload File
                    <input
                      type="file"
                      className="hidden"
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.json,.csv"
                    />
                  </label>

                  <button
                    type="button"
                    onClick={handleBackupPawClubToDrive}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-bold border border-emerald-200 transition-all cursor-pointer"
                    title="Export all PawClub users, logins and telemetry to Google Drive"
                  >
                    <Database className="w-3.5 h-3.5 text-emerald-700" />
                    Backup PawClub DB
                  </button>

                  <button
                    type="button"
                    onClick={loadDriveData}
                    className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-all cursor-pointer"
                    title="Refresh Google Drive files"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={handleLogout}
                    className="px-3 py-2 text-xs font-bold text-gray-500 hover:text-red-600 transition-colors cursor-pointer"
                    title="Disconnect Google Drive"
                  >
                    Disconnect
                  </button>
                </div>
              </div>

              {/* Search & Filter Toolbar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-5">
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search Google Drive files..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-gray-200 text-xs font-medium focus:outline-amber-600 shadow-2xs"
                  />
                </div>

                <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-gray-200 text-xs font-bold text-gray-600 self-stretch sm:self-auto">
                  <button
                    onClick={() => setActiveFilter('all')}
                    className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                      activeFilter === 'all' ? 'bg-amber-100 text-amber-900' : 'hover:bg-gray-100'
                    }`}
                  >
                    All ({files.length})
                  </button>
                  <button
                    onClick={() => setActiveFilter('dossiers')}
                    className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                      activeFilter === 'dossiers' ? 'bg-amber-100 text-amber-900' : 'hover:bg-gray-100'
                    }`}
                  >
                    Pet Records
                  </button>
                  <button
                    onClick={() => setActiveFilter('folders')}
                    className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                      activeFilter === 'folders' ? 'bg-amber-100 text-amber-900' : 'hover:bg-gray-100'
                    }`}
                  >
                    Folders
                  </button>
                  <button
                    onClick={() => setActiveFilter('documents')}
                    className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                      activeFilter === 'documents' ? 'bg-amber-100 text-amber-900' : 'hover:bg-gray-100'
                    }`}
                  >
                    Documents
                  </button>
                </div>
              </div>

              {/* Files List / Grid */}
              {filteredFiles.length === 0 ? (
                <div className="bg-white rounded-3xl p-12 text-center border border-amber-900/10 shadow-xs">
                  <Folder className="w-12 h-12 text-amber-300 mx-auto mb-3" />
                  <h4 className="font-bold text-[#2a170d] text-base mb-1">
                    {searchTerm ? 'No matching files found' : 'No documents in this view'}
                  </h4>
                  <p className="text-xs text-gray-500 max-w-md mx-auto mb-5">
                    Click "+ New Pet Health Dossier" to store your first verified medical record, or upload vaccination certificates directly to Google Drive.
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowDossierModal(true)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#2a170d] text-amber-300 text-xs font-bold rounded-xl shadow cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create Sample Pet Dossier
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {filteredFiles.map((file) => (
                    <div
                      key={file.id}
                      className="bg-white rounded-2xl p-4 border border-gray-200/80 hover:border-amber-400 hover:shadow-md transition-all flex flex-col justify-between group"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          file.isFolder
                            ? 'bg-amber-100 text-amber-700'
                            : file.name.includes('.md')
                            ? 'bg-emerald-100 text-emerald-700'
                            : file.name.includes('.json')
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}>
                          {file.isFolder ? (
                            <Folder className="w-5 h-5" />
                          ) : file.name.includes('.md') ? (
                            <FileCheck className="w-5 h-5" />
                          ) : file.name.includes('.json') ? (
                            <FileCode className="w-5 h-5" />
                          ) : (
                            <FileText className="w-5 h-5" />
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <h5 className="font-bold text-xs text-gray-900 truncate group-hover:text-amber-900 transition-colors" title={file.name}>
                            {file.name}
                          </h5>
                          <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-1">
                            <span>{formatFileSize(file.size)}</span>
                            {file.modifiedTime && (
                              <>
                                <span>•</span>
                                <span>{new Date(file.modifiedTime).toLocaleDateString()}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Card Action Footer */}
                      <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          {file.webViewLink && (
                            <a
                              href={file.webViewLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1"
                              title="Open in Google Drive"
                            >
                              Open in Drive <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          )}
                          {file.webContentLink && (
                            <a
                              href={file.webContentLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] font-bold text-gray-600 hover:text-gray-900 flex items-center gap-1 ml-2"
                              title="Download File"
                            >
                              <Download className="w-2.5 h-2.5" />
                            </a>
                          )}
                        </div>

                        {/* Destructive Delete Button - Triggers Confirmation Dialog */}
                        <button
                          type="button"
                          onClick={() => setItemToDelete(file)}
                          className="text-gray-400 hover:text-red-600 p-1 rounded-md transition-colors cursor-pointer"
                          title="Delete from Google Drive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-amber-50/70 border-t border-amber-900/10 px-6 sm:px-8 py-3.5 flex flex-col sm:flex-row items-center justify-between text-xs text-amber-900 gap-2">
          <div className="flex items-center gap-2 font-medium">
            <HeartHandshake className="w-4 h-4 text-amber-700" />
            <span>The Paw Club · Official Pet Boarding & Breeding Kennel (Kamareddy, India)</span>
          </div>
          <div className="text-[11px] text-gray-500">
            Powered by Google Drive REST API v3
          </div>
        </div>

      </div>

      {/* --- CREATE NEW FOLDER DIALOG --- */}
      {showNewFolderModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 w-full max-w-md shadow-2xl border border-amber-900/20">
            <h4 className="text-lg font-black text-[#2a170d] mb-1">Create Folder in Google Drive</h4>
            <p className="text-xs text-gray-500 mb-4">Organize your pet records, medical documents, and contracts.</p>
            <form onSubmit={handleCreateFolder}>
              <input
                type="text"
                placeholder="e.g. 🐶 Husky Vaccination Cards"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                autoFocus
                className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-xs font-semibold focus:outline-amber-600 mb-4"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewFolderModal(false)}
                  className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newFolderName.trim()}
                  className="px-5 py-2 text-xs font-bold bg-[#2a170d] text-amber-300 hover:bg-[#3d2012] rounded-xl cursor-pointer disabled:opacity-50"
                >
                  Create Folder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- CREATE PET HEALTH DOSSIER DIALOG --- */}
      {showDossierModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-amber-900/20 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-black text-[#2a170d] flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-amber-700" />
                Generate Pet Health Dossier to Drive
              </h4>
              <button
                onClick={() => setShowDossierModal(false)}
                className="w-7 h-7 rounded-full hover:bg-gray-100 flex items-center justify-center cursor-pointer text-gray-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mb-4">
              Generates an authorized PawClub veterinary and care record file and uploads it directly to your Google Drive.
            </p>

            <form onSubmit={handleGeneratePetDossier} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Pet Name</label>
                <input
                  type="text"
                  value={dossierPetName}
                  onChange={(e) => setDossierPetName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Breed</label>
                  <input
                    type="text"
                    value={dossierBreed}
                    onChange={(e) => setDossierBreed(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Age</label>
                  <input
                    type="text"
                    value={dossierAge}
                    onChange={(e) => setDossierAge(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Gender</label>
                  <select
                    value={dossierGender}
                    onChange={(e) => setDossierGender(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Owner / Guardian</label>
                  <input
                    type="text"
                    value={dossierOwner}
                    onChange={(e) => setDossierOwner(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-700 uppercase mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={dossierPhone}
                  onChange={(e) => setDossierPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-gray-300 font-semibold"
                />
              </div>

              <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-[11px] text-amber-950 font-medium">
                ✅ Includes: Full Rabies/DHPP vaccination clearances, microchip id sync, and Mr. Sai's trainer endorsement.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDossierModal(false)}
                  className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-amber-700 hover:bg-amber-800 text-white rounded-xl cursor-pointer shadow-sm"
                >
                  Save Dossier to Drive
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MANDATORY CONFIRMATION DIALOG FOR DESTRUCTIVE OPERATIONS --- */}
      {itemToDelete && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-7 w-full max-w-md shadow-2xl border-2 border-red-500/30">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            
            <h4 className="text-lg font-black text-gray-900 mb-1">
              Delete File from Google Drive?
            </h4>
            <p className="text-xs text-gray-600 mb-4 leading-relaxed">
              Are you sure you want to permanently delete <strong className="text-red-700 font-bold">"{itemToDelete.name}"</strong> from your Google Drive? This action cannot be undone.
            </p>

            <div className="bg-red-50 rounded-xl p-3 border border-red-200 text-[11px] text-red-900 mb-5">
              ⚠️ This will remove the file from your Google Drive storage via the Google Drive API.
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setItemToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2.5 text-xs font-bold text-gray-700 hover:bg-gray-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmAndDelete}
                disabled={isDeleting}
                className="px-5 py-2.5 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                {isDeleting ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
