import { useState } from 'react';
import { 
  X, User, Mail, Shield, Calendar, Clock, LogOut, 
  Trash2, AlertTriangle, CheckCircle2, Award
} from 'lucide-react';
import { UserSession } from '../types';
import { logoutGoogle } from '../services/googleAuth';
import { firestoreService } from '../services/firestoreService';
import { storageService } from '../services/storageService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserSession | null;
  onLogout: () => void;
}

export default function AccountSettingsModal({ isOpen, onClose, currentUser, onLogout }: Props) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen || !currentUser) return null;

  // Retrieve user profile data from storageService or default
  const profile = currentUser.id ? storageService.getUserById(currentUser.id) : null;
  const registeredDate = profile?.registeredAt 
    ? new Date(profile.registeredAt).toLocaleDateString(undefined, { dateStyle: 'medium' })
    : 'Active Member';
  const lastLoginFormatted = profile?.lastLoginAt 
    ? new Date(profile.lastLoginAt).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
    : 'Current Session';
  const totalLogins = profile?.totalLogins || 1;

  const handleSignOut = async () => {
    await logoutGoogle();
    onLogout();
    onClose();
  };

  const handleDeleteAccount = async () => {
    if (!currentUser.id) return;
    setIsDeleting(true);
    setStatusMsg('Deleting account data securely...');

    try {
      await firestoreService.deleteUserAccount(currentUser.id);
    } catch {
      // ignore network error
    }

    storageService.deleteUser(currentUser.id);
    setIsDeleting(false);
    onLogout();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="absolute inset-0"
        onClick={onClose}
      />
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-br from-[#2a170d] to-[#452718] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-amber-500/20 border-2 border-amber-400/40 flex items-center justify-center text-amber-200 font-bold text-lg">
              {currentUser.avatar ? (
                <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
              ) : (
                currentUser.name.charAt(0).toUpperCase()
              )}
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-1.5">
                {currentUser.name}
                {currentUser.role === 'admin' && (
                  <span className="text-[10px] bg-amber-500 text-amber-950 font-black px-2 py-0.5 rounded-full uppercase">
                    Admin
                  </span>
                )}
              </h2>
              <span className="text-xs text-amber-200/80 font-medium flex items-center gap-1">
                <Shield className="w-3 h-3 text-emerald-400" /> Account Settings & Security
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Account Details Content */}
        <div className="p-6 space-y-4 text-xs">
          {/* Email Address - displayed securely in Account Settings */}
          <div className="p-3.5 bg-amber-50/60 rounded-2xl border border-amber-200/70">
            <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block mb-1">
              Registered Email (Google Account)
            </span>
            <div className="flex items-center gap-2 text-sm font-extrabold text-gray-900">
              <Mail className="w-4 h-4 text-amber-700" />
              <span>{currentUser.email || 'Not provided'}</span>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-0.5">
                Account Status
              </span>
              <div className="flex items-center gap-1.5 font-extrabold text-emerald-700 text-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Active Member
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-0.5">
                Total Logins
              </span>
              <div className="flex items-center gap-1.5 font-extrabold text-amber-900 text-sm">
                <Award className="w-4 h-4 text-amber-600" /> {totalLogins} Successful
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-0.5">
                Member Since
              </span>
              <div className="flex items-center gap-1.5 font-bold text-gray-800 text-xs">
                <Calendar className="w-3.5 h-3.5 text-gray-500" /> {registeredDate}
              </div>
            </div>

            <div className="p-3 bg-gray-50 rounded-2xl border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-0.5">
                Last Activity
              </span>
              <div className="flex items-center gap-1.5 font-bold text-gray-800 text-xs">
                <Clock className="w-3.5 h-3.5 text-gray-500" /> {lastLoginFormatted}
              </div>
            </div>
          </div>

          {/* Security & Cloud Firestore Note */}
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px] leading-relaxed">
            <strong className="block font-bold">🔒 Protected by Firebase & Cloud Firestore:</strong>
            Your profile is securely indexed by your unique Firebase User ID. Passwords are never stored on this website.
          </div>

          {/* Delete Account Process */}
          {showDeleteConfirm ? (
            <div className="p-4 rounded-2xl bg-red-50 border border-red-200 space-y-2">
              <div className="flex items-center gap-2 text-red-700 font-extrabold text-xs">
                <AlertTriangle className="w-4 h-4 text-red-600" /> Confirm Account Deletion
              </div>
              <p className="text-[11px] text-red-600 leading-normal">
                This will permanently delete your user profile and login history from Cloud Firestore. This cannot be undone.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={handleDeleteAccount}
                  className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs cursor-pointer"
                >
                  {isDeleting ? 'Deleting...' : 'Yes, Delete My Account'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-xl font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="pt-2 flex items-center justify-between border-t border-gray-100">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="text-red-500 hover:text-red-700 font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" /> Delete My Account
              </button>

              <button
                type="button"
                onClick={handleSignOut}
                className="px-4 py-2 bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 font-extrabold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <LogOut className="w-3.5 h-3.5" /> Sign Out
              </button>
            </div>
          )}

          {statusMsg && (
            <p className="text-center text-xs text-amber-800 font-bold">{statusMsg}</p>
          )}
        </div>
      </div>
    </div>
  );
}
