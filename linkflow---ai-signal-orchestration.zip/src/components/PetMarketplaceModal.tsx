import { useState } from 'react';
import { 
  X, Search, Filter, PlusCircle, Tag, MapPin, Phone, ShieldCheck, 
  Heart, CheckCircle2, DollarSign, Camera, Sparkles, User, SlidersHorizontal,
  Instagram, ShoppingBag
} from 'lucide-react';
import { PetListing, UserSession } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  pets: PetListing[];
  onAddPet: (newPet: PetListing) => void;
  onSelectPetForInquiry: (pet: PetListing) => void;
  initialTab?: 'buy' | 'sell';
  currentUser: UserSession | null;
  onOpenAuth: () => void;
  onOpenOwner?: () => void;
  onOpenSupplies?: () => void;
}

const SAMPLE_IMAGES = [
  { label: 'Labrador Puppy', url: 'https://images.unsplash.com/photo-1579202673506-ca3ce28943ef?auto=format&fit=crop&w=800&q=80' },
  { label: 'German Shepherd', url: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5455?auto=format&fit=crop&w=800&q=80' },
  { label: 'Golden Retriever', url: 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80' },
  { label: 'Persian Kitten', url: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=800&q=80' },
  { label: 'Exotic Sun Conure', url: 'https://images.unsplash.com/photo-1452570053594-1b985d6ea890?auto=format&fit=crop&w=800&q=80' },
  { label: 'Holland Lop Bunny', url: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?auto=format&fit=crop&w=800&q=80' }
];

export default function PetMarketplaceModal({
  isOpen,
  onClose,
  pets,
  onAddPet,
  onSelectPetForInquiry,
  initialTab = 'buy',
  currentUser,
  onOpenAuth,
  onOpenOwner,
  onOpenSupplies
}: Props) {
  const [activeTab, setActiveTab] = useState<'buy' | 'sell'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'dog' | 'cat' | 'other'>('all');
  const [maxPrice, setMaxPrice] = useState<number>(2000);
  const [savedPetIds, setSavedPetIds] = useState<string[]>([]);
  const [toastMsg, setToastMsg] = useState('');

  // Sell Form state
  const [petName, setPetName] = useState('');
  const [petType, setPetType] = useState<'dog' | 'cat' | 'bird' | 'other'>('dog');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [price, setPrice] = useState('');
  const [location, setLocation] = useState('Kamareddy, India');
  const [sellerName, setSellerName] = useState(currentUser?.name || 'Mr. Sai (@mr_sai_official_o6)');
  const [sellerPhone, setSellerPhone] = useState(currentUser?.phone || '9014508314');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState(SAMPLE_IMAGES[0].url);
  const [vaccinated, setVaccinated] = useState(true);
  const [microchipped, setMicrochipped] = useState(true);
  const [healthChecked, setHealthChecked] = useState(true);
  const [pedigree, setPedigree] = useState(true);

  if (!isOpen) return null;

  const toggleSave = (id: string) => {
    setSavedPetIds((prev) => 
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSellSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sellerPhone.trim()) {
      alert('Please provide your contact phone number so buyers can reach you.');
      return;
    }

    const newListing: PetListing = {
      id: `pet-${Date.now()}`,
      name: petName.trim(),
      type: petType as any,
      breed: breed.trim(),
      age: age.trim() || 'Young',
      gender,
      price: parseFloat(price) || 0,
      location: location.trim() || 'Kamareddy, India',
      imageUrl,
      vaccinated,
      microchipped,
      healthChecked,
      pedigree,
      description: description.trim() || 'Raised at PawClub kennel, certified trainer examined.',
      sellerName: sellerName.trim() || 'PawClub Kennel (@mr_sai_official_o6)',
      sellerPhone: sellerPhone.trim() || '9014508314',
      sellerRating: 5.0,
      sellerVerified: true,
      createdAt: 'Just now'
    };

    onAddPet(newListing);
    setToastMsg(`🎉 "${newListing.name}" has been published to PawClub Pet Marketplace!`);
    setTimeout(() => setToastMsg(''), 4000);
    setActiveTab('buy');

    // Reset fields
    setPetName('');
    setBreed('');
    setAge('');
    setPrice('');
    setDescription('');
  };

  const filteredPets = pets.filter((p) => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.breed.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || p.type === selectedType;
    const matchesPrice = p.price <= maxPrice;
    return matchesSearch && matchesType && matchesPrice;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#140c06]/75 backdrop-blur-md transition-opacity" 
        onClick={onClose} 
      />

      {/* Main Container */}
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-amber-900/20 overflow-hidden z-10 flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-[#2a170d] via-[#3a1d0f] to-[#78350f] px-6 py-5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-800/30">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/30 text-xs font-bold text-amber-200">
                <Sparkles className="w-3.5 h-3.5" />
                PawClub Marketplace · Kamareddy, India
              </span>
              <a
                href="tel:9014508314"
                className="text-xs font-extrabold text-amber-300 bg-black/30 px-2.5 py-0.5 rounded-full flex items-center gap-1 hover:bg-black/50"
              >
                <Phone className="w-3 h-3 text-amber-400" /> 9014508314
              </a>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1">
              Buy, Rehome & Adopt Trained & Exotic Pets
            </h2>
            <p className="text-xs text-amber-100/80 mt-0.5 hidden sm:block">
              Boarding & Training Kennel · Certified Trainer Mr. Sai (@mr_sai_official_o6) · @thepawclub_2
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-end sm:self-center">
            {/* Quick link to supplies or owner */}
            {onOpenSupplies && (
              <button
                type="button"
                onClick={() => { onClose(); onOpenSupplies(); }}
                className="hidden md:flex items-center gap-1 text-xs font-bold text-amber-200 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> Supplies
              </button>
            )}

            {/* Tab switchers */}
            <div className="flex bg-white/15 p-1 rounded-2xl">
              <button
                type="button"
                onClick={() => setActiveTab('buy')}
                className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
                  activeTab === 'buy' ? 'bg-amber-400 text-amber-950 shadow-sm' : 'text-white/80 hover:text-white'
                }`}
              >
                🐾 Buy & Adopt
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('sell')}
                className={`px-3.5 py-1.5 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'sell' ? 'bg-amber-400 text-amber-950 shadow-sm' : 'text-white/80 hover:text-white'
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Sell a Pet
              </button>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>

        {/* Success toast notification */}
        {toastMsg && (
          <div className="bg-amber-700 text-white px-6 py-2.5 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-amber-300" />
            {toastMsg}
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-[#fbf9f6]">
          {activeTab === 'buy' ? (
            /* ================= BUY / ADOPT TAB ================= */
            <div>
              {/* Filter and Search Bar */}
              <div className="bg-white p-4 rounded-2xl shadow-sm border border-amber-200/70 mb-6 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
                
                {/* Search input */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="Search Labrador, German Shepherd, Parrot, Kamareddy..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                  />
                </div>

                {/* Pet Type Filters */}
                <div className="flex gap-1.5 flex-wrap">
                  {(['all', 'dog', 'cat', 'other'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setSelectedType(t)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                        selectedType === t
                          ? 'bg-[#2a170d] text-amber-300 shadow-sm'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {t === 'all' ? 'All Pets' : t === 'dog' ? '🐶 Dogs & Pups' : t === 'cat' ? '🐱 Cats' : '🦜 Exotic Pets'}
                    </button>
                  ))}
                </div>

                {/* Price Filter */}
                <div className="flex items-center gap-2 text-xs font-semibold text-gray-600">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-gray-400" />
                  <span>Max: <strong className="text-[#2a170d]">${maxPrice}</strong></span>
                  <input
                    type="range"
                    min={150}
                    max={2000}
                    step={50}
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(Number(e.target.value))}
                    className="w-24 accent-amber-700"
                  />
                </div>
              </div>

              {/* Pets Grid */}
              {filteredPets.length === 0 ? (
                <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-amber-200">
                  <span className="text-4xl block mb-2">🐾</span>
                  <h3 className="text-base font-bold text-gray-800">No pets match your search</h3>
                  <p className="text-xs text-gray-500 mt-1">Try resetting your filters or contacting trainer Mr. Sai.</p>
                  <button
                    onClick={() => { setSearchQuery(''); setSelectedType('all'); setMaxPrice(2000); }}
                    className="mt-4 px-4 py-1.5 bg-[#2a170d] text-amber-300 text-xs font-bold rounded-full"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredPets.map((pet) => {
                    const isSaved = savedPetIds.includes(pet.id);
                    return (
                      <div
                        key={pet.id}
                        className="group bg-white rounded-2xl border border-amber-200/80 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
                      >
                        <div>
                          {/* Pet Photo with overlay */}
                          <div className="relative aspect-[4/3] w-full overflow-hidden bg-amber-50">
                            <img
                              src={pet.imageUrl}
                              alt={pet.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute top-3 left-3 bg-[#2a170d]/90 text-amber-300 px-2.5 py-1 rounded-full text-xs font-extrabold shadow-sm">
                              ${pet.price}
                            </div>
                            <button
                              type="button"
                              onClick={() => toggleSave(pet.id)}
                              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-gray-600 hover:text-red-500 transition-colors shadow-sm cursor-pointer"
                              aria-label="Save pet"
                            >
                              <Heart className={`w-4 h-4 ${isSaved ? 'fill-red-500 text-red-500' : ''}`} />
                            </button>
                            <div className="absolute bottom-2 left-2 bg-[#2a170d]/85 backdrop-blur-sm text-white px-2 py-0.5 rounded-md text-[10px] font-semibold flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-amber-400" />
                              {pet.location}
                            </div>
                          </div>

                          {/* Pet Info */}
                          <div className="p-4">
                            <div className="flex items-center justify-between mb-1">
                              <h3 className="text-base font-bold text-gray-900 group-hover:text-amber-800 transition-colors">
                                {pet.name}
                              </h3>
                              <span className="text-xs font-semibold text-gray-600 bg-amber-50 border border-amber-200/70 px-2 py-0.5 rounded-full">
                                {pet.gender} · {pet.age}
                              </span>
                            </div>
                            <p className="text-xs font-bold text-amber-900">{pet.breed}</p>
                            <p className="text-xs text-gray-600 mt-2 line-clamp-2 leading-relaxed">
                              {pet.description}
                            </p>

                            {/* Trust Badges */}
                            <div className="flex flex-wrap gap-1.5 mt-3">
                              {pet.vaccinated && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full">
                                  <ShieldCheck className="w-3 h-3 text-emerald-600" /> Vaccinated
                                </span>
                              )}
                              {pet.healthChecked && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-blue-50 text-blue-800 px-2 py-0.5 rounded-full">
                                  Vet Checked
                                </span>
                              )}
                              {pet.pedigree && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-50 text-amber-800 px-2 py-0.5 rounded-full">
                                  ★ Certified K9
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Seller & Action Footer */}
                        <div className="p-4 pt-0">
                          <div className="pt-2.5 border-t border-gray-100 mb-2.5 flex items-center justify-between text-[11px] text-gray-500">
                            <span className="truncate font-medium">{pet.sellerName}</span>
                            <a
                              href="tel:9014508314"
                              className="flex items-center gap-1 text-amber-900 font-extrabold hover:underline"
                            >
                              <Phone className="w-3 h-3 text-amber-700" /> {pet.sellerPhone}
                            </a>
                          </div>

                          <button
                            type="button"
                            onClick={() => onSelectPetForInquiry(pet)}
                            className="w-full bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-xs font-bold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                          >
                            <Phone className="w-3.5 h-3.5" />
                            Contact Trainer & Buy / Adopt
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            /* ================= SELL / LIST TAB ================= */
            <div className="max-w-2xl mx-auto bg-white p-6 sm:p-8 rounded-3xl border border-amber-200/80 shadow-sm">
              <div className="border-b border-gray-100 pb-4 mb-6">
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-extrabold mb-2">
                  <Tag className="w-3.5 h-3.5 text-amber-700" /> Direct Kennel & Breeder Rehoming
                </span>
                <h3 className="text-xl font-extrabold text-gray-900">List Your Pet with PawClub</h3>
                <p className="text-xs text-gray-600 mt-1">
                  Connect directly with verified pet adopters across Kamareddy and India. Main kennel phone: <strong>9014508314</strong>.
                </p>
              </div>

              <form onSubmit={handleSellSubmit} className="space-y-4">
                {/* Pet Name & Type */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Pet Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Bruno"
                      value={petName}
                      onChange={(e) => setPetName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Pet Category *</label>
                    <select
                      value={petType}
                      onChange={(e) => setPetType(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none bg-white cursor-pointer"
                    >
                      <option value="dog">🐶 Dog / Puppy</option>
                      <option value="cat">🐱 Cat / Kitten</option>
                      <option value="other">🦜 Exotic Pet (Parrot, Bunny, etc.)</option>
                    </select>
                  </div>
                </div>

                {/* Breed & Age */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Breed *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Labrador, German Shepherd"
                      value={breed}
                      onChange={(e) => setBreed(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Age *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 3 Months, 1 Year"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                    />
                  </div>
                </div>

                {/* Gender & Price */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Gender *</label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setGender('Male')}
                        className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-colors cursor-pointer ${
                          gender === 'Male' ? 'bg-[#2a170d] text-amber-300 border-[#2a170d]' : 'border-gray-200 text-gray-600'
                        }`}
                      >
                        Male
                      </button>
                      <button
                        type="button"
                        onClick={() => setGender('Female')}
                        className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-colors cursor-pointer ${
                          gender === 'Female' ? 'bg-[#2a170d] text-amber-300 border-[#2a170d]' : 'border-gray-200 text-gray-600'
                        }`}
                      >
                        Female
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Price / Adoption Fee ($) *</label>
                    <div className="relative">
                      <DollarSign className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                      <input
                        type="number"
                        required
                        placeholder="650"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Location */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">City, State / Location *</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      placeholder="Kamareddy, India"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none"
                    />
                  </div>
                </div>

                {/* Seller Contact Info */}
                <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-3">
                  <span className="text-xs font-bold text-amber-950 block">Owner / Breeder Contact Information</span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 mb-1">Your Name / Kennel *</label>
                      <input
                        type="text"
                        required
                        placeholder="Mr. Sai (@mr_sai_official_o6)"
                        value={sellerName}
                        onChange={(e) => setSellerName(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-gray-200 bg-white text-xs focus:border-amber-700 outline-none font-semibold"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-gray-700 mb-1">
                        Contact Phone Number * (e.g. 9014508314)
                      </label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 text-amber-700 absolute left-3 top-2.5" />
                        <input
                          type="tel"
                          required
                          placeholder="9014508314"
                          value={sellerPhone}
                          onChange={(e) => setSellerPhone(e.target.value)}
                          className="w-full pl-8 pr-3 py-2 rounded-xl border border-gray-200 bg-white text-xs focus:border-amber-700 outline-none font-bold"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Photo selection */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Select Pet Photo</label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-2">
                    {SAMPLE_IMAGES.map((img) => (
                      <button
                        type="button"
                        key={img.url}
                        onClick={() => setImageUrl(img.url)}
                        className={`aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                          imageUrl === img.url ? 'border-amber-700 scale-105 shadow-md' : 'border-gray-200 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img src={img.url} alt={img.label} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Health checkboxes */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <label className="flex items-center gap-1.5 p-2 bg-gray-50 rounded-xl cursor-pointer font-semibold">
                    <input type="checkbox" checked={vaccinated} onChange={(e) => setVaccinated(e.target.checked)} className="rounded text-amber-700" />
                    Vaccinated
                  </label>
                  <label className="flex items-center gap-1.5 p-2 bg-gray-50 rounded-xl cursor-pointer font-semibold">
                    <input type="checkbox" checked={healthChecked} onChange={(e) => setHealthChecked(e.target.checked)} className="rounded text-amber-700" />
                    Vet Checked
                  </label>
                  <label className="flex items-center gap-1.5 p-2 bg-gray-50 rounded-xl cursor-pointer font-semibold">
                    <input type="checkbox" checked={microchipped} onChange={(e) => setMicrochipped(e.target.checked)} className="rounded text-amber-700" />
                    Microchipped
                  </label>
                  <label className="flex items-center gap-1.5 p-2 bg-gray-50 rounded-xl cursor-pointer font-semibold">
                    <input type="checkbox" checked={pedigree} onChange={(e) => setPedigree(e.target.checked)} className="rounded text-amber-700" />
                    Trained K9
                  </label>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">About the Pet *</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Temperament, training status, favorite toys, exotic care requirements..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-amber-700 outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#2a170d] hover:bg-[#3d2012] text-amber-300 text-sm font-extrabold py-3.5 rounded-full transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4 text-amber-400" />
                  Publish Pet Listing for Sale
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
