import { useEffect, useRef, useState } from 'react';

type Props = {
  src: string;
  className?: string;
  isMuted?: boolean;
  isPlaying?: boolean;
  onTogglePlay?: () => void;
  onToggleMute?: () => void;
  onOpenSpotlight?: () => void;
  onOpenUpload?: () => void;
  onReplayIntro?: () => void;
  isCustomVideo?: boolean;
  isOwnerOrFounder?: boolean;
};

export default function BoomerangVideoBg({
  src,
  className,
  isMuted = true,
  isPlaying = true,
  onTogglePlay,
  onToggleMute,
  onOpenSpotlight,
  onOpenUpload,
  onReplayIntro,
  isCustomVideo = false,
  isOwnerOrFounder = false
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoLoaded, setVideoLoaded] = useState(true);
  const [videoError, setVideoError] = useState(false);

  // Synchronize playing / pause state
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      const p = video.play();
      if (p !== undefined) {
        p.catch(() => {
          // If browser policy blocks autoplay with sound, fall back to muted autoplay
          video.muted = true;
          video.play().catch(() => {});
        });
      }
    } else {
      video.pause();
    }
  }, [isPlaying, src]);

  // Synchronize muted state
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = isMuted;
  }, [isMuted]);

  // Ensure autoplay on mount and source change
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    setVideoLoaded(true);
    setVideoError(false);

    const handleLoaded = () => {
      setVideoLoaded(true);
      video.muted = isMuted;
      video.play().catch(() => {
        video.muted = true;
        video.play().catch(() => {});
      });
    };

    const handleError = () => {
      setVideoError(true);
    };

    video.addEventListener('loadeddata', handleLoaded);
    video.addEventListener('error', handleError);

    if (video.readyState >= 2) {
      handleLoaded();
    }

    return () => {
      video.removeEventListener('loadeddata', handleLoaded);
      video.removeEventListener('error', handleError);
    };
  }, [src, isMuted]);

  return (
    <div className={className ?? 'absolute inset-0 w-full h-full overflow-hidden'}>
      {/* HTML5 Native Video for Hardware-Accelerated Playback */}
      <video
        ref={videoRef}
        key={src}
        src={src}
        className="w-full h-full object-cover transition-opacity duration-700 opacity-100"
        autoPlay
        loop
        muted={isMuted}
        playsInline
        preload="auto"
      >
        {/* Fallbacks */}
        <source src={src} type="video/mp4" />
        <source src="/INTRO.mp4" type="video/mp4" />
        <source src="/Scene-ezremove.mp4" type="video/mp4" />
        <source src="/intro.mp4" type="video/mp4" />
      </video>

      {/* Clean Subtle Warm Overlay for Contrast while keeping video vibrant */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            linear-gradient(to bottom, rgba(20, 12, 7, 0.45) 0%, rgba(20, 12, 7, 0.12) 40%, rgba(18, 11, 6, 0.65) 100%)
          `
        }}
      />
    </div>
  );
}
