export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'user' | 'seller' | 'admin';
  authMethod: 'google' | 'email_password' | 'phone_otp' | 'instagram';
  registeredAt: string; // ISO date string
  lastLoginAt: string;  // ISO date string
  totalLogins: number;
  consentGiven: boolean;
  avatarUrl?: string;
  photoURL?: string;
  status: 'active' | 'suspended';
  referralCode?: string;
  utmSource?: string;
}

export interface LoginEvent {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  timestamp: string;    // ISO date string
  loginDate: string;    // YYYY-MM-DD
  loginTime: string;    // HH:MM:SS
  authMethod: string;
  device: string;
  status: 'success' | 'failed';
}

export interface DailyAnalytics {
  date: string;         // YYYY-MM-DD
  visitors: number;
  sessions: number;
  newRegistrations: number;
  successfulLogins: number;
  pageViews: number;
  uniqueUsers?: number;
}

export interface GoogleSheetsConfig {
  spreadsheetId?: string;
  webhookUrl?: string;
  lastSyncedAt?: string;
  autoSyncEnabled: boolean;
}

export interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  phone?: string;
  service?: string;
  message: string;
  createdAt: string;
  status: 'new' | 'read' | 'resolved';
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  consentGiven: string;
  subscribedAt: string;
  source?: string;
}

export interface FeedbackSubmission {
  id: string;
  name: string;
  email: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface GrowthMetrics {
  acquisition: {
    visitors: number;
    trafficSources: { source: string; count: number; percentage: number }[];
    campaignPerformance: { utmSource: string; clicks: number; registrations: number }[];
    newRegistrations: number;
  };
  engagement: {
    returningVisitors: number;
    activeUsers: number;
    loginActivity: number;
    popularPages: { page: string; views: number }[];
  };
  conversion: {
    visitorToRegistrationRate: number;
    contactFormCompletionRate: number;
    newsletterSignupRate: number;
  };
  retention: {
    returningRegisteredUsers: number;
    loginFrequencyAvg: number;
    userActivityTrend: 'up' | 'stable' | 'down';
  };
  recommendations: {
    category: 'SEO' | 'Acquisition' | 'Engagement' | 'Conversion';
    title: string;
    description: string;
    actionable: string;
    impact: 'high' | 'medium' | 'low';
  }[];
}
